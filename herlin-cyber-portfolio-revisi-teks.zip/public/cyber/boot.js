const button = document.getElementById("metatron");
const hint = document.getElementById("hint");
const loader = document.getElementById("load");
let api = null;
let completed = false;
let failed = false;
let timer = 0;
let watchdog = 0;

function complete() {
  if (completed) return;
  completed = true;
  clearTimeout(watchdog);
  button.disabled = true;
  document.body.classList.add("leaving", "covered");
  timer = setTimeout(() => {
    api?.dispose();
    api = null;
    parent.postMessage({ type: "herlin:cyber-complete" }, location.origin);
  }, 380);
}

function fallback(error) {
  if (completed || failed) return;
  failed = true;
  clearTimeout(watchdog);
  api?.dispose();
  api = null;
  document.body.classList.add("fallback");
  loader.classList.add("done");
  for (const property of ["left", "top", "width", "height"])
    button.style.removeProperty(property);
  const points = [[0, 0]];
  for (let ring = 1; ring <= 2; ring++) {
    for (let k = 0; k < 6; k++) {
      const angle = Math.PI / 2 + (k * Math.PI) / 3;
      points.push([Math.cos(angle) * 0.5 * ring, Math.sin(angle) * 0.5 * ring]);
    }
  }
  const svg = document.getElementById("metatron-static");
  for (let i = 0; i < points.length; i++) {
    for (let j = i + 1; j < points.length; j++) {
      const line = document.createElementNS(
        "http://www.w3.org/2000/svg",
        "line",
      );
      ["x1", "y1", "x2", "y2"].forEach((key, index) =>
        line.setAttribute(key, [...points[i], ...points[j]][index]),
      );
      svg.append(line);
    }
    const circle = document.createElementNS(
      "http://www.w3.org/2000/svg",
      "circle",
    );
    circle.setAttribute("cx", points[i][0]);
    circle.setAttribute("cy", points[i][1]);
    circle.setAttribute("r", ".25");
    svg.append(circle);
  }
  hint.textContent = "diagramnya aneh ga si lin?";
  button.disabled = false;
  button.onclick = complete;
  document.documentElement.dataset.cyberMode = "fallback";
  console.warn("Cyber Ronin fallback:", error);
}

if (parent !== window) {
  watchdog = setTimeout(() => fallback("Model readiness timeout"), 30000);
  try {
    const { startCyber } = await import("./ronin.js");
    if (!failed && !completed) {
      api = startCyber({
        button,
        onComplete: complete,
        onError: (error) => queueMicrotask(() => fallback(error)),
        onReady: () => {
          clearTimeout(watchdog);
          document.documentElement.dataset.cyberMode = "webgl";
        },
      });
    }
  } catch (error) {
    fallback(error);
  }
}

addEventListener(
  "pagehide",
  () => {
    clearTimeout(timer);
    clearTimeout(watchdog);
    api?.dispose();
    api = null;
  },
  { once: true },
);
