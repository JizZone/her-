import * as THREE from "three";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { RoomEnvironment } from "three/addons/environments/RoomEnvironment.js";
import { LineSegments2 } from "three/addons/lines/LineSegments2.js";
import { LineSegmentsGeometry } from "three/addons/lines/LineSegmentsGeometry.js";
import { LineMaterial } from "three/addons/lines/LineMaterial.js";
export function startCyber({ button, onComplete, onError, onReady }) {
  let disposed = false;
  let renderer = null;
  const controller = new AbortController();
  const scenes = [];
  const resources = new Set();
  const style = getComputedStyle(document.documentElement);
  const palette = {
    ink: style.getPropertyValue("--ink").trim(),
    bone: style.getPropertyValue("--bone").trim(),
  };
  if (!palette.ink || !palette.bone)
    throw new Error("Portfolio palette unavailable");
  const on = (target, type, callback, options = {}) =>
    target.addEventListener(type, callback, {
      ...options,
      signal: controller.signal,
    });
  function disposeGraph(root) {
    const geometries = new Set(),
      materials = new Set(),
      textures = new Set();
    root.traverse((object) => {
      if (object.geometry) geometries.add(object.geometry);
      const list = Array.isArray(object.material)
        ? object.material
        : [object.material];
      for (const material of list) {
        if (!material) continue;
        materials.add(material);
        for (const value of Object.values(material))
          if (value?.isTexture) textures.add(value);
        for (const uniform of Object.values(material.uniforms || {}))
          if (uniform?.value?.isTexture) textures.add(uniform.value);
      }
    });
    for (const geometry of geometries) geometry.dispose();
    for (const material of materials) material.dispose();
    for (const texture of textures) {
      texture.source?.data?.close?.();
      texture.dispose();
    }
    root.clear();
  }
  function dispose() {
    if (disposed) return;
    disposed = true;
    controller.abort();
    renderer?.setAnimationLoop(null);
    for (const scene of scenes) disposeGraph(scene);
    for (const resource of resources) resource.dispose();
    scenes.length = 0;
    resources.clear();
    if (renderer) {
      renderer.renderLists.dispose();
      renderer.dispose();
      renderer.forceContextLoss();
      renderer.domElement.width = 1;
      renderer.domElement.height = 1;
      renderer.domElement.remove();
      renderer = null;
    }
    document.body.style.cursor = "";
  }
  try {
    renderer = new THREE.WebGLRenderer({
      antialias: true,
      alpha: true,
      powerPreference: "high-performance",
    });
    renderer.setPixelRatio(
      Math.min(
        devicePixelRatio,
        matchMedia("(pointer:coarse)").matches ? 1.75 : 2,
      ),
    );
    renderer.autoClear = false;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.05;
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    document.body.appendChild(renderer.domElement);
    const scene = new THREE.Scene();
    scenes.push(scene);
    const environmentGenerator = new THREE.PMREMGenerator(renderer);
    const room = new RoomEnvironment();
    const environment = environmentGenerator.fromScene(room, 0.04);
    scene.environment = environment.texture;
    resources.add(environment);
    environmentGenerator.dispose();
    room.dispose?.();
    const key = new THREE.DirectionalLight(0xffffff, 1.6);
    key.position.set(1.5, 3, 3);
    scene.add(key);
    const rim = new THREE.DirectionalLight(0x7fa8ff, 2.2);
    rim.position.set(-3, 2, -2);
    scene.add(rim);
    const kick = new THREE.DirectionalLight(0xff2a3a, 1.1);
    kick.position.set(-2.5, -0.6, 2);
    scene.add(kick);
    const topL = new THREE.DirectionalLight(0xdfe8ff, 1.2);
    topL.position.set(2.5, 2, -1.5);
    scene.add(topL);
    const cam = new THREE.PerspectiveCamera(28, 1, 0.1, 50);
    const TARGET = new THREE.Vector3(0, 1.5, 0);
    function fit() {
      const w = document.documentElement.clientWidth,
        h = document.documentElement.clientHeight;
      renderer.setSize(w, h, false);
      cam.aspect = w / h;
      const t = Math.tan(THREE.MathUtils.degToRad(cam.fov / 2));
      const H = Math.max(2.03, 1.2 / cam.aspect);
      TARGET.set(-0.14, 1 + 0.24 * H, 0);
      cam.position.set(TARGET.x, TARGET.y, H / (2 * t));
      cam.lookAt(TARGET);
      cam.updateProjectionMatrix();
    }
    on(window, "resize", fit);
    if (window.visualViewport) on(visualViewport, "resize", fit);
    fit();

    const HEAD_P = new THREE.Vector3(0.03, 1.66, -0.06),
      WAIST_P = new THREE.Vector3(0, 1.1, -0.05);
    const BAKED_YAW = 0.49;
    const U = {
      uHR: { value: new THREE.Matrix3() },
      uHP: { value: HEAD_P },
      uTR: { value: new THREE.Matrix3() },
      uTP: { value: WAIST_P },
      uTT: { value: new THREE.Vector3() },
      uT: { value: 0 },
    };
    const ss = (a, b, x) => {
      const t = Math.min(1, Math.max(0, (x - a) / (b - a)));
      return t * t * (3 - 2 * t);
    };
    function patch(mt) {
      const fx = mt.name.startsWith("LowSet");
      mt.customProgramCacheKey = () => (fx ? "ronin-v" : "ronin");
      mt.onBeforeCompile = (sh) => {
        Object.assign(sh.uniforms, U);
        sh.vertexShader = sh.vertexShader
          .replace(
            "#include <common>",
            "#include <common>\nattribute float headW;attribute float torW;uniform mat3 uHR,uTR;uniform vec3 uHP,uTP,uTT;varying vec3 vP;",
          )
          .replace(
            "#include <beginnormal_vertex>",
            "#include <beginnormal_vertex>\nobjectNormal=mix(objectNormal,uHR*objectNormal,headW);objectNormal=mix(objectNormal,uTR*objectNormal,torW);",
          )
          .replace(
            "#include <begin_vertex>",
            "#include <begin_vertex>\ntransformed=mix(transformed,uHP+uHR*(transformed-uHP),headW);transformed=mix(transformed,uTP+uTR*(transformed-uTP)+uTT,torW);vP=transformed;",
          );
        if (fx)
          sh.fragmentShader = sh.fragmentShader
            .replace(
              "#include <common>",
              `#include <common>
uniform float uT;varying vec3 vP;
float hh(vec3 p){p=fract(p*.3183099+.1);p*=17.;return fract(p.x*p.y*p.z*(p.x+p.y+p.z));}
float nn(vec3 x){vec3 i=floor(x),f=fract(x);f=f*f*(3.-2.*f);
return mix(mix(mix(hh(i),hh(i+vec3(1.,0.,0.)),f.x),mix(hh(i+vec3(0.,1.,0.)),hh(i+vec3(1.,1.,0.)),f.x),f.y),
mix(mix(hh(i+vec3(0.,0.,1.)),hh(i+vec3(1.,0.,1.)),f.x),mix(hh(i+vec3(0.,1.,1.)),hh(i+vec3(1.,1.,1.)),f.x),f.y),f.z);}
float fb(vec3 p){return .55*nn(p)+.3*nn(p*2.1)+.15*nn(p*4.3);}`,
            )
            .replace(
              "#include <map_fragment>",
              `#include <map_fragment>
float rustM=smoothstep(.56,.78,fb(vP*9.+3.))*.9;
vec3 rustC=mix(vec3(.3,.1,.04),vec3(.62,.27,.09),fb(vP*18.));
diffuseColor.rgb=mix(diffuseColor.rgb,rustC,rustM);
float vA=abs(sin(vP.x*10.+sin(vP.y*12.)*2.2+sin(vP.z*9.)*1.6));
float vB=abs(sin(vP.y*8.-sin(vP.x*11.)*2.+sin(vP.z*12.)*1.5));
float vd=min(vA,vB);
float vUp=smoothstep(.9,1.6,vP.y)*smoothstep(.5,.72,fb(vP*3.5+7.));
diffuseColor.rgb*=1.-(1.-smoothstep(.11,.2,vd))*.95*vUp;`,
            )
            .replace(
              "#include <roughnessmap_fragment>",
              "#include <roughnessmap_fragment>\nroughnessFactor=mix(roughnessFactor,.88,rustM);",
            )
            .replace(
              "#include <metalnessmap_fragment>",
              "#include <metalnessmap_fragment>\nmetalnessFactor=mix(metalnessFactor,.15,rustM);",
            )
            .replace(
              "#include <emissivemap_fragment>",
              `#include <emissivemap_fragment>
totalEmissiveRadiance+=vec3(1.,.04,.08)*(1.-smoothstep(.02,.06,vd))*1.5*vUp;`,
            );
      };
    }

    function glowTex() {
      const c = document.createElement("canvas");
      c.width = c.height = 128;
      const g = c.getContext("2d");
      const r = g.createRadialGradient(64, 64, 0, 64, 64, 64);
      r.addColorStop(0, "rgba(255,255,255,1)");
      r.addColorStop(0.18, "rgba(255,235,230,1)");
      r.addColorStop(0.38, "rgba(255,40,50,.95)");
      r.addColorStop(0.7, "rgba(255,20,40,.25)");
      r.addColorStop(1, "rgba(255,0,30,0)");
      g.fillStyle = r;
      g.fillRect(0, 0, 128, 128);
      const t = new THREE.CanvasTexture(c);
      t.colorSpace = THREE.SRGBColorSpace;
      return t;
    }
    const gt = glowTex();
    function eyeTex() {
      const c = document.createElement("canvas");
      c.width = c.height = 128;
      const g = c.getContext("2d");
      const r = g.createRadialGradient(64, 64, 0, 64, 64, 64);
      r.addColorStop(0, "rgba(255,255,255,1)");
      r.addColorStop(0.2, "rgba(225,240,255,1)");
      r.addColorStop(0.42, "rgba(110,175,255,.9)");
      r.addColorStop(0.72, "rgba(60,120,255,.2)");
      r.addColorStop(1, "rgba(40,90,255,0)");
      g.fillStyle = r;
      g.fillRect(0, 0, 128, 128);
      const x = new THREE.CanvasTexture(c);
      x.colorSpace = THREE.SRGBColorSpace;
      return x;
    }
    const et = eyeTex();
    const eyeRest = [
      new THREE.Vector3(0.013, 1.79, 0.033),
      new THREE.Vector3(0.082, 1.794, -0.004),
    ];
    const faceN = new THREE.Vector3(0.47, 0, 0.88);
    const eyes = eyeRest.map(() => {
      const s = new THREE.Sprite(
        new THREE.SpriteMaterial({
          map: et,
          transparent: true,
          depthWrite: false,
          toneMapped: false,
        }),
      );
      s.scale.set(0.05, 0.05, 1);
      s.renderOrder = 5;
      scene.add(s);
      return s;
    });
    const halos = eyeRest.map(() => {
      const s = new THREE.Sprite(
        new THREE.SpriteMaterial({
          map: et,
          color: 0x8fbaff,
          transparent: true,
          opacity: 0.2,
          blending: THREE.AdditiveBlending,
          depthWrite: false,
          toneMapped: false,
        }),
      );
      s.renderOrder = 4;
      scene.add(s);
      return s;
    });
    const auraU = { uT: { value: 0 } };
    const aura = new THREE.Mesh(
      new THREE.PlaneGeometry(3.2, 3.4),
      new THREE.ShaderMaterial({
        uniforms: auraU,
        transparent: true,
        depthWrite: false,
        vertexShader:
          "varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}",
        fragmentShader: `uniform float uT;varying vec2 vUv;
float h(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float n(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h(i),h(i+vec2(1.,0.)),f.x),mix(h(i+vec2(0.,1.)),h(i+vec2(1.,1.)),f.x),f.y);}
float fbm(vec2 p){float a=.5,s=0.;for(int i=0;i<3;i++){s+=a*n(p);p=p*2.03+vec2(1.7,9.2);a*=.5;}return s;}
void main(){
  vec2 q=(vUv-.5)*vec2(3.2,3.4)-vec2(.12,0.);
  float mask=1.-smoothstep(.25,1.05,length(q/vec2(.72,1.1)));
  vec2 p=q*1.3+vec2(0.,-uT*.12);
  float w=fbm(p+vec2(uT*.05,0.));
  float d=fbm(p*1.1+w*1.6+vec2(0.,-uT*.08));
  float dens=smoothstep(.28,.8,d)*mask;
  float red=smoothstep(.45,.85,fbm(p*.8+w*2.+11.))*mask;
  vec3 col=mix(vec3(.01,0.,.015),vec3(.62,.02,.07),red);
  float a=clamp(dens*.95+red*.35,0.,.92)*smoothstep(0.,.1,vUv.y)*(1.-smoothstep(.9,1.,vUv.y));
  gl_FragColor=vec4(col,a);
}`,
      }),
    );
    aura.position.set(0, 1.45, -0.5);
    aura.renderOrder = -1;
    scene.add(aura);
    const mt = (() => {
      const S = 0.2,
        LIFT = 0.3;
      const GOLD = 0xb87a10,
        RED = 0xc8101f,
        HOT = 0x3a0509,
        WHITE = new THREE.Color(palette.ink);
      const fat = [];
      const fm2 = (c, o, w) => {
        const m = new LineMaterial({
          color: c,
          linewidth: w,
          transparent: true,
          opacity: o,
          blending: THREE.NormalBlending,
          depthWrite: false,
          toneMapped: false,
        });
        m.userData.base = o;
        fat.push(m);
        return m;
      };
      const seg2 = (arr, m) => {
        const g = new LineSegmentsGeometry();
        g.setPositions(arr);
        const l = new LineSegments2(g, m);
        l.frustumCulled = false;
        return l;
      };
      const anchor = new THREE.Group();
      anchor.visible = false;
      scene.add(anchor);
      const root = new THREE.Group();
      root.scale.setScalar(S);
      anchor.add(root);
      const meta = new THREE.Group();
      root.add(meta);
      const D = 0.5,
        nodes = [new THREE.Vector3()];
      for (let r = 1; r <= 2; r++)
        for (let k = 0; k < 6; k++) {
          const a = Math.PI / 2 + (k * Math.PI) / 3;
          nodes.push(
            new THREE.Vector3(Math.cos(a) * D * r, Math.sin(a) * D * r, 0),
          );
        }
      const segs = [];
      for (let i = 0; i < 13; i++)
        for (let j = i + 1; j < 13; j++) segs.push([nodes[i], nodes[j]]);
      const lpos = new Float32Array(segs.length * 6);
      segs.forEach((s, i) =>
        lpos.set([s[0].x, s[0].y, s[0].z, s[1].x, s[1].y, s[1].z], i * 6),
      );
      const lineSeg = seg2(new Float32Array(lpos.length), fm2(RED, 0.75, 1.2));
      meta.add(lineSeg);
      const lb = lineSeg.geometry.attributes.instanceStart.data;
      const RN = 192,
        rp = new Float32Array(RN * 6);
      for (let i = 0; i < RN; i++) {
        const a = (i / RN) * Math.PI * 2,
          b = ((i + 1) / RN) * Math.PI * 2;
        rp.set(
          [
            (Math.cos(a) * D) / 2,
            (Math.sin(a) * D) / 2,
            0,
            (Math.cos(b) * D) / 2,
            (Math.sin(b) * D) / 2,
            0,
          ],
          i * 6,
        );
      }
      const ringGeo = new LineSegmentsGeometry();
      ringGeo.setPositions(rp);
      const ringMat = fm2(GOLD, 0.9, 1.4);
      const rings = nodes.map((n) => {
        const l = new LineSegments2(ringGeo, ringMat);
        l.frustumCulled = false;
        l.position.copy(n);
        l.scale.setScalar(0.0001);
        meta.add(l);
        return l;
      });
      const ringAt = (i) =>
        i === 0 ? 0.3 : i < 7 ? 1 + (i - 1) * 0.18 : 2 + (i - 7) * 0.15;
      const c = document.createElement("canvas");
      c.width = c.height = 64;
      const g = c.getContext("2d"),
        rg = g.createRadialGradient(32, 32, 0, 32, 32, 32);
      rg.addColorStop(0, "rgba(255,255,255,1)");
      rg.addColorStop(0.3, "rgba(255,200,130,.9)");
      rg.addColorStop(1, "rgba(255,60,40,0)");
      g.fillStyle = rg;
      g.fillRect(0, 0, 64, 64);
      const tex = new THREE.CanvasTexture(c);
      const dot = (s, col) =>
        new THREE.PointsMaterial({
          map: tex,
          size: s * S,
          transparent: true,
          blending: THREE.NormalBlending,
          depthWrite: false,
          color: col,
          toneMapped: false,
        });
      const ng = new THREE.BufferGeometry().setFromPoints(nodes);
      const np = new THREE.Points(ng, dot(0.2, 0x1a0508));
      np.frustumCulled = false;
      meta.add(np);
      function uniq(eg) {
        const p = eg.attributes.position,
          seen = new Map();
        for (let i = 0; i < p.count; i++) {
          const k = [p.getX(i), p.getY(i), p.getZ(i)]
            .map((v) => v.toFixed(3))
            .join();
          if (!seen.has(k))
            seen.set(k, new THREE.Vector3(p.getX(i), p.getY(i), p.getZ(i)));
        }
        return [...seen.values()];
      }
      function solid(gg, col, o, fo, sp, i) {
        const grp = new THREE.Group(),
          eg = new THREE.EdgesGeometry(gg),
          fx = [];
        const lm = fm2(col, o, 1.15);
        fx.push([lm, o]);
        grp.add(
          new LineSegments2(
            new LineSegmentsGeometry().fromEdgesGeometry(eg),
            lm,
          ),
        );
        const fm = new THREE.MeshBasicMaterial({
          color: col,
          transparent: true,
          opacity: 0,
          side: THREE.DoubleSide,
          blending: THREE.NormalBlending,
          depthWrite: false,
          toneMapped: false,
        });
        grp.add(new THREE.Mesh(gg, fm));
        fx.push([fm, fo]);
        const dm = dot(0.12, 0x1a0508);
        grp.add(
          new THREE.Points(
            new THREE.BufferGeometry().setFromPoints(uniq(eg)),
            dm,
          ),
        );
        fx.push([dm, 1]);
        if (gg.type === "BoxGeometry") {
          const l2 = fm2(col, o * 0.8, 1);
          fx.push([l2, o * 0.8]);
          const inner = new LineSegments2(
            new LineSegmentsGeometry().fromEdgesGeometry(
              new THREE.EdgesGeometry(new THREE.BoxGeometry(0.7, 0.7, 0.7)),
            ),
            l2,
          );
          inner.userData.inner = true;
          grp.add(inner);
        }
        fx.forEach(([m]) => {
          m.opacity = 0;
        });
        grp.userData = { sp, at: 5.6 + i * 0.6, fx };
        grp.scale.setScalar(0.3);
        grp.traverse((o) => {
          o.frustumCulled = false;
        });
        root.add(grp);
        return grp;
      }
      const solids = [
        [
          new THREE.TetrahedronGeometry(0.62),
          GOLD,
          0.95,
          0.05,
          [0.31, 0.22, 0.0],
        ],
        [
          new THREE.OctahedronGeometry(0.8),
          WHITE,
          0.5,
          0.02,
          [-0.22, 0.37, 0.1],
        ],
        [
          new THREE.BoxGeometry(1.27, 1.27, 1.27),
          GOLD,
          0.85,
          0.04,
          [0.17, -0.28, 0.2],
        ],
        [
          new THREE.IcosahedronGeometry(1),
          WHITE,
          0.45,
          0.02,
          [-0.3, -0.16, 0.24],
        ],
        [
          new THREE.DodecahedronGeometry(1.14),
          RED,
          0.9,
          0.02,
          [0.12, 0.2, -0.3],
        ],
      ].map(([gg, col, o, fo, sp], i) => solid(gg, col, o, fo, sp, i));
      const V = [];
      for (let i = 0; i < 32; i++)
        V.push([0, 1, 2, 3, 4].map((b) => ((i >> b) & 1 ? 1 : -1)));
      const E = [];
      for (let i = 0; i < 32; i++)
        for (let b = 0; b < 5; b++) {
          const j = i ^ (1 << b);
          if (j > i) E.push([i, j]);
        }
      const pentMat = fm2(HOT, 1, 1.7);
      const pent = seg2(new Float32Array(E.length * 6), pentMat);
      root.add(pent);
      const pb = pent.geometry.attributes.instanceStart.data;
      const vg = new THREE.BufferGeometry(),
        vpos = new Float32Array(96);
      vg.setAttribute("position", new THREE.BufferAttribute(vpos, 3));
      const vmat = dot(0.14, 0x2a0508);
      const vpts = new THREE.Points(vg, vmat);
      vpts.frustumCulled = false;
      root.add(vpts);
      const tmp = new Float32Array(96);
      const rot = (v, i, j, a) => {
        const cs = Math.cos(a),
          sn = Math.sin(a),
          x = v[i],
          y = v[j];
        v[i] = x * cs - y * sn;
        v[j] = x * sn + y * cs;
      };
      function penteract(t) {
        for (let i = 0; i < 32; i++) {
          const v = V[i].slice();
          rot(v, 0, 3, t * 0.31);
          rot(v, 1, 4, t * 0.23);
          rot(v, 2, 4, t * 0.37);
          rot(v, 0, 2, t * 0.17);
          rot(v, 1, 3, t * 0.29);
          rot(v, 3, 4, t * 0.13);
          const k5 = 1 / (2.6 - v[4]),
            a = [v[0] * k5, v[1] * k5, v[2] * k5, v[3] * k5],
            k4 = 1 / (2.2 - a[3]);
          tmp[i * 3] = a[0] * k4 * 0.62;
          tmp[i * 3 + 1] = a[1] * k4 * 0.62;
          tmp[i * 3 + 2] = a[2] * k4 * 0.62;
        }
        for (let e = 0; e < E.length; e++) {
          const [a, b] = E[e];
          pb.array.set(tmp.subarray(a * 3, a * 3 + 3), e * 6);
          pb.array.set(tmp.subarray(b * 3, b * 3 + 3), e * 6 + 3);
        }
        vpos.set(tmp);
        pb.needsUpdate = true;
        vg.attributes.position.needsUpdate = true;
      }
      const LINE_AT = 3.2,
        LINE_SPAN = 2.6,
        LINE_DUR = 0.7,
        PENT_AT = 8,
        END = 10;
      let linesDone = false,
        rw = 0,
        rh = 0,
        shake = 0,
        pulse = 0;
      const HP = new THREE.Vector3(-0.467, 1.342, 0.24),
        HD = new THREE.Vector3(0.3, 0.95, -0.1).normalize(),
        p0 = new THREE.Vector3(),
        p1 = new THREE.Vector3();
      function grow(T) {
        const n = segs.length,
          arr = lb.array;
        for (let i = 0; i < n; i++) {
          const k = ss(
              LINE_AT + (i / n) * LINE_SPAN,
              LINE_AT + (i / n) * LINE_SPAN + LINE_DUR,
              T,
            ),
            o = i * 6;
          for (let q = 0; q < 3; q++) {
            const a = lpos[o + q],
              b = lpos[o + 3 + q];
            arr[o + q] = a;
            arr[o + 3 + q] = a + (b - a) * k;
          }
        }
        lb.needsUpdate = true;
      }
      return {
        anchor,
        setShake(v) {
          shake = v;
        },
        setPulse(v) {
          pulse = v;
        },
        update(T, t, dt, M) {
          if (T < 0) {
            anchor.visible = false;
            return;
          }
          if (rw !== innerWidth || rh !== innerHeight) {
            rw = innerWidth;
            rh = innerHeight;
            fat.forEach((m) => m.resolution.set(rw, rh));
          }
          anchor.visible = true;
          p0.copy(HP).addScaledVector(HD, LIFT + Math.sin(t * 1.1) * 0.006);
          p1.copy(p0).applyMatrix4(M);
          p0.lerp(p1, ss(0.95, 1.55, HP.y));
          anchor.position.copy(p0);
          anchor.position.x += (Math.random() - 0.5) * shake;
          anchor.position.y += (Math.random() - 0.5) * shake;
          root.scale.setScalar(S * (1 + pulse));
          const intro = 1 - ss(0, END, T);
          root.rotation.y = t * 0.12 + intro * 3.2;
          root.rotation.x = Math.sin(t * 0.3) * 0.12;
          meta.rotation.y = Math.sin(t * 0.35) * 0.5;
          let shown = 0;
          rings.forEach((r, i) => {
            const k = ss(ringAt(i), ringAt(i) + 0.9, T);
            r.scale.setScalar(Math.max(k, 0.0001));
            if (k > 0.25) shown = i + 1;
          });
          ng.setDrawRange(0, shown);
          if (!linesDone) {
            grow(T);
            if (T >= LINE_AT + LINE_SPAN + LINE_DUR + 0.1) linesDone = true;
          }
          solids.forEach((m) => {
            const s = m.userData.sp,
              k = ss(m.userData.at, m.userData.at + 1.4, T);
            m.rotation.set(t * s[0], t * s[1], t * s[2]);
            m.scale.setScalar(0.3 + 0.7 * k);
            m.userData.fx.forEach(([a, b]) => {
              a.opacity = b * k;
            });
            m.children.forEach((o) => {
              if (o.userData.inner) o.rotation.set(-t * 0.4, t * 0.5, 0);
            });
          });
          const pk = ss(PENT_AT, PENT_AT + 2, T);
          pent.scale.setScalar(Math.max(pk, 0.0001));
          vpts.scale.setScalar(Math.max(pk, 0.0001));
          pentMat.opacity = pk;
          vmat.opacity = pk;
          penteract(t);
        },
      };
    })();
    const finale = (() => {
      const END = 10,
        HR = 0.27;
      const ovU = {
        uK: { value: 0 },
        uAsp: { value: 1 },
        uMaxD: { value: 1 },
        uT: { value: 0 },
        uOut: { value: 1 },
        uCr: { value: 0 },
        uC: { value: new THREE.Vector2(0.5, 0.5) },
        uTouch: { value: new THREE.Vector2(0.5, 0.5) },
        uInk: { value: new THREE.Color(palette.ink).convertLinearToSRGB() },
      };
      const ovMesh = new THREE.Mesh(
        new THREE.PlaneGeometry(2, 2),
        new THREE.ShaderMaterial({
          uniforms: ovU,
          transparent: true,
          depthTest: false,
          depthWrite: false,
          vertexShader:
            "varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}",
          fragmentShader: `uniform float uK,uAsp,uMaxD,uT,uOut,uCr;uniform vec2 uC,uTouch;uniform vec3 uInk;varying vec2 vUv;
float h(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float n(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h(i),h(i+vec2(1.,0.)),f.x),mix(h(i+vec2(0.,1.)),h(i+vec2(1.,1.)),f.x),f.y);}
float fbm(vec2 p){float a=.5,s=0.;for(int i=0;i<4;i++){s+=a*n(p);p=p*2.03+vec2(1.7,9.2);a*=.5;}return s;}
void main(){
vec2 p=(vUv-uC)*vec2(uAsp,1.);float r=length(p);float a=atan(p.y,p.x);
float cover=0.;
for(int k=0;k<10;k++){
float fk=float(k);
float ang=h(vec2(fk,1.3))*6.2831;
float w=.05+.09*h(vec2(fk,2.1));
float s=1.15+fk*.19+h(vec2(fk,3.7))*.1;
float reach=(.35+.9*h(vec2(fk,4.4)))*uMaxD*.55;
float on=smoothstep(s,s+.12,uK)*(1.-.55*smoothstep(s+.45,s+.8,uK));
float fl=.55+.45*step(.35,h(vec2(floor(uK*16.)+fk,fk)));
float da=abs(mod(a-ang+3.14159,6.2831)-3.14159);
float wob=(fbm(vec2(r*5.+fk*3.,uK*2.))-.5)*.7*smoothstep(0.,.4,r);
float prof=exp(-pow((da+wob*.4)/w,2.));
float L=reach*on*fl;
cover=max(cover,smoothstep(0.,.03,L*prof-r));
}
float Rm=uMaxD*1.75*pow(smoothstep(2.3,5.3,uK),1.4);
float R=Rm*(.78+.44*fbm(vec2(a*2.2+3.,uT*.2)))+(fbm(p*4.+uT*.3)-.5)*.2*Rm;
cover=max(cover,smoothstep(0.,.05,R-r));
float edge=smoothstep(0.,.06,R-r)*(1.-smoothstep(.06,.14,R-r));
vec3 col=mix(uInk,vec3(.25,.01,.03),edge*.6*step(.5,Rm));
float al=cover*uOut;
vec2 pc=(vUv-uTouch)*vec2(uAsp,1.);
vec2 q=pc*7.+(vec2(n(pc*9.),n(pc*9.+7.))-.5)*1.1;
vec2 ip=floor(q),fp=fract(q);float d1=8.,d2=8.;
for(int j=-1;j<=1;j++)for(int i=-1;i<=1;i++){vec2 g=vec2(float(i),float(j));vec2 rr=g+vec2(h(ip+g),h(ip+g+17.3))-fp;float d=dot(rr,rr);if(d<d1){d2=d1;d1=d;}else if(d<d2){d2=d;}}
float cw=sqrt(d2)-sqrt(d1);
float rev=(1.-smoothstep(uCr*.4-.14,uCr*.4,length(pc)))*step(.001,uCr);
float core=(1.-smoothstep(0.,.05,cw))*rev;
float rim=(1.-smoothstep(0.,.14,cw))*rev*.6;
float ca=max(core,rim);
vec3 cc=mix(vec3(.85,.05,.1),vec3(.02),core/(ca+.0001));
float alpha=max(al,ca);
vec3 oc=(col*al+cc*ca*(1.-al))/max(alpha,.0001);
gl_FragColor=vec4(oc,alpha);
}`,
        }),
      );
      ovMesh.frustumCulled = false;
      ovMesh.visible = false;
      const ovScene = new THREE.Scene();
      scenes.push(ovScene);
      ovScene.add(ovMesh);
      const hit = new THREE.Sphere(new THREE.Vector3(), HR),
        ray = new THREE.Raycaster(),
        ndc = new THREE.Vector2(),
        tv = new THREE.Vector3(),
        pt = new THREE.Vector3();
      let state = "wait",
        t0 = 0,
        now = 0,
        finished = false;
      const pick = (e) => {
        ndc.set(
          (e.clientX / innerWidth) * 2 - 1,
          -(e.clientY / innerHeight) * 2 + 1,
        );
        ray.setFromCamera(ndc, cam);
        hit.center.copy(mt.anchor.position);
        return ray.ray.intersectSphere(hit, pt) !== null;
      };
      function center(e) {
        tv.copy(mt.anchor.position).project(cam);
        const cx = tv.x * 0.5 + 0.5,
          cy = tv.y * 0.5 + 0.5,
          asp = innerWidth / innerHeight;
        ovU.uC.value.set(cx, cy);
        ovU.uAsp.value = asp;
        ovU.uTouch.value.set(
          e.clientX / innerWidth,
          1 - e.clientY / innerHeight,
        );
        ovU.uMaxD.value = Math.max(
          Math.hypot(cx * asp, cy),
          Math.hypot((1 - cx) * asp, cy),
          Math.hypot(cx * asp, 1 - cy),
          Math.hypot((1 - cx) * asp, 1 - cy),
        );
      }
      on(button, "click", (event) => {
        if (state !== "idle" || finished) return;
        const rect = button.getBoundingClientRect();
        const e =
          event.detail === 0
            ? {
                clientX: rect.left + rect.width / 2,
                clientY: rect.top + rect.height / 2,
              }
            : event;
        center(e);
        state = "burst";
        t0 = now;
        button.disabled = true;
        if (still) {
          finished = true;
          onComplete();
        }
      });
      on(window, "pointermove", (e) => {
        if (state === "idle")
          document.body.style.cursor = pick(e) ? "pointer" : "";
      });
      return {
        update(T, t, dt) {
          now = t;
          if (T < 0) return;
          if (state === "wait") {
            if (T > END + 1) {
              state = "idle";
              button.disabled = false;
              document.getElementById("hint").textContent =
                "diagramnya aneh ga si lin?";
            } else return;
          }
          if (state === "idle") {
            tv.copy(mt.anchor.position).project(cam);
            button.style.left = (tv.x * 0.5 + 0.5) * innerWidth + "px";
            button.style.top = (-tv.y * 0.5 + 0.5) * innerHeight + "px";
            const distance = cam.position.distanceTo(mt.anchor.position);
            const diameter = Math.max(
              56,
              Math.min(
                180,
                (HR * innerHeight) /
                  (distance * Math.tan(THREE.MathUtils.degToRad(cam.fov / 2))),
              ),
            );
            button.style.width = diameter + "px";
            button.style.height = diameter + "px";
          }
          const K = state === "burst" || state === "black" ? t - t0 : 0;
          if (state === "burst" && K > 5.6 && !finished) {
            state = "black";
            finished = true;
            onComplete();
          }
          mt.setPulse(
            state === "idle"
              ? 0.025 * Math.pow(Math.sin(t * 1.4) * 0.5 + 0.5, 2)
              : 0,
          );
          mt.setShake(
            state === "burst"
              ? 0.01 * ss(0, 1.2, K) * (1 - ss(2.2, 2.6, K))
              : 0,
          );
          const cov = (state === "burst" && K > 1.1) || state === "black";
          const cr = state === "burst" ? ss(0, 1.3, K) : 0;
          ovMesh.visible = cov || cr > 0;
          document.body.classList.toggle("covered", cov);
          if (ovMesh.visible) {
            ovU.uK.value = K;
            ovU.uT.value = t;
            ovU.uCr.value = cr;
            ovU.uOut.value = 1;
          }
        },
        overlay: ovScene,
        isCover: () => ovMesh.visible,
      };
    })();
    let born = -1;
    const model = new THREE.Group();
    scene.add(model);
    fetch("/cyber/ronin.glb", { signal: controller.signal })
      .then((response) => {
        if (!response.ok) throw new Error("Model " + response.status);
        return response.arrayBuffer();
      })
      .then((buffer) => new GLTFLoader().parseAsync(buffer, ""))
      .then((gltf) => {
        if (disposed) {
          disposeGraph(gltf.scene);
          return;
        }
        gltf.scene.updateMatrixWorld(true);
        const ms = [];
        gltf.scene.traverse((o) => {
          if (o.isMesh) ms.push(o);
        });
        for (const o of ms) {
          const g = o.geometry.clone();
          g.applyMatrix4(o.matrixWorld);
          g.computeBoundingBox();
          const bb = g.boundingBox,
            p = g.attributes.position,
            n = p.count;
          const isHead = bb.min.y > 1.55;
          const hw = new Float32Array(n),
            tw = new Float32Array(n);
          for (let i = 0; i < n; i++) {
            const x = p.getX(i),
              y = p.getY(i),
              z = p.getZ(i),
              r = Math.hypot(x - 0.03, z + 0.06);
            hw[i] = ss(1.62, 1.72, y) * (isHead ? 1 : 1 - ss(0.16, 0.23, r));
            tw[i] = ss(0.95, 1.55, y);
          }
          g.setAttribute("headW", new THREE.BufferAttribute(hw, 1));
          g.setAttribute("torW", new THREE.BufferAttribute(tw, 1));
          const mt = o.material;
          mt.envMapIntensity = 1.2;
          if (mt.emissiveMap) mt.emissiveIntensity = 1.6;
          [
            "map",
            "normalMap",
            "emissiveMap",
            "roughnessMap",
            "metalnessMap",
            "aoMap",
          ].forEach((k) => {
            if (mt[k])
              mt[k].anisotropy = renderer.capabilities.getMaxAnisotropy();
          });
          if (mt.normalMap) mt.normalScale.set(1.25, 1.25);
          patch(mt);
          const m = new THREE.Mesh(g, mt);
          m.frustumCulled = false;
          model.add(m);
        }
        gltf.scene.traverse((object) => {
          if (object.isMesh) object.geometry.dispose();
        });
        gltf.scene.clear();
        document.getElementById("load").classList.add("done");
        onReady();
      })
      .catch((error) => {
        if (!disposed) onError(error);
      });

    let tx = 0,
      ty = 0,
      last = -9;
    const clk = new THREE.Clock();
    const move = (e) => {
      const p = e.touches ? e.touches[0] : e;
      tx = (p.clientX / innerWidth - 0.5) * 2;
      ty = (p.clientY / innerHeight - 0.5) * 2;
      last = clk.elapsedTime;
    };
    on(window, "pointermove", move);
    on(window, "touchmove", move, { passive: true });
    on(window, "touchstart", move, { passive: true });
    const still = matchMedia("(prefers-reduced-motion:reduce)").matches;
    let hy = 0,
      hp = 0,
      ty2 = 0,
      ly = 0,
      sx = 0,
      sy = 0,
      nextSac = 0,
      blinkAt = 2,
      blink = 0,
      alert = 0;
    const ease = (v, t, k, dt) => v + (t - v) * (1 - Math.exp(-k * dt));
    const Mh = new THREE.Matrix4(),
      Mt = new THREE.Matrix4(),
      Tm = new THREE.Matrix4(),
      R = new THREE.Matrix4(),
      v = new THREE.Vector3(),
      nrm = new THREE.Vector3();
    renderer.setAnimationLoop(() => {
      if (disposed || document.hidden) return;
      const dt = Math.min(clk.getDelta(), 0.05),
        t = clk.elapsedTime;
      const live = t - last < 3.5;

      let aimX = live ? tx : -0.5 + Math.sin(t * 0.45) * 0.08,
        aimY = live ? ty : 0.12 + Math.sin(t * 0.31 + 1) * 0.05;
      if (still) {
        aimX = 0;
        aimY = 0;
      }
      if (t > nextSac) {
        sx = (Math.random() - 0.5) * 0.06;
        sy = (Math.random() - 0.5) * 0.04;
        nextSac = t + 1.2 + Math.random() * 2.2;
      }
      const yawT = aimX * 0.85 + sx,
        pitT = aimY * 0.32 + sy;
      hy = ease(hy, yawT, live ? 9 : 4, dt);
      hp = ease(hp, pitT, live ? 9 : 4, dt);
      ly = ease(ly, hy, 2.4, dt);
      const breath = still ? 0 : Math.sin(t * 1.5);

      R.makeRotationFromEuler(new THREE.Euler(hp, hy - BAKED_YAW, 0, "YXZ"));

      Mh.makeTranslation(HEAD_P.x, HEAD_P.y, HEAD_P.z)
        .multiply(R)
        .multiply(Tm.makeTranslation(-HEAD_P.x, -HEAD_P.y, -HEAD_P.z));
      U.uHR.value.setFromMatrix4(R);
      const TR = new THREE.Matrix4().makeRotationFromEuler(
        new THREE.Euler(hp * 0.15, ly * 0.22, -ly * 0.04, "YXZ"),
      );
      const TT = new THREE.Vector3(0, breath * 0.005, breath * 0.008);
      U.uTR.value.setFromMatrix4(TR);
      U.uTT.value.copy(TT);
      Mt.makeTranslation(WAIST_P.x, WAIST_P.y, WAIST_P.z)
        .multiply(TR)
        .multiply(Tm.makeTranslation(-WAIST_P.x, -WAIST_P.y, -WAIST_P.z))
        .premultiply(Tm.makeTranslation(TT.x, TT.y, TT.z));

      alert = ease(alert, live ? 1 : 0, 3, dt);
      if (t > blinkAt) {
        blink = 1;
        blinkAt = t + 2.5 + Math.random() * 3.5;
      }
      blink = Math.max(0, blink - dt * 9);
      const open = 1 - blink * 0.9;
      eyes.forEach((s, i) => {
        v.copy(eyeRest[i]);
        nrm.copy(faceN).multiplyScalar(0.012);
        v.add(nrm);
        v.applyMatrix4(Mh).applyMatrix4(Mt);
        s.position.copy(v);
        const k = 0.04 + 0.016 * alert + 0.003 * Math.sin(t * 3 + i);
        s.scale.set(k, Math.max(0.004, k * Math.max(0.08, open)), 1);
        s.material.opacity = 0.65 + 0.2 * alert;
        const h = halos[i],
          hs = k * (2.4 + 0.5 * alert);
        h.position.copy(s.position);
        h.scale.set(hs, hs * Math.max(0.25, open), 1);
        h.material.opacity = 0.14 + 0.1 * alert;
      });
      U.uT.value = t;
      auraU.uT.value = t;
      if (born < 0 && model.children.length) born = still ? t - 12 : t + 0.6;
      mt.update(born < 0 ? -1 : t - born, still ? 12 : t, dt, Mt);
      finale.update(born < 0 ? -1 : t - born, t, dt);
      renderer.clear();
      renderer.render(scene, cam);
      if (finale.isCover()) renderer.render(finale.overlay, cam);
    });
    on(renderer.domElement, "webglcontextlost", (event) => {
      event.preventDefault();
      if (!disposed) onError(new Error("WebGL context lost"));
    });
    return { dispose };
  } catch (error) {
    dispose();
    throw error;
  }
}
