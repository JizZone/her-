import type { MetadataRoute } from "next";
export const dynamic = "force-static";
export default function robots(): MetadataRoute.Robots {
  return {
    rules: { userAgent: "*", allow: "/" },
    sitemap: process.env.SITE_ORIGIN
      ? `${process.env.SITE_ORIGIN}/sitemap.xml`
      : undefined,
  };
}
