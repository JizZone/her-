import { ArrowIcon } from "@/components/icons/Icons";
import { content } from "@/content";
export default function NotFound() {
  return (
    <main id="main" className="section not-found" tabIndex={-1}>
      <p className="label gold">404</p>
      <h1>{content.notFound.title}</h1>
      <p className="muted">{content.notFound.description}</p>
      <a href="/" data-transition={content.home} className="label">
        {content.notFound.button}
        <ArrowIcon />
      </a>
    </main>
  );
}
