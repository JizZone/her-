import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { content } from "@/content";
import { ProjectDetail } from "@/components/ui/ProjectDetail";
export function generateStaticParams() {
  return content.projects.map(({ slug }) => ({ slug }));
}
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const project = content.projects.find((p) => p.slug === slug);
  return {
    title: `${project?.name ?? content.work.title} — ${content.name}`,
    description: project?.description,
    alternates: { canonical: `/work/${slug}/` },
  };
}
export default async function ProjectPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const index = content.projects.findIndex((p) => p.slug === slug);
  if (index < 0) notFound();
  return (
    <ProjectDetail
      project={content.projects[index]}
      next={content.projects[(index + 1) % content.projects.length]}
    />
  );
}
