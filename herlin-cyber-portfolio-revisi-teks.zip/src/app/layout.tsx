import type { Metadata } from "next";
import localFont from "next/font/local";
import { content } from "@/content";
import { cssTokens } from "@/lib/tokens";
import "./globals.css";
import { Runtime } from "@/components/ui/Runtime";
import { IntroShell } from "@/intro/IntroShell";
import { profile } from "@/content";
import { Header } from "@/components/ui/Header";
import { CyberGate } from "@/cyber/CyberGate";
const fraunces = localFont({
  src: "../../public/fonts/fraunces.woff2",
  variable: "--font-display",
  display: "swap",
  weight: "300 800",
});
const inter = localFont({
  src: "../../public/fonts/inter-tight.woff2",
  variable: "--font-body",
  display: "swap",
  weight: "100 900",
});
export const metadata: Metadata = {
  other: { "contact:email": profile.email },
  title: content.meta.title,
  description: content.meta.description,
  alternates: { canonical: "/" },
  metadataBase: process.env.SITE_ORIGIN
    ? new URL(process.env.SITE_ORIGIN)
    : undefined,
  openGraph: {
    title: content.meta.title,
    description: content.meta.description,
    type: "website",
    images: [
      {
        url: "/images/ton-618.webp",
        width: 1600,
        height: 800,
        alt: "TON 618 — Herlin Aprianti",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    images: ["/images/ton-618.webp"],
    title: content.meta.title,
    description: content.meta.description,
  },
};
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${fraunces.variable} ${inter.variable}`}>
      <head>
        <style>{`:root{${Object.entries(cssTokens)
          .map(([k, v]) => `${k}:${v}`)
          .join(";")}}`}</style>
      </head>
      <body>
        <noscript>
          <style>{`.preloader{display:none!important}.custom-cursor{display:none!important}`}</style>
        </noscript>
        <CyberGate>
          <IntroShell>
            <a className="skip" href="#main">
              {content.skip}
            </a>
            <Runtime />
            <Header />
            {children}
          </IntroShell>
        </CyberGate>
      </body>
    </html>
  );
}
