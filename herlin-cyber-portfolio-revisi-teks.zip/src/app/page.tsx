import { ArrowIcon } from "@/components/icons/Icons";
import { content } from "@/content";
import { Work } from "@/components/ui/Work";
import { Practice } from "@/components/ui/Practice";
import { Contact } from "@/components/ui/Contact";
import { Marquee } from "@/components/ui/Marquee";
import { FallbackHero } from "@/components/ui/FallbackHero";
export default function Home() {
  return (
    <main id="main" tabIndex={-1}>
      <section id="hero" className="hero">
        <FallbackHero />
        <h1 className="sr-only">{content.name}</h1>
        <div className="hero-top label">{content.sectionIndex[0]}</div>
        <div className="hero-bottom">
          <p className="hero-role label">{content.role}</p>
          <p className="hero-tagline">{content.tagline}</p>
          <a className="button hero-cta" href="#work">
            {content.explore}
            <ArrowIcon direction="down" />
          </a>
        </div>
        <a className="scroll-cue" href="#work" aria-label={content.explore}>
          <i />
        </a>
      </section>
      <Work />
      <Marquee text={content.marquee} />
      <Practice />
      <Contact />
    </main>
  );
}
