import type { MetadataRoute } from "next";
import { projects } from "@/content";
export const dynamic = "force-static";
export default function sitemap(): MetadataRoute.Sitemap {
  const origin = process.env.SITE_ORIGIN;
  return origin
    ? [
        { url: origin + "/", priority: 1 },
        ...projects.map((p) => ({
          url: `${origin}/work/${p.slug}/`,
          priority: 0.8,
        })),
      ]
    : [];
}
