"use client";

import { type ReactNode, useEffect, useRef, useState } from "react";
import "./cyber.css";

const enteredKey = "herlin-cyber-entered-v1";
let enteredInThisPage = false;

function hasEntered() {
  if (enteredInThisPage) return true;
  try {
    if (localStorage.getItem(enteredKey) === "1") return true;
  } catch {}
  try {
    return sessionStorage.getItem(enteredKey) === "1";
  } catch {
    return false;
  }
}

function rememberEntry() {
  enteredInThisPage = true;
  try {
    localStorage.setItem(enteredKey, "1");
  } catch {}
  try {
    sessionStorage.setItem(enteredKey, "1");
  } catch {}
}

export function CyberGate({ children }: { children: ReactNode }) {
  const [phase, setPhase] = useState<
    "checking" | "cyber" | "black" | "portfolio"
  >("checking");
  const frame = useRef<HTMLIFrameElement>(null);
  const accepted = useRef(false);

  useEffect(() => {
    setPhase(location.pathname !== "/" || hasEntered() ? "portfolio" : "cyber");
  }, []);

  useEffect(() => {
    if (phase !== "cyber") return;
    const enter = () => {
      if (accepted.current) return;
      accepted.current = true;
      rememberEntry();
      setPhase("black");
    };
    const message = (event: MessageEvent) => {
      if (
        event.origin !== location.origin ||
        event.source !== frame.current?.contentWindow
      )
        return;
      if (event.data?.type === "herlin:cyber-complete") enter();
    };
    const storage = (event: StorageEvent) => {
      if (event.key === enteredKey && event.newValue === "1") enter();
    };
    window.addEventListener("message", message);
    window.addEventListener("storage", storage);
    return () => {
      window.removeEventListener("message", message);
      window.removeEventListener("storage", storage);
    };
  }, [phase]);

  useEffect(() => {
    if (phase !== "black") return;
    let timer = 0;
    const paint = requestAnimationFrame(() => {
      timer = window.setTimeout(() => setPhase("portfolio"), 240);
    });
    return () => {
      cancelAnimationFrame(paint);
      clearTimeout(timer);
    };
  }, [phase]);

  if (phase === "portfolio") return children;

  return (
    <section
      className="cyber-gate"
      data-phase={phase}
      aria-label="Cyber Ronin entrance"
    >
      {phase === "cyber" && (
        <iframe
          ref={frame}
          className="cyber-frame"
          src="/cyber/index.html"
          title="Cyber Ronin — touch Metatron to enter Herlin Aprianti's portfolio"
          allow="autoplay"
        />
      )}
      {phase === "black" && <div className="cyber-black" aria-hidden="true" />}
      <noscript>Enable JavaScript to open this portfolio.</noscript>
    </section>
  );
}
