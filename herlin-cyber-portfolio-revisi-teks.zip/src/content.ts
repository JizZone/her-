export const profile = {
  name: "Herlin Aprianti",
  monogram: "HA",
  role: "Pharmacy · Regulatory · Production",
  tagline: "Precision in every dose. Compliance in every document.",
  email: "herlinaprianti5@gmail.com",
  whatsapp: "{{WA_NUMBER}}",
  instagram: "{{IG_HANDLE}}",
  linkedin: "{{LINKEDIN_URL}}",
  cv: "{{CV_PATH}}",
};
export const isConfigured = (value: string) => !!value && !value.includes("{{");
export const stats: { value: number; suffix: string; label: string }[] = [];
export const practice = {
  title: "Precision, in practice.",
  copy: "My focus sits between regulation, quality and production. Careful documentation and alignment with CPOB connect the requirements on paper with the decisions made on the production floor.",
  detail:
    "I work from source documents to process maps, checking dependencies, clarifying responsibilities and keeping records traceable. The aim is a clear handover from the dossier to the production line.",
  services: [
    "Regulatory Affairs",
    "Quality Assurance",
    "Production & Scale-Up",
    "Documentation & Compliance",
  ],
};
export type DocumentationPhoto = {
  src: string;
  src800: string;
  jpeg: string;
  jpeg800: string;
  alt: string;
  caption: string;
  width: number;
  height: number;
  blurDataURL: string;
};
const documentationPhotos: Record<string, DocumentationPhoto[]> = {
  dossier: [
    {
      src: "/work/dossier/01.webp",
      src800: "/work/dossier/01-800.webp",
      jpeg: "/work/dossier/01.jpg",
      jpeg800: "/work/dossier/01-800.jpg",
      alt: "Documents and a pen beside a desktop computer on an office desk",
      caption:
        "Reference photograph of a document-review workspace. The proposed dossier approach groups source records before BPOM review.",
      width: 1600,
      height: 1067,
      blurDataURL:
        "data:image/webp;base64,UklGRogAAABXRUJQVlA4IHwAAAAwBACdASoUAA0APwFqrE8rJiQiMAgBYCAJZwAFEALU9SDSlfCOGvCYygAA99ww0g5RB+1EpBt4lz6oPffwzTwMZ4IqvAnMONd6ThjigZwZ4kE7T9j9Tji5Tqb7u0CV5i71EY4xYLVMvGEQUeksZS7mO1PNEa+fCewEAAAA",
    },
    {
      src: "/work/dossier/02.webp",
      src800: "/work/dossier/02-800.webp",
      jpeg: "/work/dossier/02.jpg",
      jpeg800: "/work/dossier/02-800.jpg",
      alt: "Hand resting on organised document folders",
      caption:
        "Structured folders make document ownership and version review easier to follow. Reference photograph; no actual submission records are shown.",
      width: 1600,
      height: 2000,
      blurDataURL:
        "data:image/webp;base64,UklGRnIAAABXRUJQVlA4IGYAAACwAwCdASoQABQAPwFqrU6rJiQiMAgBYCAJZQAAQq6JltNliVNzAAD+r3PWk4DrQZ5k9dZ6dN/0/ac53opgFwF0atVA3voVKNl/GtKN5q3rI5UW7hdNTWlz39W/jzfsR9qFpSTRQAA=",
    },
    {
      src: "/work/dossier/03.webp",
      src800: "/work/dossier/03-800.webp",
      jpeg: "/work/dossier/03.jpg",
      jpeg800: "/work/dossier/03-800.jpg",
      alt: "Hand reviewing a printed document with a pen and binder clips",
      caption:
        "Document review connects questions to their source pages. Reference photograph supporting the proposed CTD workflow.",
      width: 1600,
      height: 2000,
      blurDataURL:
        "data:image/webp;base64,UklGRpIAAABXRUJQVlA4IIYAAACQBACdASoQABQAPwForE6rJaQiMAgBYCAJbACdMoR1sCxRBb/cIR+aCnxUpIAA/uknV0H8g2zqbX0Wh+S7iZkGR2w423/NhoHhv+uixW+Bd12clPJuniLKcr06NnUMw6qEsIw27k7JhdR2gyFjWW8scircxZIAuyGEL+XF3b58NQ5ugAAAAA==",
    },
  ],
  "audit-ready": [
    {
      src: "/work/audit-ready/01.webp",
      src800: "/work/audit-ready/01-800.webp",
      jpeg: "/work/audit-ready/01.jpg",
      jpeg800: "/work/audit-ready/01-800.jpg",
      alt: "Hand holding a clipboard checklist during an inventory review",
      caption:
        "A checklist links observations to evidence and follow-up actions. This reference photograph supports the proposed CPOB readiness process.",
      width: 1600,
      height: 1067,
      blurDataURL:
        "data:image/webp;base64,UklGRn4AAABXRUJQVlA4IHIAAACQAwCdASoUAA0APwForE6rJaQiMAgBYCAJZQDCgA9Wlm3s6pcAAPIP+iYXmpVs7OWx5WnQFwzJH9u20HGk8fzMyFYyKvr4+FBqFexEogW/jSQFN96ySeziWGTfsiUrql+96TRN7nTMMxwFhNMdDt4AAAA=",
    },
    {
      src: "/work/audit-ready/02.webp",
      src800: "/work/audit-ready/02-800.webp",
      jpeg: "/work/audit-ready/02.jpg",
      jpeg800: "/work/audit-ready/02-800.jpg",
      alt: "Labelled tubes mounted in a benchtop laboratory rotator",
      caption:
        "Equipment status and identification belong in a traceable readiness review. Reference laboratory equipment, not a claimed production facility.",
      width: 1600,
      height: 2000,
      blurDataURL:
        "data:image/webp;base64,UklGRmYAAABXRUJQVlA4IFoAAACQAwCdASoQABQAPwFqrE6rJiQiMAgBYCAJZwAAUAqaXvvYLyLgAP6ZchkzyHZ+tiYVS9fk8bMugovhb8vrdWJt2LKVOu7L5zx6ZtHfF0IZz+6d15yI8/ONRAA=",
    },
  ],
  "scale-up": [
    {
      src: "/work/scale-up/01.webp",
      src800: "/work/scale-up/01-800.webp",
      jpeg: "/work/scale-up/01.jpg",
      jpeg800: "/work/scale-up/01-800.jpg",
      alt: "Close-up of unbranded oblong tablets",
      caption:
        "Tablet form and material behaviour inform the questions raised during scale-up. Reference photograph; no measured batch or production outcome is claimed.",
      width: 1600,
      height: 1067,
      blurDataURL:
        "data:image/webp;base64,UklGRpIAAABXRUJQVlA4IIYAAADwAwCdASoUAA0APwFqrE8rJiQiMAgBYCAJZQCsEf/jeBcDpvWjWiAAAP6Xdvaw3Fjn1N5OMqIII5D8CKc7JiMgfy5O1YsvT+TTCj3xS0BAeVrWg8bX5Mb998tlpGr3qS3PvgaTa4q3pwZ1m/yCWeURGODQukNkT3UfFhBaUzAjsFkVhRwAAA==",
    },
  ],
  "shelf-life": [
    {
      src: "/work/shelf-life/01.webp",
      src800: "/work/shelf-life/01-800.webp",
      jpeg: "/work/shelf-life/01.jpg",
      jpeg800: "/work/shelf-life/01-800.jpg",
      alt: "Rows of labelled metal laboratory storage drawers",
      caption:
        "Organised storage helps keep samples and their records traceable. Reference photograph; temperature-controlled stability conditions are not established by the image.",
      width: 1600,
      height: 1067,
      blurDataURL:
        "data:image/webp;base64,UklGRmYAAABXRUJQVlA4IFoAAADQAwCdASoUAA0APwForE6rJaQiMAgBYCAJZwAASoX6d/aJSXt4ZUAA/iszyLUDMoDQC6BTQnaIbJBVIATXW4RPG8oyd32/gvO2zINk34bzJy0RisNPMGBwAAA=",
    },
    {
      src: "/work/shelf-life/02.webp",
      src800: "/work/shelf-life/02-800.webp",
      jpeg: "/work/shelf-life/02.jpg",
      jpeg800: "/work/shelf-life/02-800.jpg",
      alt: "Labelled glass sample containers arranged on a laboratory shelf",
      caption:
        "Sample identification connects each container with its source record. Reference photograph supporting a documented stability-study workflow.",
      width: 1600,
      height: 2000,
      blurDataURL:
        "data:image/webp;base64,UklGRmoAAABXRUJQVlA4IF4AAABwAwCdASoQABQAPwFqrE8rJiQiMAgBYCAJQBfJBBgI1EebsHAA/ta8Xr8iEaHb29ln5GMIlR6/tyWHjdqYG0yru1le0gPapcd9k8AHZtU1FJHmkza+iikhr96jgAAA",
    },
    {
      src: "/work/shelf-life/03.webp",
      src800: "/work/shelf-life/03-800.webp",
      jpeg: "/work/shelf-life/03.jpg",
      jpeg800: "/work/shelf-life/03-800.jpg",
      alt: "Blue-capped vials and sampling probe in a chromatograph",
      caption:
        "Analytical instruments support the review of changes over time. Reference photograph; no test result or shelf-life decision is implied.",
      width: 1600,
      height: 2000,
      blurDataURL:
        "data:image/webp;base64,UklGRm4AAABXRUJQVlA4IGIAAAAQBACdASoQABQAPwForE6rJaQiMAgBYCAJZQAAUL4Z68X9r57mS7UQAAD+a7n7icjCNjJAo6Uk6rrZUaFnZ29bw0GgBJACkskXrxK7qdjal8RO/LHjWmJBI++pCKTheOgAAA==",
    },
  ],
};
export const projects = [
  {
    slug: "dossier",
    photos: documentationPhotos["dossier"],
    name: "Dossier",
    number: "01",
    category: "Regulatory Affairs",
    year: "2026",
    description:
      "Preparing a CTD product registration dossier to support an application for izin edar. The proposed workflow connects source documents, ownership and review questions before submission to BPOM.",
    role: "Regulatory documentation",
    scope: "Dossier structure, source review and document control",
    standards: ["CTD", "BPOM"],
    image: "/images/dossier-map.svg",
    alt: "CTD modules connected to a controlled submission dossier",
    blocks: [
      {
        title: "Challenge",
        text: "A product dossier brings together material from different teams and source records. This case study explores how to make that information coherent, traceable and ready for a structured review.",
        image: "/images/dossier-map.svg",
        alt: "CTD structure with five modules feeding a dossier",
        diagram: {
          title: "The dossier architecture",
          caption: "CTD / DOCUMENT STRUCTURE",
          labels: [
            "Administrative",
            "Summaries",
            "Quality",
            "Nonclinical",
            "Clinical",
            "Dossier",
          ],
        },
      },
      {
        title: "Approach",
        text: "Map source documents to the relevant CTD modules and assign a clear owner to each item. Use version control and a review log to identify gaps before assembling the submission package.",
        image: "/images/dossier-flow.svg",
        alt: "Source, review and approval steps in a document workflow",
        diagram: {
          title: "One controlled review path",
          caption: "DOCUMENT CONTROL",
          labels: [
            "Source record",
            "Review",
            "Resolve gaps",
            "Approve",
            "Controlled copy",
          ],
        },
      },
      {
        title: "Outcome",
        text: "The proposed structure makes document dependencies and open questions easier to inspect. A consistent handover package supports the next review stage without implying that regulatory approval has been granted.",
        image: "/images/dossier-register.svg",
        alt: "Document register with ownership, review and revision columns",
        diagram: {
          title: "A traceable handover",
          caption: "REVIEW REGISTER",
          labels: [
            "Document",
            "Owner",
            "Review",
            "Revision",
            "Quality summary",
            "Product record",
            "Supporting data",
          ],
        },
      },
    ],
  },
  {
    slug: "audit-ready",
    photos: documentationPhotos["audit-ready"],
    name: "Audit Ready",
    number: "02",
    category: "Quality Assurance",
    year: "2025",
    description:
      "Preparing a solid dosage production line for a CPOB audit through documents, rooms and workflow. This proposed readiness review connects observations to evidence, ownership and follow-up actions.",
    role: "Quality readiness review",
    scope: "Readiness mapping, record checks and follow-up planning",
    standards: ["CPOB", "Quality systems"],
    image: "/images/audit-ready-map.svg",
    alt: "Document, facility and workflow checks connected to audit readiness",
    blocks: [
      {
        title: "Challenge",
        text: "Audit readiness depends on alignment between written procedures and daily practice. This case study considers how gaps in records, room status and movement flows can be made visible before a formal review.",
        image: "/images/audit-ready-map.svg",
        alt: "Three connected areas of CPOB readiness",
        diagram: {
          title: "Readiness, from every angle",
          caption: "CPOB / READINESS MAP",
          labels: ["Documents", "Rooms", "Workflow", "Audit readiness"],
        },
      },
      {
        title: "Approach",
        text: "Organise a walkthrough around document status, room use and the movement of people and materials. Record observations with an owner and a follow-up action, then review the supporting evidence together.",
        image: "/images/audit-ready-flow.svg",
        alt: "Separation of material movement, process checks and records",
        diagram: {
          title: "Follow the process",
          caption: "WALKTHROUGH SEQUENCE",
          labels: [
            "Material entry",
            "Room status",
            "Line checks",
            "Record review",
            "Follow-up",
          ],
        },
      },
      {
        title: "Outcome",
        text: "The proposed checklist connects each observation to a practical next step. It gives a review team a clearer picture of readiness while keeping unresolved items visible.",
        image: "/images/audit-ready-register.svg",
        alt: "Readiness checklist covering procedures, line status and training",
        diagram: {
          title: "Evidence before assurance",
          caption: "READINESS CHECKLIST",
          labels: [
            "Review area",
            "Evidence",
            "Status",
            "Owner",
            "Procedures",
            "Line status",
            "Training records",
          ],
        },
      },
    ],
  },
  {
    slug: "scale-up",
    photos: documentationPhotos["scale-up"],
    name: "Scale-Up",
    number: "03",
    category: "Production",
    year: "2025",
    description:
      "Planning technology transfer and tablet batch scale-up from the laboratory to production. The proposed transfer record makes equipment differences and parameters explicit before a batch decision.",
    role: "Production transfer planning",
    scope: "Process mapping, parameter review and transfer records",
    standards: ["CPOB", "Technology transfer"],
    image: "/images/scale-up-map.svg",
    alt: "Laboratory, pilot and production stages of tablet scale-up",
    blocks: [
      {
        title: "Challenge",
        text: "A process that works at laboratory scale needs careful review before moving to production equipment. This case study examines how material behaviour, equipment differences and documentation affect that handover.",
        image: "/images/scale-up-map.svg",
        alt: "A progression from laboratory through pilot to production scale",
        diagram: {
          title: "A considered change of scale",
          caption: "TECHNOLOGY TRANSFER",
          labels: ["Laboratory", "Pilot", "Production", "Transfer review"],
        },
      },
      {
        title: "Approach",
        text: "Map the tablet process and compare the operating principles of each equipment set. Identify the parameters that need review and capture the rationale, responsibilities and observations in a transfer plan.",
        image: "/images/scale-up-flow.svg",
        alt: "Material preparation, blending, compression and review sequence",
        diagram: {
          title: "From material to tablet",
          caption: "PROCESS MAP",
          labels: [
            "Preparation",
            "Blending",
            "Compression",
            "In-process review",
            "Batch record",
          ],
        },
      },
      {
        title: "Outcome",
        text: "The proposed transfer record creates a shared basis for discussion between development and production. It keeps assumptions and open actions explicit before any batch or validation decision.",
        image: "/images/scale-up-register.svg",
        alt: "Transfer matrix comparing equipment, parameters and records",
        diagram: {
          title: "Keep the rationale connected",
          caption: "TRANSFER MATRIX",
          labels: [
            "Transfer item",
            "Lab",
            "Production",
            "Review",
            "Equipment",
            "Parameters",
            "Batch records",
          ],
        },
      },
    ],
  },
  {
    slug: "shelf-life",
    photos: documentationPhotos["shelf-life"],
    name: "Shelf Life",
    number: "04",
    category: "Quality Control",
    year: "2024",
    description:
      "Planning stability studies to support the evaluation of shelf life for a liquid dosage product. The proposed study plan connects sampling, storage and analytical records without claiming an expiry decision.",
    role: "Stability documentation",
    scope: "Study planning, data review and trend interpretation",
    standards: ["Stability studies", "Quality control"],
    image: "/images/shelf-life-map.svg",
    alt: "Study conditions connected to sampling and quality review",
    blocks: [
      {
        title: "Challenge",
        text: "Shelf-life decisions depend on a well-defined study and reliable quality data over time. This case study explores how to organise conditions, sampling and records for a liquid dosage product.",
        image: "/images/shelf-life-map.svg",
        alt: "Study conditions, samples and quality attributes in a stability plan",
        diagram: {
          title: "Design the study first",
          caption: "STABILITY PLAN",
          labels: [
            "Conditions",
            "Samples",
            "Quality attributes",
            "Study protocol",
          ],
        },
      },
      {
        title: "Approach",
        text: "Define the study schedule, sample handling and quality attributes before reviewing trends. Keep observations linked to their source records and assess any change in the context of the agreed protocol.",
        image: "/images/shelf-life-flow.svg",
        alt: "Qualitative stability trend with no measured data or numerical claims",
        diagram: {
          title: "Read the pattern over time",
          caption: "SCHEMATIC / NO MEASURED DATA",
          labels: [
            "Quality attribute",
            "Study time",
            "Review window",
            "Trend review",
          ],
        },
      },
      {
        title: "Outcome",
        text: "A structured study record supports a clearer discussion of product behaviour and remaining evidence needs. No shelf life or acceptance decision is claimed here; those require actual study data and an appropriate review.",
        image: "/images/shelf-life-register.svg",
        alt: "Stability review register linking observations and source records",
        diagram: {
          title: "A documented interpretation",
          caption: "STUDY REVIEW",
          labels: [
            "Review item",
            "Source",
            "Trend",
            "Action",
            "Appearance",
            "Quality data",
            "Packaging",
          ],
        },
      },
    ],
  },
];
export const content = {
  meta: {
    title: "Herlin Aprianti — Pharmacy, Regulatory & Production",
    description:
      "Herlin Aprianti’s focus across pharmacy, regulatory documentation, quality and production. Explore four pharmaceutical case studies and a precision-led practice.",
    imageAlt: "TON 618 inspired accretion disk in bone and gold",
  },
  name: profile.name,
  firstName: "Herlin",
  lastName: "Aprianti",
  monogram: profile.monogram,
  year: "2026",
  role: profile.role,
  tagline: profile.tagline,
  explore: "Explore selected work",
  home: "Introduction",
  menu: "Menu",
  close: "Close",
  back: "All projects",
  view: "VIEW",
  skip: "Skip to content",
  loading: "Loading",
  objectLabel: "TON 618",
  sectionIndex: [
    "01 / Introduction",
    "02 / Selected work",
    "03 / The practice",
    "04 / Contact",
  ],
  nav: [
    { label: "Selected work", href: "/#work" },
    { label: "The practice", href: "/#practice" },
    { label: "Contact", href: "/#contact" },
  ],
  notFound: {
    title: "A different direction.",
    description: "This page is unavailable. Return to the selected work.",
    button: "All projects",
  },
  work: {
    title: "Selected work",
    intro:
      "Four case studies across the path from regulatory documents to pharmaceutical production.",
    explore: "Explore case study",
    index: "Project",
    category: "Discipline",
    year: "Year",
  },
  projects,
  practice,
  stats,
  marquee: ["REGULATORY", "QUALITY", "PRODUCTION"],
  contact: {
    title: "Let’s connect.",
    emailLabel: "Email",
    copy: "Copy email",
    copied: "Copied",
    failed: "Select and copy the address",
    unavailable: "Contact details to be added.",
    unavailableLabel: "Contact detail not yet provided",
    download: "Download CV",
    socials: [
      {
        name: "WhatsApp",
        key: "whatsapp",
        value: profile.whatsapp,
        href: `https://wa.me/${profile.whatsapp}`,
      },
      {
        name: "Instagram",
        key: "instagram",
        value: profile.instagram,
        href: `https://instagram.com/${profile.instagram}`,
      },
      {
        name: "LinkedIn",
        key: "linkedin",
        value: profile.linkedin,
        href: profile.linkedin,
      },
    ],
  },
  footer: { copyright: "© 2026 Herlin Aprianti", top: "Back to top" },
  documentation: {
    title: "Documentation",
    view: "View documentation",
    close: "Close",
    previous: "Previous photo",
    next: "Next photo",
    photo: "Photo",
    thumbnails: "Choose a documentation photo",
    note: "Reference imagery for this independent case study.",
    unavailable: "This image could not be loaded.",
  },
  detail: {
    role: "Role",
    scope: "Scope",
    standards: "Standards / Regulation",
    year: "Year",
    next: "Next project",
    all: "All projects",
    note: "Independent case study. A proposed approach, without client or employment claims.",
  },
};
export type Project = (typeof projects)[number];
