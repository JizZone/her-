export const sceneState = {
  center: { x: 0.62, y: 0.52 },
  scale: 1,
  anchors: {
    work: Infinity,
    practice: Infinity,
    practiceCenter: Infinity,
    contact: Infinity,
    contactCenter: Infinity,
  },
  width: 1440,
  height: 900,
};
export function refreshSceneAnchors() {
  const top = (id: string) => {
    const el = document.getElementById(id);
    return el ? el.getBoundingClientRect().top + window.scrollY : Infinity;
  };
  const middle = (selector: string) => {
    const el = document.querySelector(selector);
    if (!el) return Infinity;
    const r = el.getBoundingClientRect();
    return r.top + window.scrollY + r.height / 2;
  };
  sceneState.width = window.innerWidth;
  sceneState.height = window.innerHeight;
  sceneState.anchors = {
    work: top("work"),
    practice: top("practice"),
    practiceCenter: middle(".practice-object"),
    contact: top("contact"),
    contactCenter: middle(".contact-object"),
  };
}
