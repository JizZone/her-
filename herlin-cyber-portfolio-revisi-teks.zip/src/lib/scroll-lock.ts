import { lenis } from "./lenis";
const owners = new Set<string>();
let previous = "";
export function lockScroll(owner: string) {
  if (!owners.size) previous = document.documentElement.style.overflow;
  owners.add(owner);
  document.documentElement.style.overflow = "hidden";
  document.documentElement.dataset.scrollLocked = "true";
  lenis?.stop();
}
export function unlockScroll(owner: string) {
  owners.delete(owner);
  if (owners.size) return;
  document.documentElement.style.overflow = previous;
  delete document.documentElement.dataset.scrollLocked;
  lenis?.start();
}
