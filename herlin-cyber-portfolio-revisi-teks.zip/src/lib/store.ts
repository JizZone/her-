import { create } from "zustand";
export type CursorState = "default" | "link" | "project" | "text";
export type Quality = "high" | "medium" | "low";
interface State {
  scrollProgress: number;
  scrollY: number;
  velocity: number;
  section: string;
  mouse: { x: number; y: number; px: number; py: number; speed: number };
  cursorState: CursorState;
  isTransitioning: boolean;
  transition: number;
  loaded: boolean;
  intro: number;
  introPhase: "pending" | "loading" | "entering" | "ready";
  introProgress: number;
  rendererChecked: boolean;
  frameReady: boolean;
  introLens: number;
  nameReveal: number;
  viewerOpen: boolean;
  sceneReady: boolean;
  reducedMotion: boolean;
  mobile: boolean;
  visible: boolean;
  canvasActive: boolean;
  webgl: boolean;
  quality: Quality;
  softwareRenderer: boolean;
  menuOpen: boolean;
  hoverProject: number | null;
  detail: boolean;
  bulgeTarget: HTMLElement | null;
}
export const useStore = create<State>(() => ({
  scrollProgress: 0,
  scrollY: 0,
  velocity: 0,
  section: "hero",
  mouse: { x: 0, y: 0, px: 0, py: 0, speed: 0 },
  cursorState: "default",
  isTransitioning: false,
  transition: 0,
  loaded: false,
  intro: 0,
  introPhase: "pending",
  introProgress: 0,
  rendererChecked: false,
  frameReady: false,
  introLens: 1,
  nameReveal: 0,
  viewerOpen: false,
  sceneReady: false,
  reducedMotion: false,
  mobile: false,
  visible: true,
  canvasActive: true,
  webgl: false,
  quality: "high",
  softwareRenderer: false,
  menuOpen: false,
  hoverProject: null,
  detail: false,
  bulgeTarget: null,
}));
export const set = useStore.setState;
