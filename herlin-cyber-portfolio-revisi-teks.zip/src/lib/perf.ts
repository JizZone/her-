import { set, useStore, type Quality } from "./store";
const levels: Quality[] = ["high", "medium", "low"];
export function lowerQuality() {
  set({
    quality:
      levels[Math.min(levels.indexOf(useStore.getState().quality) + 1, 2)],
  });
}
export function raiseQuality() {
  const s = useStore.getState();
  if (s.softwareRenderer) return;
  set({
    quality: levels[Math.max(s.mobile ? 1 : 0, levels.indexOf(s.quality) - 1)],
  });
}
export function qualitySettings(tier: Quality) {
  return {
    dpr: tier === "high" ? 1.5 : tier === "medium" ? 1.25 : 1,
    postprocessing: tier !== "low",
  };
}
