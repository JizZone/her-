import { Effect } from "postprocessing";
import { Uniform, Vector2 } from "three";
import { TON } from "./ton-scene";
const fragment = `uniform vec2 uCenter;uniform float uStrength,uAspect,uRadius,uLimit,uCapture;void mainUv(inout vec2 uv){vec2 p=(uv-uCenter)*vec2(uAspect,1.);float r=length(p);float influence=1.-smoothstep(uRadius*.65,uRadius,r);float shift=min(uLimit,uStrength/max(r*r,.006))*influence;vec2 direction=p/max(r,.0001);uv=clamp(uv-direction*shift/vec2(uAspect,1.),vec2(.001),vec2(.999));}void mainImage(const in vec4 inputColor,const in vec2 uv,out vec4 outputColor){outputColor=vec4(inputColor.rgb*(1.-uCapture),inputColor.a);}`;
export class HorizonLensing extends Effect {
  constructor() {
    super("HorizonLensing", fragment, {
      uniforms: new Map<string, Uniform>([
        ["uCenter", new Uniform(new Vector2(0.5, 0.5))],
        ["uStrength", new Uniform(TON.lensStrength)],
        ["uAspect", new Uniform(1)],
        ["uRadius", new Uniform(TON.lensRadius)],
        ["uLimit", new Uniform(TON.lensLimit)],
        ["uCapture", new Uniform(0)],
      ]),
    });
  }
  configure(
    center: { x: number; y: number },
    aspect: number,
    strength: number,
    radius: number,
    capture: number,
  ) {
    this.uniforms.get("uCenter")!.value.copy(center);
    this.uniforms.get("uAspect")!.value = aspect;
    this.uniforms.get("uStrength")!.value = strength;
    this.uniforms.get("uRadius")!.value = radius;
    this.uniforms.get("uCapture")!.value = capture;
  }
}
