import * as THREE from "three";
import { T } from "./tokens";
export const TON = {
  radius: 1,
  inner: 1.6,
  outer: 6,
  segments: 160,
  sphereSegments: 40,
  sphereRings: 24,
  tilt: (75 * Math.PI) / 180,
  roll: (-10 * Math.PI) / 180,
  mouseTilt: (8 * Math.PI) / 180,
  photonRadius: 1.055,
  photonTube: 0.012,
  haloSize: 4.8,
  haloDepth: 0.15,
  idle: 0.06,
  turbulence: 0.25,
  hoverBoost: 0.2,
  ignition: 1.4,
  heroX: 0.62,
  heroY: 0.48,
  heroWidth: 0.78,
  mobileX: 0.5,
  mobileY: 0.3,
  mobileWidth: 1.2,
  practiceX: 0.78,
  practiceScale: 0.6,
  workScale: 0.38,
  contactScale: 0.28,
  lensStrength: 0.008,
  lensLimit: 0.026,
  lensRadius: 0.34,
  mobileLensing: 0.35,
  transitionStrength: 4,
  bloom: 0.4,
  bloomMedium: 0.2,
  bloomThreshold: 0.9,
  jetOpacity: 0.055,
  jetLength: 4.4,
  captureWidth: 1600,
  captureHeight: 800,
  captureTime: 2.5,
} as const;
const vertex = `varying vec3 vLocal;void main(){vLocal=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`;
const noise = `
float hash(vec2 p){return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453);}
float noise(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(hash(i),hash(i+vec2(1.,0.)),f.x),mix(hash(i+vec2(0.,1.)),hash(i+vec2(1.,1.)),f.x),f.y);}
float fbm(vec2 p){return .57*noise(p)+.28*noise(p*2.13)+.15*noise(p*4.21);}
`;
const diskFragment = `
uniform float uTime,uInner,uOuter,uIgnition,uTurbulence,uHover;uniform vec3 uBone,uGold;varying vec3 vLocal;
${noise}
void main(){
 float r=length(vLocal.xy),q=clamp((r-uInner)/(uOuter-uInner),0.,1.);
 float phi=atan(vLocal.y,vLocal.x),omega=pow(max(r,.1),-1.5);
 float a=phi-uTime*omega;
 vec2 orbital=vec2(cos(a),sin(a))*r;
 float turbulence=fbm(orbital*4.+uTime*.015);
 float spiral=.74+.26*sin(a*3.-r*5.+turbulence*(1.5+uTurbulence));
 float filaments=.72+.28*sin(r*48.+turbulence*7.+sin(a*4.)*.6);
 float density=spiral*filaments*(.55+.45*turbulence);
 float beam=pow(1.-.32*cos(phi)*sqrt(uInner/r),3.);
 float fade=smoothstep(0.,.06,q)*(1.-smoothstep(.58,1.,q));
 vec3 color=mix(uBone,uGold,smoothstep(.02,.5,q));
 float emission=(2.7*pow(1.-q,2.)+.3)*density*beam*(1.+uHover)*uIgnition;
 gl_FragColor=vec4(color*emission,fade*min(.95,.5+density)*uIgnition);
 #include <tonemapping_fragment>
 #include <colorspace_fragment>
}`;
const haloFragment = `
uniform float uTime,uIgnition,uHover;uniform vec3 uBone,uGold;varying vec3 vLocal;
${noise}
void main(){
 vec2 p=vLocal.xy;float a=atan(p.y,p.x);
 float upper=step(0.,p.y);float r=length(vec2(p.x,p.y*mix(1.14,.86,upper)));
 float ridge=1.25+upper*.16;float thick=mix(.055,.16,upper);
 float band=exp(-pow((r-ridge)/thick,2.));
 float filaments=.65+.35*sin(r*105.+fbm(p*7.+uTime*.03)*5.);
 float wings=(1.-smoothstep(1.6,2.25,abs(p.x)))*smoothstep(.02,.3,abs(p.y));
 float beam=pow(1.-.25*cos(a),3.);
 float light=band*filaments*wings*beam*uIgnition*(1.+uHover);
 vec3 col=mix(uGold,uBone,smoothstep(.4,.85,band));
 gl_FragColor=vec4(col*light*2.4,clamp(light,0.,.88));
 #include <tonemapping_fragment>
 #include <colorspace_fragment>
}`;
const glowFragment = `uniform vec3 uGold;uniform float uIgnition;varying vec3 vLocal;void main(){float r=length(vLocal.xy);float glow=exp(-pow((r-1.13)/.19,2.))*.12*uIgnition;gl_FragColor=vec4(uGold,glow);}`;
export function createTonScene(high = true) {
  const group = new THREE.Group();
  group.name = "TON618";
  const uniforms = {
    uTime: { value: 0 },
    uInner: { value: TON.inner },
    uOuter: { value: TON.outer },
    uIgnition: { value: 0 },
    uTurbulence: { value: 0 },
    uHover: { value: 0 },
    uBone: { value: new THREE.Color(T.color.bone) },
    uGold: { value: new THREE.Color(T.color.gold) },
  };
  const eventHorizon = new THREE.Mesh(
    new THREE.SphereGeometry(TON.radius, TON.sphereSegments, TON.sphereRings),
    new THREE.MeshBasicMaterial({ color: 0x000000 }),
  );
  eventHorizon.name = "EventHorizon";
  group.add(eventHorizon);
  const diskMaterial = new THREE.ShaderMaterial({
    uniforms,
    vertexShader: vertex,
    fragmentShader: diskFragment,
    side: THREE.DoubleSide,
    transparent: true,
    depthWrite: false,
  });
  const disk = new THREE.Mesh(
    new THREE.RingGeometry(TON.inner, TON.outer, TON.segments, 1),
    diskMaterial,
  );
  disk.name = "AccretionDisk";
  disk.rotation.set(TON.tilt, 0, TON.roll);
  group.add(disk);
  const photonMaterial = new THREE.MeshBasicMaterial({
    color: new THREE.Color(T.color.bone).multiplyScalar(2.5),
    transparent: true,
    opacity: 0,
    toneMapped: false,
  });
  const photon = new THREE.Mesh(
    new THREE.TorusGeometry(TON.photonRadius, TON.photonTube, 8, TON.segments),
    photonMaterial,
  );
  photon.name = "PhotonRing";
  photon.position.z = 0.05;
  group.add(photon);
  const haloMaterial = new THREE.ShaderMaterial({
    uniforms,
    vertexShader: vertex,
    fragmentShader: haloFragment,
    side: THREE.DoubleSide,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const halo = new THREE.Mesh(
    new THREE.PlaneGeometry(TON.haloSize, TON.haloSize),
    haloMaterial,
  );
  halo.name = "LensedHalo";
  halo.position.z = TON.haloDepth;
  group.add(halo);
  const glowMaterial = new THREE.ShaderMaterial({
    uniforms,
    vertexShader: vertex,
    fragmentShader: glowFragment,
    transparent: true,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  const glow = new THREE.Mesh(
    new THREE.PlaneGeometry(TON.haloSize, TON.haloSize),
    glowMaterial,
  );
  glow.position.z = -0.05;
  group.add(glow);
  const jets = new THREE.Group();
  jets.name = "Jets";
  jets.visible = high;
  const jetMaterial = new THREE.MeshBasicMaterial({
    color: new THREE.Color(T.color.gold).multiplyScalar(1.8),
    transparent: true,
    opacity: 0,
    depthWrite: false,
    blending: THREE.AdditiveBlending,
  });
  for (const sign of [-1, 1]) {
    const jet = new THREE.Mesh(
      new THREE.CylinderGeometry(0.006, 0.022, TON.jetLength, 6),
      jetMaterial,
    );
    jet.position.y = sign * (TON.jetLength / 2 + 1);
    jets.add(jet);
  }
  jets.rotation.z = TON.roll;
  group.add(jets);
  return {
    group,
    update(
      time: number,
      intro: number,
      turbulence = 0,
      hover = 0,
      tiltX = 0,
      tiltY = 0,
    ) {
      uniforms.uTime.value = time;
      uniforms.uIgnition.value = intro;
      uniforms.uTurbulence.value = turbulence;
      uniforms.uHover.value = hover;
      photonMaterial.opacity = intro * 0.85;
      jetMaterial.opacity = intro * TON.jetOpacity;
      disk.rotation.x = TON.tilt + tiltY;
      disk.rotation.y = tiltX;
      disk.rotation.z = TON.roll;
      halo.rotation.z = tiltX * 0.3;
    },
    dispose() {
      group.traverse((obj) => {
        if (obj instanceof THREE.Mesh) {
          obj.geometry.dispose();
          const mats = Array.isArray(obj.material)
            ? obj.material
            : [obj.material];
          mats.forEach((m) => m.dispose());
        }
      });
    },
  };
}
