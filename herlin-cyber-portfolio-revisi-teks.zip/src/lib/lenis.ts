import Lenis from "lenis";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { sceneState } from "./scene-state";
import { T } from "./tokens";
import { set, useStore } from "./store";
export let lenis: Lenis | undefined;
export function startScroll() {
  gsap.registerPlugin(ScrollTrigger);
  lenis = new Lenis({
    lerp: T.motion.scrollLerp,
    smoothWheel: !useStore.getState().reducedMotion,
    anchors: true,
    syncTouch: false,
  });
  if (document.documentElement.dataset.scrollLocked) lenis.stop();
  const update = (e: Lenis) => {
    set({
      scrollProgress: e.progress,
      scrollY: e.scroll,
      velocity: e.velocity,
    });
    const a = sceneState.anchors,
      h = sceneState.height;
    const canvasActive =
      e.scroll < h || (e.scroll + h > a.practice && e.scroll < a.contact + h);
    if (canvasActive !== useStore.getState().canvasActive)
      set({ canvasActive });
    ScrollTrigger.update();
  };
  lenis.on("scroll", update);
  const tick = (t: number) => {
    if (useStore.getState().visible) lenis?.raf(t * T.number.ms);
  };
  gsap.ticker.add(tick);
  gsap.ticker.lagSmoothing(0);
  return () => {
    gsap.ticker.remove(tick);
    lenis?.off("scroll", update);
    lenis?.destroy();
    lenis = undefined;
  };
}
