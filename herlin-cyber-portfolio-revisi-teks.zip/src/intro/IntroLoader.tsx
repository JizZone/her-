"use client";
import { useLayoutEffect, useRef, type CSSProperties } from "react";
import { usePathname } from "next/navigation";
import { content } from "@/content";
import { gsap } from "gsap";
import { set, useStore } from "@/lib/store";
import { T } from "@/lib/tokens";
import { completeIntro, useIntro } from "./useIntro";
import "./intro.css";
export function IntroLoader() {
  const root = useRef<HTMLDivElement>(null);
  const { phase } = useIntro();
  const pathname = usePathname();
  const count = useStore((s) => s.introProgress);
  const reduced = useStore((s) => s.reducedMotion);
  useLayoutEffect(() => {
    if (phase !== "entering" || !root.current) return;
    const el = root.current;
    const shell = document.getElementById("site-shell");
    if (!shell) return;
    const finish = () => {
      gsap.set(shell, { clearProps: "clipPath" });
      completeIntro();
    };
    const timeline = gsap.timeline({ onComplete: finish });
    if (reduced) {
      gsap.set(shell, { clipPath: "none" });
      timeline.to(el, { opacity: 0, duration: T.dur.micro });
      return () => {
        timeline.kill();
      };
    }
    const state = { light: 0, lens: 3, name: 0 };
    const letters = shell.querySelectorAll(".hero-letter");
    const nav = shell.querySelector(".header");
    const labels = shell.querySelectorAll(
      ".hero-top,.hero-role,.hero-tagline,.hero-cta",
    );
    const ring = el.querySelector(".intro-horizon");
    gsap.set(shell, { clipPath: "circle(0% at 50% 50%)" });
    gsap.set(el, { backgroundColor: "transparent" });
    gsap.set(letters, {
      yPercent: 110,
      rotateX: 70,
      transformOrigin: "50% 100%",
    });
    gsap.set(nav, { yPercent: -110 });
    gsap.set(labels, { y: 32, opacity: 0 });
    gsap.set(".scroll-cue i", { scaleY: 0, transformOrigin: "top" });
    gsap.set(ring, {
      width: "300vmax",
      height: "300vmax",
      xPercent: -50,
      yPercent: -50,
      scale: 0,
      opacity: 0,
    });
    set({ introLens: 3 });
    timeline
      .set(
        el.querySelectorAll(".intro-digit-track,.intro-progress i"),
        { transition: "none" },
        0,
      )
      .to(
        el.querySelectorAll(".intro-exit,.intro-monogram,.intro-progress"),
        {
          yPercent: -110,
          opacity: 0,
          duration: T.intro.exit,
          ease: T.ease.inout,
        },
        T.intro.exitAt,
      )
      .to(
        shell,
        {
          clipPath: "circle(150% at 50% 50%)",
          duration: T.intro.horizon,
          ease: T.ease.inout,
        },
        T.intro.horizonAt,
      )
      .set(ring, { opacity: 1 }, T.intro.horizonAt)
      .to(
        ring,
        { scale: 1, duration: T.intro.horizon, ease: T.ease.inout },
        T.intro.horizonAt,
      )
      .to(
        state,
        {
          light: 1,
          lens: 1,
          duration: T.intro.scene,
          ease: T.ease.out,
          onUpdate: () => set({ intro: state.light, introLens: state.lens }),
        },
        T.intro.sceneAt,
      )
      .to(
        letters,
        {
          yPercent: 0,
          rotateX: 0,
          duration: T.intro.name,
          stagger: T.stagger.char,
          ease: T.ease.out,
        },
        T.intro.nameAt,
      )
      .to(
        state,
        {
          name: 1,
          duration: T.intro.name + (letters.length - 1) * T.stagger.char,
          ease: "none",
          onUpdate: () => set({ nameReveal: state.name }),
        },
        T.intro.nameAt,
      )
      .to(
        nav,
        { yPercent: 0, duration: T.intro.nav, ease: T.ease.out },
        T.intro.navAt,
      )
      .to(
        labels,
        {
          y: 0,
          opacity: 1,
          duration: T.intro.nav,
          stagger: T.stagger.char,
          ease: T.ease.out,
        },
        T.intro.navAt,
      )
      .to(
        ".scroll-cue i",
        { scaleY: 1, duration: T.intro.nav, ease: T.ease.out },
        T.intro.navAt,
      )
      .set(ring, { opacity: 0 }, T.intro.total)
      .call(() => {}, [], T.intro.total);
    return () => {
      timeline.kill();
    };
  }, [phase, reduced]);
  if (pathname !== "/" || phase === "ready") return null;
  return (
    <div
      ref={root}
      className="intro-loader"
      data-phase={phase}
      style={
        {
          "--intro-digit": `${T.intro.digit}s`,
          "--intro-ring": `${T.intro.ring}s`,
        } as CSSProperties
      }
    >
      <svg
        className="intro-monogram"
        viewBox="0 0 84 44"
        fill="none"
        aria-label={content.monogram}
        role="img"
      >
        <path
          d="M4 3v38M29 3v38M4 22h25M40 41 58 3l18 38M47 27h23"
          stroke="currentColor"
          strokeWidth="2"
        />
      </svg>
      <div
        className="intro-center"
        role="progressbar"
        aria-label={content.loading}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-valuenow={count}
      >
        <div className="intro-mask">
          <div className="intro-exit">
            <span className="intro-ring" />
          </div>
        </div>
        <div className="intro-mask">
          <div className="intro-count intro-exit" aria-hidden="true">
            {reduced
              ? count
              : String(count)
                  .padStart(3, "0")
                  .split("")
                  .map((digit, index) => (
                    <span className="intro-digit" key={index}>
                      <span
                        className="intro-digit-track"
                        style={{
                          transform: `translateY(-${Number(digit) * 10}%)`,
                        }}
                      >
                        {Array.from({ length: 10 }, (_, n) => (
                          <span key={n}>{n}</span>
                        ))}
                      </span>
                    </span>
                  ))}
            <span className="intro-percent">%</span>
          </div>
        </div>
        <div className="intro-progress">
          <i style={{ transform: `scaleX(${count / 100})` }} />
        </div>
      </div>
      <div className="intro-horizon" />
    </div>
  );
}
