"use client";
import { useEffect, useRef } from "react";
import { usePathname } from "next/navigation";
import { useProgress } from "@react-three/drei";
import { set, useStore } from "@/lib/store";
import { T } from "@/lib/tokens";
import { lockScroll, unlockScroll } from "@/lib/scroll-lock";
const sessionKey = "herlin-intro-v2";
export function completeIntro() {
  try {
    sessionStorage.setItem(sessionKey, "seen");
  } catch {}
  set({
    introPhase: "ready",
    introProgress: 100,
    loaded: true,
    intro: 1,
    nameReveal: 1,
    introLens: 1,
  });
  unlockScroll("intro");
}
export function useIntro() {
  const pathname = usePathname();
  const previousPath = useRef<string | null>(null);
  const progress = useProgress((s) => s.progress);
  useEffect(() => {
    const internalVisit =
      previousPath.current !== null && previousPath.current !== pathname;
    previousPath.current = pathname;
    let seen = false;
    try {
      seen = sessionStorage.getItem(sessionKey) === "seen";
    } catch {}
    const force = new URLSearchParams(location.search).get("intro") === "1";
    if (pathname !== "/" || ((seen || internalVisit) && !force)) {
      if (pathname === "/") {
        try {
          sessionStorage.setItem(sessionKey, "seen");
        } catch {}
      }
      set({ introPhase: "ready", loaded: true, intro: 1, nameReveal: 1 });
      unlockScroll("intro");
      return;
    }
    set({
      introPhase: "loading",
      introProgress: 0,
      loaded: false,
      intro: 0,
      nameReveal: 0,
    });
    lockScroll("intro");
    const start = performance.now();
    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    let disposed = false,
      fonts = false,
      image = false,
      raf = 0;
    document.fonts.ready.then(() => {
      fonts = true;
    });
    const critical = new Image();
    critical.src = "/images/ton-618.webp";
    critical
      .decode()
      .then(() => {
        image = true;
      })
      .catch(() => {
        image = false;
      });
    const tick = () => {
      if (disposed) return;
      const state = useStore.getState();
      const age = (performance.now() - start) / T.number.ms;
      const scene =
        state.rendererChecked &&
        (!state.webgl || (state.sceneReady && state.frameReady));
      const loader = useProgress.getState();
      const loaded = loader.total
        ? Math.min(loader.loaded / loader.total, 1)
        : 0;
      const real = Math.floor(
        (fonts ? 35 : 0) + (image ? 35 : 0) + (scene ? 30 : 20 * loaded),
      );
      if (real > state.introProgress)
        set({ introProgress: Math.min(real, 99) });
      const deadline = age >= (reduce ? T.intro.reduced : T.intro.maximum);
      if (deadline || (fonts && image && scene && age >= T.intro.minimum)) {
        if (deadline || !scene || reduce)
          set({ webgl: false, sceneReady: true });
        set({ introProgress: 100, introPhase: "entering" });
        return;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => {
      disposed = true;
      cancelAnimationFrame(raf);
      unlockScroll("intro");
    };
  }, [pathname]);
  return { progress, phase: useStore((s) => s.introPhase) };
}
