"use client";
import { usePathname } from "next/navigation";
import { type ReactNode } from "react";
import { useStore } from "@/lib/store";
import { IntroLoader } from "./IntroLoader";
export function IntroShell({ children }: { children: ReactNode }) {
  const phase = useStore((s) => s.introPhase);
  const pathname = usePathname();
  const overlay = useStore((s) => s.viewerOpen || s.isTransitioning);
  const introLocked = pathname === "/" && phase !== "ready";
  const locked = introLocked || overlay;
  const hidden = introLocked && phase !== "entering";
  return (
    <>
      <IntroLoader />
      <div
        id="site-shell"
        data-intro={hidden ? "loading" : locked ? "entering" : "ready"}
        inert={locked}
        aria-hidden={locked ? true : undefined}
        style={{
          visibility: hidden ? "hidden" : undefined,
          pointerEvents: locked ? "none" : undefined,
        }}
      >
        {children}
      </div>
    </>
  );
}
