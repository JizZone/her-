"use client";
import { useEffect, useRef } from "react";
import { usePathname } from "next/navigation";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { refreshSceneAnchors } from "@/lib/scene-state";
import { startScroll } from "@/lib/lenis";
import { useStore } from "@/lib/store";
import { T } from "@/lib/tokens";
export function ScrollSystem() {
  const pathname = usePathname();
  const reduced = useStore((s) => s.reducedMotion);
  const progress = useStore((s) =>
    Math.round(s.scrollProgress * T.number.percent),
  );
  useEffect(() => {
    ScrollTrigger.addEventListener("refresh", refreshSceneAnchors);
    const cleanup = startScroll();
    return () => {
      cleanup();
      ScrollTrigger.removeEventListener("refresh", refreshSceneAnchors);
    };
  }, [reduced]);
  useEffect(() => {
    const timer = setTimeout(
      () => ScrollTrigger.refresh(),
      T.dur.base * T.number.ms,
    );
    return () => clearTimeout(timer);
  }, [pathname]);
  return (
    <div className="scroll-indicator label" aria-hidden="true">
      <div>
        <i style={{ transform: `scaleY(${progress / T.number.percent})` }} />
      </div>
    </div>
  );
}
