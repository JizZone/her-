"use client";
import { content } from "@/content";
import { useStore } from "@/lib/store";
export function FallbackHero() {
  const ready = useStore((s) => s.webgl && s.sceneReady);
  return (
    <div
      className={`fallback-hero ${ready ? "scene-visible" : ""}`}
      aria-hidden="true"
    >
      <img
        className="hero-snapshot"
        src="/images/ton-618.webp"
        alt=""
        width="1600"
        height="800"
        fetchPriority="high"
      />
      <div className="fallback-name">
        {[content.firstName, content.lastName].map((line) => (
          <span key={line}>
            {Array.from(line).map((letter, index) => (
              <span className="hero-letter-mask" key={index}>
                <span className="hero-letter">{letter}</span>
              </span>
            ))}
          </span>
        ))}
      </div>
    </div>
  );
}
