"use client";
import dynamic from "next/dynamic";
import { gsap } from "gsap";
import { useEffect } from "react";
import { usePathname } from "next/navigation";
import { CanvasBoundary } from "../canvas/CanvasBoundary";
import { set, useStore } from "@/lib/store";
import { T } from "@/lib/tokens";
import { ScrollSystem } from "./ScrollSystem";
import { Cursor } from "./Cursor";
import { Menu } from "./Menu";
import { TransitionOverlay } from "./TransitionOverlay";
import { refreshSceneAnchors } from "@/lib/scene-state";
import "lenis/dist/lenis.css";
const Experience = dynamic(() => import("../canvas/Experience"), {
  ssr: false,
});
export function Runtime() {
  const webgl = useStore((s) => s.webgl);
  const reduced = useStore((s) => s.reducedMotion);
  const pathname = usePathname();
  useEffect(() => {
    set({ detail: pathname !== "/", canvasActive: true });
    refreshSceneAnchors();
  }, [pathname]);
  useEffect(() => {
    const reduce = matchMedia("(prefers-reduced-motion: reduce)"),
      coarse = matchMedia("(pointer: coarse)");
    let supported = false,
      raf = 0,
      resizeFrame = 0;
    let latest: PointerEvent | null = null,
      last = { x: 0, y: 0 };
    const preferences = () => {
      const mobile = coarse.matches || innerWidth < T.layout.mobile;
      const changed = mobile !== useStore.getState().mobile;
      set({
        reducedMotion: reduce.matches,
        mobile,
        webgl: supported && !reduce.matches,
      });
      if (changed)
        set({
          quality: useStore.getState().softwareRenderer
            ? "low"
            : mobile
              ? "medium"
              : "high",
        });
      if (useStore.getState().rendererChecked && (reduce.matches || !supported))
        set({ sceneReady: true });
      refreshSceneAnchors();
    };
    preferences();
    const probeWebGL = () => {
      const probe = document.createElement("canvas");
      try {
        const gl = probe.getContext("webgl2");
        supported = !!gl;
        const info = gl?.getExtension("WEBGL_debug_renderer_info");
        const renderer = info
          ? String(gl?.getParameter(info.UNMASKED_RENDERER_WEBGL))
          : "";
        const softwareRenderer = /swiftshader|llvmpipe|software/i.test(
          renderer,
        );
        set({
          softwareRenderer,
          quality: softwareRenderer
            ? "low"
            : useStore.getState().mobile
              ? "medium"
              : "high",
        });
        gl?.getExtension("WEBGL_lose_context")?.loseContext();
      } catch {
        supported = false;
      }
    };
    const boot = setTimeout(() => {
      if (!reduce.matches) probeWebGL();
      set({ sceneReady: !supported, rendererChecked: true });
      preferences();
    }, T.dur.micro * T.number.ms);
    const motionPreference = () => {
      if (!reduce.matches && !supported) probeWebGL();
      preferences();
    };
    const pointer = (e: PointerEvent) => {
      if (e.pointerType === "touch" && !e.buttons) return;
      latest = e;
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        if (!latest) return;
        const e = latest;
        set({
          mouse: {
            x: (e.clientX / innerWidth) * 2 - 1,
            y: 1 - (e.clientY / innerHeight) * 2,
            px: e.clientX,
            py: e.clientY,
            speed: Math.min(
              Math.hypot(e.clientX - last.x, e.clientY - last.y),
              T.motion.velocityCap,
            ),
          },
        });
        last = { x: e.clientX, y: e.clientY };
      });
    };
    const release = (e: PointerEvent) => {
      if (e.pointerType === "touch")
        set({ mouse: { ...useStore.getState().mouse, x: 0, y: 0, speed: 0 } });
    };
    const resize = () => {
      if (resizeFrame) return;
      resizeFrame = requestAnimationFrame(() => {
        resizeFrame = 0;
        preferences();
      });
    };
    const visibility = () => set({ visible: !document.hidden });
    window.addEventListener("pointermove", pointer, { passive: true });
    window.addEventListener("pointerup", release, { passive: true });
    window.addEventListener("pointercancel", release, { passive: true });
    window.addEventListener("resize", resize, { passive: true });
    document.addEventListener("visibilitychange", visibility);
    reduce.addEventListener("change", motionPreference);
    coarse.addEventListener("change", preferences);
    const decay = () => {
      const s = useStore.getState();
      if (s.visible && s.mouse.speed > 0.001)
        set({ mouse: { ...s.mouse, speed: s.mouse.speed * 0.88 } });
    };
    gsap.ticker.add(decay);
    const deadline = setTimeout(() => {
      if (!useStore.getState().sceneReady)
        set({ webgl: false, sceneReady: true });
    }, T.intro.maximum * T.number.ms);
    document.fonts.ready.then(refreshSceneAnchors);
    return () => {
      clearTimeout(boot);
      clearTimeout(deadline);
      cancelAnimationFrame(raf);
      cancelAnimationFrame(resizeFrame);
      gsap.ticker.remove(decay);
      window.removeEventListener("pointermove", pointer);
      window.removeEventListener("pointerup", release);
      window.removeEventListener("pointercancel", release);
      window.removeEventListener("resize", resize);
      document.removeEventListener("visibilitychange", visibility);
      reduce.removeEventListener("change", motionPreference);
      coarse.removeEventListener("change", preferences);
    };
  }, []);
  return (
    <>
      {webgl && !reduced && (
        <CanvasBoundary>
          <Experience />
        </CanvasBoundary>
      )}
      <ScrollSystem />
      <Cursor />
      <Menu />
      <TransitionOverlay />
    </>
  );
}
