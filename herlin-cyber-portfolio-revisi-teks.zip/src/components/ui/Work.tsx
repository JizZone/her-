"use client";
import { ArrowIcon } from "../icons/Icons";
import { content } from "@/content";
import { set, useStore } from "@/lib/store";
import { SplitReveal } from "./SplitReveal";
export function Work() {
  const mobile = useStore((s) => s.mobile);
  return (
    <section id="work" className="section work">
      <div className="section-label label muted">{content.sectionIndex[1]}</div>
      <div className="section-heading">
        <SplitReveal as="h2">{content.work.title}</SplitReveal>
        <p className="lead muted">{content.work.intro}</p>
      </div>
      <div className="project-list">
        {content.projects.map((p, i) => (
          <a
            key={p.slug}
            className="project-row"
            href={`/work/${p.slug}/`}
            data-transition={p.name}
            data-cursor="project"
            onPointerEnter={() => {
              if (!mobile) set({ hoverProject: i });
            }}
            onPointerLeave={() => set({ hoverProject: null })}
            onFocus={() => set({ hoverProject: i })}
            onBlur={() => set({ hoverProject: null })}
          >
            <span className="project-number label gold">{p.number}</span>
            <h3 className="project-title">{p.name}</h3>
            <span className="project-category label muted">{p.category}</span>
            <span className="project-year label muted">{p.year}</span>
            <span className="project-arrow">
              <ArrowIcon />
            </span>
            <img
              className="project-preview"
              src={p.image}
              alt={p.alt}
              width="1200"
              height="800"
              loading="lazy"
              decoding="async"
            />
          </a>
        ))}
      </div>
    </section>
  );
}
