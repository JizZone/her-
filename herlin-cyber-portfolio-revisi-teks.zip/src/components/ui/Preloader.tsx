"use client";
import { useEffect, useRef, useState } from "react";
import { gsap } from "gsap";
import { set, useStore } from "@/lib/store";
import { T } from "@/lib/tokens";
import { content } from "@/content";
export function Preloader() {
  const root = useRef<HTMLDivElement>(null);
  const start = useRef(0);
  const ready = useStore((s) => s.sceneReady);
  const reduced = useStore((s) => s.reducedMotion);
  const [count, setCount] = useState(0);
  const [done, setDone] = useState(false);
  useEffect(() => {
    if (done) return;
    if (reduced) {
      set({ loaded: true, intro: 1 });
      setDone(true);
      return;
    }
    if (!start.current) start.current = performance.now();
    let frame = 0;
    let finishing = false;
    let tween: gsap.core.Tween | undefined;
    const update = () => {
      if (finishing) return;
      const progress = Math.min(
        1,
        (performance.now() - start.current) / (T.dur.loader * T.number.ms),
      );
      setCount(Math.round(Math.min(ready ? 1 : 0.9, progress) * 100));
      if (progress < 1 || !ready) {
        frame = requestAnimationFrame(update);
        return;
      }
      finishing = true;
      set({ loaded: true });
      const intro = { v: 0 };
      tween = gsap.to(intro, {
        v: 1,
        duration: T.dur.hero,
        ease: T.ease.out,
        onUpdate: () => set({ intro: intro.v }),
      });
      gsap.to(root.current, {
        opacity: 0,
        y: -T.cursor.text,
        duration: T.dur.loaderExit,
        ease: T.ease.out,
        onComplete: () => setDone(true),
      });
    };
    frame = requestAnimationFrame(update);
    return () => {
      cancelAnimationFrame(frame);
    };
  }, [ready, reduced, done]);
  if (done) return null;
  return (
    <div
      ref={root}
      className="preloader"
      aria-label={content.loading}
      aria-hidden="true"
    >
      <span className="loader-ring" />
      <div className="preloader-count">
        {String(count).padStart(2, "0")}
        <span className="gold">%</span>
      </div>
    </div>
  );
}
