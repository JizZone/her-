"use client";
import { ArrowIcon } from "../icons/Icons";
import { content, type Project } from "@/content";
import { Documentation } from "@/documentation/Documentation";
import { SplitReveal } from "./SplitReveal";
export function ProjectDetail({
  project,
  next,
}: {
  project: Project;
  next: Project;
}) {
  return (
    <main
      id="main"
      className="project-detail documentation-detail"
      tabIndex={-1}
    >
      <section className="detail-hero">
        <a
          className="button button-quiet back-link"
          href="/#work"
          data-transition={content.work.title}
        >
          <ArrowIcon direction="left" />
          {content.detail.all}
        </a>
        <div className="detail-heading">
          <SplitReveal as="h1">{project.name}</SplitReveal>
          <p className="label gold">
            {project.category}
            <span>{project.year}</span>
          </p>
        </div>
        <p className="detail-summary lead">{project.description}</p>
        <p className="case-note muted">{content.detail.note}</p>
        <dl className="project-info">
          {[
            { label: content.detail.role, value: project.role },
            { label: content.detail.scope, value: project.scope },
            {
              label: content.detail.standards,
              value: project.standards.join(" · "),
            },
            { label: content.detail.year, value: project.year },
          ].map((v) => (
            <div key={v.label}>
              <dt className="label muted">{v.label}</dt>
              <dd>{v.value}</dd>
            </div>
          ))}
        </dl>
      </section>
      <Documentation project={project} />
      <div className="case-blocks">
        {project.blocks.map((b, i) => (
          <section key={b.title} className="case-block">
            <div className="case-copy">
              <span className="label gold">
                {String(i + 1).padStart(2, "0")}
              </span>
              <SplitReveal as="h2">{b.title}</SplitReveal>
              <p>{b.text}</p>
            </div>
          </section>
        ))}
      </div>
      <section className="next-project">
        <p className="label muted">{content.detail.next}</p>
        <a
          className="next-project-link"
          data-transition={next.name}
          href={`/work/${next.slug}/`}
          data-cursor="project"
        >
          <span>{next.name}</span>
          <ArrowIcon />
        </a>
        <a
          className="button button-quiet"
          href="/#work"
          data-transition={content.work.title}
        >
          <ArrowIcon direction="left" />
          {content.detail.all}
        </a>
      </section>
      <footer>
        <p className="label muted">{content.footer.copyright}</p>
        <a className="button button-quiet" href="#main">
          {content.footer.top}
          <ArrowIcon direction="up" />
        </a>
      </footer>
    </main>
  );
}
