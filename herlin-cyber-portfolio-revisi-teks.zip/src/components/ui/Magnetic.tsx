"use client";
import { useEffect, useRef, type ReactNode } from "react";
import { gsap } from "gsap";
import { T } from "@/lib/tokens";
import { useStore } from "@/lib/store";
export function Magnetic({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  const root = useRef<HTMLDivElement>(null),
    inner = useRef<HTMLDivElement>(null);
  const reduced = useStore((s) => s.reducedMotion),
    mobile = useStore((s) => s.mobile);
  useEffect(() => {
    if (reduced || mobile) return;
    let active = false,
      frame = 0;
    let latest: PointerEvent | null = null;
    const apply = (e: PointerEvent) => {
      if (!root.current || !inner.current) return;
      const b = root.current.getBoundingClientRect(),
        dx = e.clientX - (b.left + b.width / 2),
        dy = e.clientY - (b.top + b.height / 2);
      const near =
        Math.abs(dx) < b.width / 2 + T.magnet.radius &&
        Math.abs(dy) < b.height / 2 + T.magnet.radius;
      if (near) {
        active = true;
        const x =
            Math.max(-T.magnet.radius, Math.min(T.magnet.radius, dx)) *
            T.magnet.strength,
          y =
            Math.max(-T.magnet.radius, Math.min(T.magnet.radius, dy)) *
            T.magnet.strength;
        gsap.to(inner.current, {
          x,
          y,
          duration: T.dur.base,
          ease: T.ease.out,
          overwrite: true,
        });
        const label = inner.current.querySelector(".magnetic-text");
        if (label)
          gsap.to(label, {
            x: x * (T.magnet.inner - 1),
            y: y * (T.magnet.inner - 1),
            duration: T.dur.base,
            ease: T.ease.out,
            overwrite: true,
          });
      } else if (active) {
        active = false;
        gsap.to(
          [inner.current, inner.current.querySelector(".magnetic-text")].filter(
            Boolean,
          ),
          {
            x: 0,
            y: 0,
            duration: T.dur.magnet,
            ease: T.ease.elastic,
            overwrite: true,
          },
        );
      }
    };
    const move = (e: PointerEvent) => {
      latest = e;
      if (!frame)
        frame = requestAnimationFrame(() => {
          frame = 0;
          if (latest) apply(latest);
        });
    };
    window.addEventListener("pointermove", move, { passive: true });
    return () => {
      cancelAnimationFrame(frame);
      window.removeEventListener("pointermove", move);
      gsap.killTweensOf(inner.current);
    };
  }, [reduced, mobile]);
  return (
    <div ref={root} className={`magnetic ${className}`}>
      <div ref={inner}>{children}</div>
    </div>
  );
}
