"use client";
import { useEffect, useRef, useState } from "react";
import { usePathname, useRouter } from "next/navigation";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { T } from "@/lib/tokens";
import { content } from "@/content";
import { lockScroll, unlockScroll } from "@/lib/scroll-lock";
import { lenis } from "@/lib/lenis";
import { set, useStore } from "@/lib/store";
function jump(url: URL) {
  lenis?.start();
  lenis?.resize();
  const target = url.hash ? document.getElementById(url.hash.slice(1)) : null;
  const top = target
    ? Math.max(
        0,
        target.getBoundingClientRect().top +
          window.scrollY -
          parseFloat(
            getComputedStyle(document.documentElement).scrollPaddingTop || "0",
          ),
      )
    : 0;
  window.scrollTo({ top, behavior: "instant" });
  lenis?.scrollTo(top, { immediate: true, force: true });
  set({ scrollY: top });
  lenis?.stop();
}
export function TransitionOverlay() {
  const root = useRef<HTMLDivElement>(null),
    fallback = useRef<HTMLDivElement>(null);
  const router = useRouter(),
    pathname = usePathname();
  const pending = useRef<{ url: URL; exit: () => void } | null>(null);
  const anim = useRef<gsap.core.Timeline | null>(null);
  const [title, setTitle] = useState("");

  useEffect(() => {
    const prefetch = (event: Event) => {
      const link = (event.target as Element).closest<HTMLAnchorElement>(
        "a[data-transition]",
      );
      if (link && link.origin === location.origin)
        router.prefetch(link.pathname);
    };
    document.addEventListener("pointerover", prefetch, { passive: true });
    document.addEventListener("focusin", prefetch);
    return () => {
      document.removeEventListener("pointerover", prefetch);
      document.removeEventListener("focusin", prefetch);
    };
  }, [router]);
  useEffect(() => {
    if (!pending.current) return;
    const target = pending.current;
    if (
      pathname.replace(/\/$/, "") === target.url.pathname.replace(/\/$/, "")
    ) {
      pending.current = null;
      requestAnimationFrame(() => {
        ScrollTrigger.refresh();
        jump(target.url);
        target.exit();
      });
    }
  }, [pathname]);
  useEffect(() => {
    const click = (e: MouseEvent) => {
      const link = (e.target as HTMLElement).closest<HTMLAnchorElement>(
        "a[data-transition]",
      );
      if (
        !link ||
        e.button !== 0 ||
        e.metaKey ||
        e.ctrlKey ||
        e.shiftKey ||
        e.altKey ||
        link.target === "_blank"
      )
        return;
      const url = new URL(link.href);
      if (url.origin !== location.origin) return;
      e.preventDefault();
      if (useStore.getState().isTransitioning) return;
      const state = useStore.getState();
      setTitle(link.dataset.transition || content.home);
      set({
        isTransitioning: true,
        menuOpen: false,
        hoverProject: null,
        bulgeTarget: null,
      });
      lockScroll("route");
      const value = { v: 0 };
      const el = root.current!;
      gsap.set(el, { visibility: "visible", pointerEvents: "auto" });
      const finish = () => {
        set({ isTransitioning: false, transition: 0 });
        gsap.set(el, { visibility: "hidden", pointerEvents: "none" });
        unlockScroll("route");
        ScrollTrigger.refresh();
        document
          .querySelector<HTMLElement>("main")
          ?.focus({ preventScroll: true });
      };
      const exit = () => {
        const home = url.pathname === "/";
        const out = gsap.timeline({
          onComplete: () => {
            if (!home || state.reducedMotion) {
              finish();
              return;
            }
            const letters = document.querySelectorAll(".hero-letter");
            const reveal = { name: 0 };
            set({ nameReveal: 0 });
            gsap.set(el, { visibility: "hidden", pointerEvents: "none" });
            const entrance = gsap.timeline({ onComplete: finish });
            anim.current = entrance;
            entrance
              .fromTo(
                letters,
                { yPercent: 110, rotateX: 70 },
                {
                  yPercent: 0,
                  rotateX: 0,
                  duration:
                    T.intro.short - (letters.length - 1) * T.stagger.char,
                  stagger: T.stagger.char,
                  ease: T.ease.out,
                },
                0,
              )
              .fromTo(
                ".hero-bottom > *, .header",
                { y: 24, opacity: 0 },
                { y: 0, opacity: 1, duration: T.intro.short, ease: T.ease.out },
                0,
              )
              .to(
                reveal,
                {
                  name: 1,
                  duration: T.intro.short,
                  onUpdate: () => set({ nameReveal: reveal.name }),
                },
                0,
              );
          },
        });
        anim.current = out;
        if (state.reducedMotion) {
          out.to(el, { opacity: 0, duration: T.dur.micro });
          return;
        }
        out
          .to(
            value,
            {
              v: 0,
              duration: T.dur.page / 2,
              ease: T.ease.inout,
              onUpdate: () => set({ transition: value.v }),
            },
            0,
          )
          .to(
            el.querySelector(".transition-type"),
            {
              yPercent: -25,
              rotate: 0,
              scale: T.transition.scale,
              duration: T.dur.page / 2,
              ease: T.ease.inout,
            },
            0,
          )
          .to(
            el.querySelector(".transition-veil"),
            { opacity: 0, duration: T.dur.page / 2, ease: T.ease.inout },
            0,
          )
          .to(
            fallback.current,
            {
              scale: 1,
              rotate: 0,
              opacity: 0,
              duration: T.dur.page / 2,
              ease: T.ease.inout,
            },
            0,
          );
      };
      const navigate = () => {
        if (
          url.pathname.replace(/\/$/, "") ===
          location.pathname.replace(/\/$/, "")
        ) {
          if (url.hash) history.pushState(null, "", url.hash);
          jump(url);
          exit();
        } else {
          pending.current = { url, exit };
          router.push(url.pathname + url.hash, { scroll: false });
        }
      };
      const timeline = gsap.timeline({ onComplete: navigate });
      anim.current = timeline;
      gsap.set(el, { opacity: 1 });
      if (state.reducedMotion) {
        gsap.set(el.querySelector(".transition-type"), { opacity: 0 });
        timeline.fromTo(
          el,
          { opacity: 0 },
          { opacity: 1, duration: T.dur.micro },
        );
        gsap.set(el.querySelector(".transition-veil"), { opacity: 1 });
        return;
      }
      gsap.set(el.querySelector(".transition-type"), {
        yPercent: 0,
        rotate: 0,
        scale: 0.25,
        opacity: 1,
      });
      gsap.set(el.querySelector(".transition-veil"), { opacity: 0 });
      timeline
        .to(
          value,
          {
            v: 1,
            duration: T.dur.page / 2,
            ease: T.ease.inout,
            onUpdate: () => set({ transition: value.v }),
          },
          0,
        )
        .to(
          el.querySelector(".transition-type"),
          {
            rotate: 0,
            scale: 1,
            opacity: 0,
            duration: T.dur.page / 2,
            ease: T.ease.inout,
          },
          0,
        )
        .to(
          el.querySelector(".transition-veil"),
          { opacity: 1, duration: T.dur.page / 2, ease: T.ease.inout },
          0,
        )
        .fromTo(
          fallback.current,
          { scale: 0.25, rotate: 0, opacity: 0 },
          {
            scale: 2,
            rotate: 0,
            opacity: 1,
            duration: T.dur.page / 2,
            ease: T.ease.inout,
          },
          0,
        );
    };
    document.addEventListener("click", click, true);
    return () => {
      document.removeEventListener("click", click, true);
      anim.current?.kill();
    };
  }, [router]);
  return (
    <div className="transition-overlay" ref={root} aria-hidden="true">
      <div ref={fallback} className="transition-horizon" />
      <div className="transition-veil" />
      <div className="transition-type">{title}</div>
    </div>
  );
}
