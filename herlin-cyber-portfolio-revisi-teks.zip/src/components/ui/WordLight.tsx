"use client";
import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { T } from "@/lib/tokens";
import { useStore } from "@/lib/store";
export function WordLight({ text }: { text: string }) {
  const ref = useRef<HTMLParagraphElement>(null);
  const reduced = useStore((s) => s.reducedMotion);
  useEffect(() => {
    if (!ref.current || reduced) return;
    gsap.registerPlugin(ScrollTrigger);
    const ctx = gsap.context(
      () =>
        gsap.fromTo(
          ref.current!.querySelectorAll("[data-word]"),
          { opacity: T.motion.wordDim },
          {
            opacity: 1,
            stagger: T.stagger.word,
            ease: T.ease.linear,
            scrollTrigger: {
              trigger: ref.current,
              start: T.scroll.wordStart,
              end: T.scroll.wordEnd,
              scrub: true,
            },
          },
        ),
      ref,
    );
    return () => ctx.revert();
  }, [reduced]);
  return (
    <p ref={ref} className="about-copy">
      <span className="sr-only">{text}</span>
      {text.split(" ").map((word, i) => (
        <span data-word aria-hidden="true" key={i}>
          {word}{" "}
        </span>
      ))}
    </p>
  );
}
