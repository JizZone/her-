"use client";
import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { set, useStore, type CursorState } from "@/lib/store";
import { T } from "@/lib/tokens";
import { content } from "@/content";
export function Cursor() {
  const root = useRef<HTMLDivElement>(null),
    dot = useRef<HTMLDivElement>(null),
    ring = useRef<HTMLDivElement>(null);
  const enabled = useStore(
    (s) => s.introPhase === "ready" && !s.isTransitioning,
  );
  const state = useStore((s) => s.cursorState),
    mobile = useStore((s) => s.mobile),
    reduced = useStore((s) => s.reducedMotion);
  useEffect(() => {
    if (!enabled || mobile || reduced || !matchMedia("(pointer:fine)").matches)
      return;
    document.body.classList.add("cursor-enabled");
    let dx = 0,
      dy = 0,
      rx = 0,
      ry = 0;
    const tick = () => {
      const s = useStore.getState();
      if (!s.visible) return;
      dx += (s.mouse.px - dx) * T.lerp.cursorDot;
      dy += (s.mouse.py - dy) * T.lerp.cursorDot;
      rx += (s.mouse.px - rx) * T.lerp.cursorRing;
      ry += (s.mouse.py - ry) * T.lerp.cursorRing;
      gsap.set(dot.current, { x: dx, y: dy });
      gsap.set(ring.current, { x: rx, y: ry });
    };
    const over = (e: PointerEvent) => {
      const target = (e.target as HTMLElement).closest(
        "[data-cursor],a,button",
      );
      set({
        cursorState: (target?.getAttribute("data-cursor") ??
          (target ? "link" : "default")) as CursorState,
      });
      gsap.to(root.current, { opacity: 1, duration: T.dur.micro });
    };
    const leave = () =>
      gsap.to(root.current, { opacity: 0, duration: T.dur.micro });
    const down = () =>
      gsap.fromTo(
        ring.current,
        { scale: T.cursor.pulse },
        { scale: 1, duration: T.dur.micro },
      );
    window.addEventListener("pointerover", over);
    document.documentElement.addEventListener("pointerleave", leave);
    window.addEventListener("pointerdown", down);
    gsap.ticker.add(tick);
    return () => {
      document.body.classList.remove("cursor-enabled");
      gsap.ticker.remove(tick);
      window.removeEventListener("pointerover", over);
      document.documentElement.removeEventListener("pointerleave", leave);
      window.removeEventListener("pointerdown", down);
    };
  }, [mobile, reduced, enabled]);
  if (!enabled || mobile || reduced) return null;
  const size =
    state === "project"
      ? T.cursor.project
      : state === "text"
        ? T.cursor.text
        : state === "link"
          ? T.cursor.ring * T.cursor.linkScale
          : T.cursor.ring;
  return (
    <div className="custom-cursor" ref={root} aria-hidden="true">
      <div className="cursor-dot" ref={dot} />
      <div
        className={`cursor-ring cursor-${state}`}
        ref={ring}
        style={{ width: size, height: size }}
      >
        <span>{state === "project" ? content.view : ""}</span>
      </div>
    </div>
  );
}
