"use client";
import { MarkIcon, MenuIcon } from "../icons/Icons";
import { content } from "@/content";
import { set, useStore } from "@/lib/store";
import { RollingText } from "./SplitReveal";
import { Magnetic } from "./Magnetic";
export function Header() {
  const open = useStore((s) => s.menuOpen);
  const detail = useStore((s) => s.detail);
  return (
    <header className="header">
      <a
        href="/"
        data-transition={content.home}
        className="brand"
        aria-label={`${content.monogram} — ${content.name}`}
      >
        <span className="brand-monogram">
          {content.monogram}
          <MarkIcon className="brand-mark" />
        </span>
        <span className="label brand-name">
          <RollingText text={content.name} />
        </span>
      </a>

      <nav className="header-nav" aria-label={content.menu}>
        {content.nav.slice(0, 2).map((item) => (
          <a
            key={item.label}
            href={item.href}
            data-transition={detail ? item.label : undefined}
            className="label"
          >
            <RollingText text={item.label} />
          </a>
        ))}
        <Magnetic>
          <button
            id="menu-toggle"
            className={`menu-toggle label ${open ? "is-open" : ""}`}
            aria-expanded={open}
            aria-controls="navigation-menu"
            onClick={() => set({ menuOpen: !open })}
          >
            <span className="magnetic-text">
              {open ? content.close : content.menu}
            </span>
            <MenuIcon open={open} />
          </button>
        </Magnetic>
      </nav>
    </header>
  );
}
