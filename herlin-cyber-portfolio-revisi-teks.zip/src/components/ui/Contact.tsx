"use client";
import { ArrowIcon, CopyIcon } from "../icons/Icons";
import { SocialIcon } from "../icons/SocialIcons";
import { useEffect, useRef, useState } from "react";
import { useStore } from "@/lib/store";
import { content, profile, isConfigured } from "@/content";
import { T } from "@/lib/tokens";
import { SplitReveal } from "./SplitReveal";
import { Magnetic } from "./Magnetic";
export function Contact() {
  const ready = useStore((s) => s.webgl && s.sceneReady);
  const [status, setStatus] = useState("idle");
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);
  const configured = isConfigured(profile.email);
  useEffect(
    () => () => {
      clearTimeout(timer.current);
    },
    [],
  );
  const copy = async () => {
    if (!configured) return;
    try {
      await navigator.clipboard.writeText(profile.email);
      setStatus("copied");
      clearTimeout(timer.current);
      timer.current = setTimeout(
        () => setStatus("idle"),
        T.dur.copied * T.number.ms,
      );
    } catch {
      setStatus("failed");
    }
  };
  return (
    <>
      <section id="contact" className="section contact">
        <div className="section-label label muted">
          {content.sectionIndex[3]}
        </div>
        <SplitReveal as="h2">{content.contact.title}</SplitReveal>
        <div className="contact-grid">
          <div>
            <span className="label muted">{content.contact.emailLabel}</span>
            <div className="email-line">
              {configured ? (
                <a href={`mailto:${profile.email}`} className="email-text">
                  {profile.email}
                </a>
              ) : (
                <span className="email-text">{profile.email}</span>
              )}
              <button
                className="copy-button"
                onClick={copy}
                disabled={!configured}
                aria-label={content.contact.copy}
              >
                <CopyIcon done={status === "copied"} />
              </button>
            </div>
            <p role="status" className="copy-status label gold">
              {status === "copied"
                ? content.contact.copied
                : status === "failed"
                  ? content.contact.failed
                  : ""}
            </p>
            {status === "failed" && (
              <input
                className="copy-fallback"
                aria-label={content.contact.failed}
                readOnly
                value={profile.email}
                onFocus={(e) => e.currentTarget.select()}
              />
            )}
          </div>
          <div className="social-links">
            {content.contact.socials.map((s) => (
              <Magnetic key={s.key}>
                {isConfigured(s.value) ? (
                  <a
                    className="social-link"
                    href={s.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={`${s.name} — ${profile.name}`}
                  >
                    <span className="social-icon">
                      <SocialIcon name={s.key} />
                    </span>
                    <span>{s.name}</span>
                  </a>
                ) : (
                  <span
                    className="social-link is-disabled"
                    aria-disabled="true"
                    aria-label={`${s.name}: ${content.contact.unavailableLabel}`}
                  >
                    <span className="social-icon">
                      <SocialIcon name={s.key} />
                    </span>
                    <span>{s.name}</span>
                  </span>
                )}
              </Magnetic>
            ))}
          </div>
        </div>
        {!configured && (
          <p className="contact-unavailable muted">
            {content.contact.unavailable}
          </p>
        )}
        <div className="contact-object" aria-hidden="true">
          {!ready && (
            <img
              src="/images/ton-618.webp"
              alt=""
              width="1600"
              height="800"
              loading="lazy"
            />
          )}
        </div>
      </section>
      <footer id="footer">
        <p className="label muted">{content.footer.copyright}</p>
        <a href="#hero" className="button button-quiet">
          {content.footer.top}
          <ArrowIcon direction="up" />
        </a>
      </footer>
    </>
  );
}
