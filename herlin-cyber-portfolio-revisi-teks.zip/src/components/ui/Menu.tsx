"use client";
import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { set, useStore } from "@/lib/store";
import { T } from "@/lib/tokens";
import { content } from "@/content";
import { lenis } from "@/lib/lenis";
export function Menu() {
  const ref = useRef<HTMLDivElement>(null);
  const open = useStore((s) => s.menuOpen);
  const reduced = useStore((s) => s.reducedMotion);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const button = document.querySelector<HTMLButtonElement>("#menu-toggle");
    const main = document.querySelector("main");
    if (main) main.inert = open;
    if (open) {
      lenis?.stop();
      gsap.set(el, {
        visibility: "visible",
        pointerEvents: "auto",
        opacity: 1,
      });
      if (reduced) {
        gsap.set(el, { yPercent: 0 });
        gsap.fromTo(el, { opacity: 0 }, { opacity: 1, duration: T.dur.micro });
        gsap.set(el.querySelectorAll(".menu-letter"), { yPercent: 0 });
      } else {
        gsap.fromTo(
          el,
          { opacity: 0, yPercent: -3 },
          {
            opacity: 1,
            yPercent: 0,
            duration: reduced ? T.dur.micro : T.dur.menu,
            ease: T.ease.inout,
          },
        );
        gsap.fromTo(
          el.querySelectorAll(".menu-letter"),
          { yPercent: T.motion.hiddenY },
          {
            yPercent: 0,
            stagger: reduced ? 0 : T.stagger.char,
            duration: reduced ? T.dur.micro : T.dur.reveal,
            ease: T.ease.out,
          },
        );
      }
      el.querySelector<HTMLAnchorElement>("a")?.focus({ preventScroll: true });
    } else {
      if (reduced) {
        gsap.to(el, {
          opacity: 0,
          duration: T.dur.micro,
          onComplete: () => {
            gsap.set(el, { visibility: "hidden", pointerEvents: "none" });
          },
        });
      } else {
        gsap.to(el, {
          opacity: 0,
          yPercent: -3,
          duration: reduced ? T.dur.micro : T.dur.menu,
          ease: T.ease.inout,
          onComplete: () => {
            gsap.set(el, { visibility: "hidden", pointerEvents: "none" });
          },
        });
      }
      if (!useStore.getState().isTransitioning && !document.documentElement.dataset.scrollLocked) lenis?.start();
    }
    const key = (e: KeyboardEvent) => {
      if (!open) return;
      if (e.key === "Escape") {
        set({ menuOpen: false });
        button?.focus();
      }
      if (e.key === "Tab") {
        const links = [
          button,
          ...el.querySelectorAll<HTMLElement>("a,button"),
        ].filter(Boolean) as HTMLElement[];
        e.preventDefault();
        const current = links.indexOf(document.activeElement as HTMLElement);
        links[
          (current + (e.shiftKey ? -1 : 1) + links.length) % links.length
        ]?.focus();
      }
    };
    document.addEventListener("keydown", key);
    return () => {
      document.removeEventListener("keydown", key);
      if (main) main.inert = false;
      gsap.killTweensOf(el);
    };
  }, [open, reduced]);
  return (
    <div
      ref={ref}
      id="navigation-menu"
      className="menu-overlay"
      role="dialog"
      aria-modal={open ? true : undefined}
      aria-label={content.menu}
      aria-hidden={!open}
    >
      <nav className="menu-links">
        {[{ label: content.home, href: "/" }, ...content.nav].map((item, i) => (
          <a
            key={item.label}
            href={item.href}
            tabIndex={open ? 0 : -1}
            aria-label={item.label}
            data-transition={item.label}
            onClick={() => set({ menuOpen: false })}
          >
            <span className="menu-number label gold">
              {String(i + 1).padStart(2, "0")}
            </span>
            <span>
              {Array.from(item.label).map((c, j) => (
                <span key={j} className="split-mask">
                  <span className="menu-letter">
                    {c === " " ? "\u00a0" : c}
                  </span>
                </span>
              ))}
            </span>
          </a>
        ))}
      </nav>
    </div>
  );
}
