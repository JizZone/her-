"use client";
import { useEffect, useRef, type ElementType } from "react";
import { gsap } from "gsap";
import { SplitText } from "gsap/SplitText";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { T } from "@/lib/tokens";
import { useStore } from "@/lib/store";
export function SplitReveal({
  children,
  as: Tag = "span",
  className = "",
  words = false,
}: {
  children: string;
  as?: ElementType;
  className?: string;
  words?: boolean;
}) {
  const ref = useRef<HTMLElement>(null);
  const ready = useStore((s) => s.loaded && !s.isTransitioning);
  const reduced = useStore((s) => s.reducedMotion);
  useEffect(() => {
    if (!ref.current || !ready || reduced) return;
    gsap.registerPlugin(SplitText, ScrollTrigger);
    const ctx = gsap.context(() => {
      SplitText.create(ref.current!, {
        type: words ? "words" : "words,chars",
        mask: words ? "words" : "chars",
        autoSplit: true,
        onSplit(self) {
          return gsap.from(words ? self.words : self.chars, {
            yPercent: T.motion.hiddenY,
            duration: T.dur.reveal,
            stagger: words ? T.stagger.word : T.stagger.char,
            ease: T.ease.out,
            scrollTrigger: {
              trigger: ref.current,
              start: T.scroll.reveal,
              once: true,
            },
          });
        },
      });
    }, ref);
    return () => ctx.revert();
  }, [ready, reduced, words]);
  return (
    <Tag ref={ref} className={className}>
      {children}
    </Tag>
  );
}
export function RollingText({ text }: { text: string }) {
  return (
    <span className="rolling" aria-label={text}>
      {Array.from(text).map((c, i) => (
        <span
          key={i}
          className="rolling-char"
          data-char={c === " " ? "\u00a0" : c}
          aria-hidden="true"
          style={{ transitionDelay: `${i * T.stagger.logo}s` }}
        >
          {c === " " ? "\u00a0" : c}
        </span>
      ))}
    </span>
  );
}
