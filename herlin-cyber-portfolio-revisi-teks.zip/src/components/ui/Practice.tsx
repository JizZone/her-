"use client";
import { useStore } from "@/lib/store";
import { content } from "@/content";
import { SplitReveal } from "./SplitReveal";
import { WordLight } from "./WordLight";
export function Practice() {
  const ready = useStore((s) => s.webgl && s.sceneReady);
  return (
    <section id="practice" className="section practice">
      <div className="section-label label muted">{content.sectionIndex[2]}</div>
      <div className="practice-grid">
        <div className="practice-copy">
          <SplitReveal as="h2">{content.practice.title}</SplitReveal>
          <WordLight text={content.practice.copy} />
          <p className="muted">{content.practice.detail}</p>
        </div>
        <div className="practice-object" aria-hidden="true">
          {!ready && (
            <img
              src="/images/ton-618.webp"
              alt=""
              width="1600"
              height="800"
              loading="lazy"
            />
          )}
        </div>
      </div>
      <div className="services">
        {content.practice.services.map((s, i) => (
          <div key={s}>
            <span className="label gold">{String(i + 1).padStart(2, "0")}</span>
            <h3>{s}</h3>
          </div>
        ))}
      </div>
      {content.stats.length > 0 && (
        <div className="stats">
          {content.stats.map((s) => (
            <div key={s.label}>
              <strong>
                {s.value}
                {s.suffix}
              </strong>
              <p>{s.label}</p>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
