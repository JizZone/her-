"use client";
import { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { T } from "@/lib/tokens";
import { useStore } from "@/lib/store";
export function Marquee({ text }: { text: string[] }) {
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let x = 0;
    let width = 0;
    const measure = () => {
      width = (ref.current?.scrollWidth ?? 0) / 2;
    };
    const observer = new ResizeObserver(measure);
    if (ref.current) observer.observe(ref.current);
    const tick = () => {
      const s = useStore.getState();
      if (!ref.current || s.reducedMotion || !s.visible || !width) return;
      x -=
        T.motion.marqueeSpeed +
        Math.min(Math.abs(s.velocity), T.motion.velocityCap) *
          T.motion.skewFactor;
      if (x < -width) x += width;
      gsap.set(ref.current, { x });
    };
    gsap.ticker.add(tick);
    return () => {
      gsap.ticker.remove(tick);
      observer.disconnect();
    };
  }, []);
  return (
    <div className="marquee" role="img" aria-label={text.join(" · ")}>
      <div className="marquee-track" ref={ref} aria-hidden="true">
        {[0, 1].map((i) => (
          <div className="marquee-set" key={i}>
            {text.map((t) => (
              <span key={t}>
                {t}
                <svg viewBox="0 0 16 16" fill="currentColor">
                  <path d="m8 2 6 6-6 6-6-6Z" />
                </svg>
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
