import type { SVGProps } from "react";
type Props = SVGProps<SVGSVGElement>;
export function ArrowIcon({
  direction = "up-right",
  ...props
}: Props & { direction?: "up-right" | "left" | "up" | "down" }) {
  const paths = {
    "up-right": "M6 18 18 6M6 6h12v12",
    left: "M20 12H4m7-7-7 7 7 7",
    up: "M12 20V4m-7 7 7-7 7 7",
    down: "M12 4v16m-7-7 7 7 7-7",
  };
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      {...props}
    >
      <path d={paths[direction]} />
    </svg>
  );
}
export function MarkIcon(props: Props) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      aria-hidden="true"
      {...props}
    >
      <circle cx="12" cy="12" r="4" />
      <path d="M12 1v5m0 12v5M1 12h5m12 0h5" />
    </svg>
  );
}
export function MenuIcon({ open = false }: { open?: boolean }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      aria-hidden="true"
      className={open ? "menu-svg is-open" : "menu-svg"}
    >
      <path className="menu-line-a" d="M3 8h18" />
      <path className="menu-line-b" d="M3 16h18" />
    </svg>
  );
}
export function CopyIcon({ done = false }: { done?: boolean }) {
  return (
    <svg
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      {done ? (
        <path d="m5 12 4 4L19 6" />
      ) : (
        <>
          <rect x="8" y="8" width="12" height="12" rx="2" />
          <path d="M16 5V4H4v12h1" />
        </>
      )}
    </svg>
  );
}
