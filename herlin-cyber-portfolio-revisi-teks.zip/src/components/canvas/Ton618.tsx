"use client";
import { useEffect, useMemo, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import { MathUtils, Vector3 } from "three";
import { createTonScene, TON } from "@/lib/ton-scene";
import { useStore, set } from "@/lib/store";
import { T } from "@/lib/tokens";
import { sceneState } from "@/lib/scene-state";
export function Ton618() {
  const quality = useStore((s) => s.quality);
  const model = useMemo(() => createTonScene(true), []);
  useEffect(() => {
    const jets = model.group.getObjectByName("Jets");
    if (jets) jets.visible = quality === "high";
  }, [quality, model]);
  const { viewport, camera } = useThree();
  const elapsed = useRef(0);
  const frames = useRef(0);
  const first = useRef(true);
  const projected = useMemo(() => new Vector3(), []);
  const tilt = useRef({ x: 0, y: 0 });
  useEffect(() => {
    first.current = true;
    return () => model.dispose();
  }, [model]);
  useFrame((_, delta) => {
    if (++frames.current === 2) set({ frameReady: true });
    const s = useStore.getState();
    const h = sceneState.height,
      w = sceneState.width,
      a = sceneState.anchors;
    const blend = (top: number) =>
      MathUtils.clamp((s.scrollY + h - top) / h, 0, 1);
    const work = blend(a.work),
      practice = blend(a.practice),
      contact = blend(a.contact);
    const base =
      (viewport.width * (s.mobile ? TON.mobileWidth : TON.heroWidth)) /
      (TON.outer * 2);
    let scale = base * MathUtils.lerp(1, TON.workScale, work);
    scale = MathUtils.lerp(scale, base * TON.practiceScale, practice);
    scale = MathUtils.lerp(scale, base * TON.contactScale, contact);
    let x = viewport.width * ((s.mobile ? TON.mobileX : TON.heroX) - 0.5);
    x = MathUtils.lerp(
      x,
      viewport.width * ((s.mobile ? 0.5 : TON.practiceX) - 0.5),
      practice,
    );
    x = MathUtils.lerp(x, 0, contact);
    let y = viewport.height * (0.5 - (s.mobile ? TON.mobileY : TON.heroY));
    const practiceY =
      viewport.height * (0.5 - (a.practiceCenter - s.scrollY) / h);
    if (Number.isFinite(practiceY)) y = MathUtils.lerp(y, practiceY, practice);
    const contactY =
      viewport.height * (0.5 - (a.contactCenter - s.scrollY) / h);
    if (Number.isFinite(contactY)) y = MathUtils.lerp(y, contactY, contact);
    if (s.detail) {
      scale = base * 0.35;
      x = 0;
      y = 0;
    }
    model.group.visible = !s.detail || s.isTransitioning;
    const ease = first.current ? 1 : T.lerp.mouseObject;
    first.current = false;
    model.group.position.x = MathUtils.lerp(
      model.group.position.x,
      x * (1 - s.transition),
      ease,
    );
    model.group.position.y = MathUtils.lerp(
      model.group.position.y,
      y * (1 - s.transition),
      ease,
    );
    model.group.scale.setScalar(
      MathUtils.lerp(model.group.scale.x, scale, ease),
    );
    camera.position.z = MathUtils.lerp(
      T.scene.cameraZ,
      TON.radius * scale * 1.08,
      s.transition,
    );
    camera.updateMatrixWorld();
    elapsed.current += Math.min(delta, 0.05);
    tilt.current.x = MathUtils.lerp(
      tilt.current.x,
      s.mouse.x * TON.mouseTilt,
      T.lerp.mouseObject,
    );
    tilt.current.y = MathUtils.lerp(
      tilt.current.y,
      s.mouse.y * TON.mouseTilt,
      T.lerp.mouseObject,
    );
    model.update(
      elapsed.current * TON.idle,
      s.intro,
      (s.mouse.speed / T.motion.velocityCap) * TON.turbulence,
      s.hoverProject === null ? 0 : TON.hoverBoost,
      tilt.current.x,
      tilt.current.y,
    );
    projected.copy(model.group.position).project(camera);
    sceneState.center.x = projected.x * 0.5 + 0.5;
    sceneState.center.y = projected.y * 0.5 + 0.5;
    sceneState.scale = scale / base;
  });
  return <primitive object={model.group} />;
}
