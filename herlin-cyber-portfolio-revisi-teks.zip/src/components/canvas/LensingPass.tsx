"use client";
import { useContext, useEffect, useMemo, useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import {
  Bloom,
  EffectComposer,
  EffectComposerContext,
} from "@react-three/postprocessing";
import { HorizonLensing } from "@/lib/lensing";
import { useStore } from "@/lib/store";
import { sceneState } from "@/lib/scene-state";
import { TON } from "@/lib/ton-scene";
function TargetResolution({ scale }: { scale: number }) {
  const { composer } = useContext(EffectComposerContext);
  const { size, gl } = useThree();
  const previous = useRef("");
  useFrame(() => {
    const key = `${size.width}:${size.height}:${gl.getPixelRatio()}:${scale}:${composer.passes.length}`;
    if (key === previous.current) return;
    previous.current = key;
    const w = Math.floor(size.width * gl.getPixelRatio() * scale),
      h = Math.floor(size.height * gl.getPixelRatio() * scale);
    composer.inputBuffer.setSize(w, h);
    composer.outputBuffer.setSize(w, h);
    composer.passes.forEach((p) => p.setSize(w, h));
  }, 0);
  return null;
}
export function LensingPass() {
  const quality = useStore((s) => s.quality);
  const effect = useMemo(() => new HorizonLensing(), [quality]);
  const { size } = useThree();
  useEffect(() => () => effect.dispose(), [effect]);
  useFrame(() => {
    const s = useStore.getState();
    effect.configure(
      sceneState.center,
      size.width / size.height,
      TON.lensStrength *
        s.introLens *
        (s.mobile ? TON.mobileLensing : 1) *
        (1 + s.transition * (TON.transitionStrength - 1)) *
        (s.hoverProject === null ? 1 : 1 + TON.hoverBoost),
      TON.lensRadius * (s.mobile ? 0.45 : 1) * Math.max(0.4, sceneState.scale),
      Math.max(0, (s.transition - 0.86) / 0.14),
    );
  });
  if (quality === "low") return null;
  const medium = quality === "medium";
  return (
    <EffectComposer
      key={quality}
      multisampling={0}
      enableNormalPass={false}
      mergeMode="none"
    >
      <primitive object={effect} />
      <Bloom
        intensity={medium ? TON.bloomMedium : TON.bloom}
        luminanceThreshold={TON.bloomThreshold}
        mipmapBlur
        resolutionScale={medium ? 0.25 : 0.5}
      />
      <TargetResolution scale={medium ? 0.5 : 1} />
    </EffectComposer>
  );
}
