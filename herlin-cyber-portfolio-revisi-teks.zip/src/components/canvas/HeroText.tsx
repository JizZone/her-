"use client";
import { useEffect, useMemo, useRef, useState } from "react";
import { Text } from "@react-three/drei";
import { useFrame, useThree } from "@react-three/fiber";
import { Group, MathUtils, Vector3 } from "three";
import { content } from "@/content";
import { useStore, set } from "@/lib/store";
import { T } from "@/lib/tokens";
import metrics from "@/lib/font-metrics.json";
export function HeroText() {
  const ref = useRef<Group>(null);
  const synced = useRef(new Set<number>());
  const lastIntro = useRef(-1);
  const textPlane = useMemo(() => new Vector3(0, 0, T.scene.textZ), []);
  const { viewport, camera, size } = useThree();
  const [lines, setLines] = useState<
    { text: string; x: number; y: number; font: number; spacing: number }[]
  >([]);
  const detail = useStore((s) => s.detail);
  useEffect(() => {
    const measure = () => {
      const el = document.querySelector<HTMLElement>(".fallback-name");
      if (!el) {
        set({ sceneReady: true });
        return;
      }
      const css = getComputedStyle(el);
      const v = viewport.getCurrentViewport(
        camera,
        new Vector3(0, 0, T.scene.textZ),
      );
      const ratio = v.width / window.innerWidth;
      setLines(
        [...el.children].map((child, i) => {
          const b = child.getBoundingClientRect();
          return {
            text: i === 0 ? content.firstName : content.lastName,
            x: (b.left - window.innerWidth / 2) * ratio,
            y: (window.innerHeight / 2 - b.top - window.scrollY) * ratio,
            font: parseFloat(css.fontSize) * ratio,
            spacing: parseFloat(css.letterSpacing) * ratio,
          };
        }),
      );
    };
    measure();
    document.fonts.ready.then(measure);
  }, [size.width, size.height, detail, viewport, camera]);
  const glyphs = useMemo(
    () =>
      lines.flatMap((line) => {
        let x = line.x;
        return Array.from(line.text).map((char) => {
          const result = { char, x, y: line.y, font: line.font };
          x +=
            ((metrics as Record<string, number>)[char] ?? 0.5) * line.font +
            line.spacing;
          return result;
        });
      }),
    [lines],
  );
  useEffect(() => {
    lastIntro.current = -1;
  }, [glyphs]);
  useFrame(() => {
    if (!ref.current) return;
    const s = useStore.getState();
    ref.current.visible = !s.detail && s.scrollY < window.innerHeight;
    const v = viewport.getCurrentViewport(camera, textPlane);
    ref.current.position.y = (s.scrollY / window.innerHeight) * v.height;
    if (lastIntro.current === s.nameReveal) return;
    lastIntro.current = s.nameReveal;
    ref.current.children.forEach((child, i) => {
      const g = glyphs[i];
      if (!g) return;
      const p = MathUtils.clamp(
        (s.nameReveal * (T.intro.name + (glyphs.length - 1) * T.stagger.char) -
          i * T.stagger.char) /
          T.intro.name,
        0,
        1,
      );
      child.rotation.x = (1 - p) * MathUtils.degToRad(70);
      child.position.y = g.y - (1 - p) * g.font;
      (child as unknown as { clipRect: number[] }).clipRect = [
        -100,
        -g.font + (1 - p) * g.font,
        100,
        (1 - p) * g.font,
      ];
    });
  });
  return (
    <group ref={ref} position={[0, 0, T.scene.textZ]}>
      {glyphs.map((g, i) => (
        <Text
          key={`${i}-${g.char}`}
          font="/fonts/fraunces-display.ttf"
          characters={content.name}
          fontSize={g.font}
          position={[g.x, g.y, 0]}
          anchorX="left"
          anchorY="top"
          color={T.color.bone}
          onSync={() => {
            synced.current.add(i);
            if (synced.current.size >= glyphs.length) set({ sceneReady: true });
          }}
        >
          {g.char}
          <meshBasicMaterial color={T.color.bone} toneMapped={false} />
        </Text>
      ))}
    </group>
  );
}
