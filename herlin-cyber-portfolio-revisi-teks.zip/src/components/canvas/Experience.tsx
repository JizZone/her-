"use client";
import { Suspense, useEffect } from "react";
import { Canvas } from "@react-three/fiber";
import { PerformanceMonitor, Stats } from "@react-three/drei";
import { T } from "@/lib/tokens";
import { set, useStore } from "@/lib/store";
import { lowerQuality, raiseQuality, qualitySettings } from "@/lib/perf";
import { Ton618 } from "./Ton618";
import { HeroText } from "./HeroText";
import { LensingPass } from "./LensingPass";
function Scene() {
  const detail = useStore((s) => s.detail);
  useEffect(() => {
    if (detail) set({ sceneReady: true });
  }, [detail]);
  return (
    <>
      <color attach="background" args={[T.color.ink]} />
      <PerformanceMonitor
        bounds={() => T.perf.bounds}
        iterations={T.perf.iterations}
        flipflops={T.perf.iterations}
        onDecline={lowerQuality}
        onIncline={raiseQuality}
        onFallback={() => set({ quality: "low" })}
      />
      {process.env.NODE_ENV === "development" && <Stats />}
      <HeroText />
      <Ton618 />
      <LensingPass />
    </>
  );
}
export default function Experience() {
  const visible = useStore((s) => s.visible);
  const active = useStore(
    (s) =>
      !s.viewerOpen &&
      (s.canvasActive || s.isTransitioning || s.hoverProject !== null),
  );
  const quality = useStore((s) => s.quality);
  const settings = qualitySettings(quality);
  return (
    <div
      className="experience"
      aria-hidden="true"
      data-quality={quality}
      style={{ visibility: active ? "visible" : "hidden" }}
    >
      <Canvas
        dpr={[1, settings.dpr]}
        gl={{ antialias: false, powerPreference: "high-performance" }}
        camera={{
          position: [0, 0, T.scene.cameraZ],
          fov: T.scene.fov,
          near: T.scene.near,
          far: T.scene.far,
        }}
        frameloop={visible && active ? "always" : "never"}
        onCreated={({ gl }) => {
          gl.domElement.addEventListener(
            "webglcontextlost",
            (e) => {
              e.preventDefault();
              set({ webgl: false, sceneReady: true });
            },
            { once: true },
          );
        }}
      >
        <Suspense fallback={null}>
          <Scene />
        </Suspense>
      </Canvas>
    </div>
  );
}
