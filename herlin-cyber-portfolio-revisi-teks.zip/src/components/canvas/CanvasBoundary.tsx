"use client";
import { Component, type ReactNode } from "react";
import { set } from "@/lib/store";
export class CanvasBoundary extends Component<
  { children: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };
  static getDerivedStateFromError() {
    return { failed: true };
  }
  componentDidCatch() {
    set({ webgl: false, sceneReady: true });
  }
  render() {
    return this.state.failed ? null : this.props.children;
  }
}
