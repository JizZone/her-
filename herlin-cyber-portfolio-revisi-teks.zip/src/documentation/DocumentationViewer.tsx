"use client";
import {
  useEffect,
  useLayoutEffect,
  useRef,
  useState,
  type RefObject,
  type PointerEvent,
  type CSSProperties,
} from "react";
import { gsap } from "gsap";
import { content, type Project } from "@/content";
import { set, useStore } from "@/lib/store";
import { T } from "@/lib/tokens";
import { lockScroll, unlockScroll } from "@/lib/scroll-lock";
import { ArrowIcon } from "@/components/icons/Icons";
import { Magnetic } from "@/components/ui/Magnetic";
import { DocumentationPhoto } from "./DocumentationPhoto";
export type ViewerProps = {
  project: Project;
  origin: { x: number; y: number };
  opener: RefObject<HTMLButtonElement | null>;
  onClose: () => void;
};
function LetterCopy({ text }: { text: string }) {
  return (
    <>
      <span className="sr-only">{text}</span>
      <span aria-hidden="true">
        {text.split(" ").map((word, i) => (
          <span key={i}>
            <span className="documentation-word">
              {Array.from(word).map((char, j) => (
                <span className="documentation-char-mask" key={j}>
                  <span className="documentation-char">{char}</span>
                </span>
              ))}
            </span>{" "}
          </span>
        ))}
      </span>
    </>
  );
}
export function DocumentationViewer({
  project,
  origin,
  opener,
  onClose,
}: ViewerProps) {
  const root = useRef<HTMLDivElement>(null);
  const start = useRef({ x: 0, y: 0 });
  const busy = useRef(true);
  const closing = useRef(false);
  const first = useRef(true);
  const timeline = useRef<gsap.core.Timeline | null>(null);
  const bounds = useRef<DOMRect | null>(null);
  const pointerFrame = useRef(0);
  const pointer = useRef({ x: 0, y: 0 });
  const [index, setIndex] = useState(0);
  const [motion, setMotion] = useState("opening");
  const reduced = useStore((s) => s.reducedMotion);
  const photo = project.photos[index];
  const count = String(index + 1).padStart(2, "0");
  const finish = () => {
    first.current = false;
    busy.current = false;
    setMotion("idle");
  };
  useEffect(() => {
    set({ viewerOpen: true });
    lockScroll("documentation");
    root.current
      ?.querySelector<HTMLButtonElement>(".documentation-close")
      ?.focus({ preventScroll: true });
    return () => {
      timeline.current?.kill();
      cancelAnimationFrame(pointerFrame.current);
      set({ viewerOpen: false });
      unlockScroll("documentation");
      requestAnimationFrame(() => {
        if (!document.getElementById(`documentation-${project.slug}`))
          opener.current?.focus({ preventScroll: true });
      });
    };
  }, [opener]);
  useLayoutEffect(() => {
    const el = root.current;
    if (!el) return;
    const initial = first.current;
    busy.current = true;
    const active = gsap.timeline({ onComplete: finish });
    timeline.current = active;
    const slices = el.querySelectorAll(".documentation-slice");
    const planes = el.querySelectorAll(".documentation-slice-plane");
    const chars = el.querySelectorAll(
      ".documentation-caption .documentation-char",
    );
    const duration = initial
      ? T.gallery.open
      : T.gallery.change - T.gallery.changeOut;
    const stagger = initial ? T.gallery.sliceStagger : T.stagger.char;
    if (reduced) {
      gsap.set(el, { clipPath: "none" });
      active.fromTo(
        initial
          ? el
          : el.querySelectorAll(
              ".documentation-stage,.documentation-caption,.documentation-number",
            ),
        { opacity: 0 },
        {
          opacity: 1,
          duration: initial ? T.gallery.reduced : T.gallery.reduced / 2,
        },
      );
      return () => {
        active.kill();
      };
    }
    if (initial) {
      gsap.set(el, { clipPath: `circle(0% at ${origin.x}% ${origin.y}%)` });
      gsap.set(el.querySelector(".documentation-edge"), {
        left: `${origin.x}%`,
        top: `${origin.y}%`,
        xPercent: -50,
        yPercent: -50,
        scale: 0,
        opacity: 1,
      });
      active
        .to(
          el,
          {
            clipPath: `circle(150% at ${origin.x}% ${origin.y}%)`,
            duration: T.gallery.iris,
            ease: T.ease.inout,
          },
          0,
        )
        .to(
          el.querySelector(".documentation-edge"),
          {
            scale: 1,
            opacity: 0,
            duration: T.gallery.iris,
            ease: T.ease.inout,
          },
          0,
        )
        .fromTo(
          el.querySelector(".documentation-pulse"),
          { scale: 0, opacity: 1 },
          { scale: 2, opacity: 0, duration: T.gallery.pulse },
          0,
        )
        .fromTo(
          el.querySelector(".documentation-header"),
          { yPercent: -110 },
          { yPercent: 0, duration: T.gallery.summary, ease: T.ease.out },
          T.gallery.captionAt,
        )
        .fromTo(
          el.querySelectorAll(".documentation-summary-word"),
          { yPercent: 110, opacity: 0 },
          {
            yPercent: 0,
            opacity: 1,
            duration: T.gallery.summary,
            stagger: {
              amount: T.gallery.open - T.gallery.summaryAt - T.gallery.summary,
            },
            ease: T.ease.out,
          },
          T.gallery.summaryAt,
        )
        .fromTo(
          el.querySelectorAll(".documentation-thumb,.documentation-navigation"),
          { y: 32, opacity: 0 },
          {
            y: 0,
            opacity: 1,
            duration: T.gallery.thumbs,
            stagger: T.stagger.char,
            ease: T.ease.out,
          },
          T.gallery.thumbsAt,
        );
    }
    const sliceAt = initial ? T.gallery.sliceAt : 0;
    const sliceDuration = initial
      ? T.gallery.slice
      : duration - stagger * (T.gallery.slices - 1);
    const captionAt = initial ? T.gallery.captionAt : 0;
    const captionDuration = initial ? T.gallery.caption : duration / 2;
    active
      .fromTo(
        slices,
        { yPercent: 110 },
        { yPercent: 0, duration: sliceDuration, stagger, ease: "power4.out" },
        sliceAt,
      )
      .fromTo(
        planes,
        { scale: T.gallery.imageScale, xPercent: initial ? 0 : -6 },
        {
          scale: 1,
          xPercent: 0,
          duration: initial ? T.gallery.open - sliceAt : duration,
          ease: T.ease.out,
        },
        sliceAt,
      )
      .fromTo(
        chars,
        { yPercent: 110, rotateX: 35 },
        {
          yPercent: 0,
          rotateX: 0,
          duration: captionDuration,
          stagger: {
            amount: Math.min(
              Math.max(0, chars.length - 1) * T.stagger.char,
              duration - captionAt - captionDuration,
            ),
          },
          ease: T.ease.out,
        },
        captionAt,
      )
      .fromTo(
        el.querySelector(".documentation-number"),
        { y: 16, opacity: 0 },
        { y: 0, opacity: 1, duration: T.gallery.caption, ease: T.ease.out },
        captionAt,
      )
      .call(() => {}, [], duration);
    return () => {
      active.kill();
    };
  }, [index, reduced]);
  const change = (next: number) => {
    const target = (next + project.photos.length) % project.photos.length;
    if (busy.current || target === index || closing.current || !root.current)
      return;
    busy.current = true;
    setMotion("changing");
    timeline.current?.kill();
    const el = root.current;
    const active = gsap.timeline({ onComplete: () => setIndex(target) });
    timeline.current = active;
    if (reduced) {
      active.to(
        el.querySelectorAll(
          ".documentation-stage,.documentation-caption,.documentation-number",
        ),
        { opacity: 0, duration: T.gallery.reduced / 2 },
      );
      return;
    }
    active
      .to(
        el.querySelectorAll(".documentation-slice"),
        {
          yPercent: -110,
          duration:
            T.gallery.changeOut - (T.gallery.slices - 1) * T.stagger.char,
          stagger: { each: T.stagger.char, from: "end" },
          ease: T.ease.inout,
        },
        0,
      )
      .to(
        el.querySelectorAll(".documentation-slice-plane"),
        { scale: 0.94, duration: T.gallery.changeOut, ease: T.ease.inout },
        0,
      )
      .to(
        el.querySelectorAll(".documentation-caption .documentation-char"),
        {
          yPercent: -110,
          duration: T.gallery.changeOut / 2,
          stagger: { amount: T.gallery.changeOut / 2, from: "end" },
        },
        0,
      )
      .call(() => {}, [], T.gallery.changeOut);
  };
  const close = () => {
    if (closing.current || !root.current) return;
    closing.current = true;
    busy.current = true;
    setMotion("closing");
    timeline.current?.kill();
    const el = root.current;
    const active = gsap.timeline({ onComplete: onClose });
    timeline.current = active;
    if (reduced) {
      active.to(el, { opacity: 0, duration: T.gallery.reduced });
      return;
    }
    const rect = opener.current?.getBoundingClientRect();
    const point = rect
      ? {
          x: ((rect.left + rect.width / 2) / innerWidth) * 100,
          y: ((rect.top + rect.height / 2) / innerHeight) * 100,
        }
      : origin;
    gsap.set(el, { clipPath: `circle(150% at ${point.x}% ${point.y}%)` });
    gsap.set(el.querySelector(".documentation-pulse"), {
      left: `${point.x}%`,
      top: `${point.y}%`,
    });
    active
      .to(
        el.querySelectorAll(".documentation-slice"),
        {
          yPercent: 110,
          duration: T.gallery.changeOut,
          stagger: { each: T.stagger.char, from: "end" },
          ease: T.ease.inout,
        },
        0,
      )
      .to(
        el.querySelectorAll(
          ".documentation-panel,.documentation-thumbnails,.documentation-header",
        ),
        { y: -24, opacity: 0, duration: T.gallery.caption },
        0,
      )
      .to(
        el,
        {
          clipPath: `circle(0% at ${point.x}% ${point.y}%)`,
          duration: T.gallery.close - T.gallery.closeIrisAt,
          ease: T.ease.inout,
        },
        T.gallery.closeIrisAt,
      )
      .fromTo(
        el.querySelector(".documentation-pulse"),
        { scale: 0.5, opacity: 0 },
        { scale: 1.5, opacity: 1, duration: T.gallery.closeIrisAt },
        T.gallery.close - T.gallery.closeIrisAt,
      );
  };
  const swipeEnd = (event: PointerEvent) => {
    if (event.pointerType !== "touch") return;
    const dx = event.clientX - start.current.x,
      dy = event.clientY - start.current.y;
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy))
      change(index + (dx < 0 ? 1 : -1));
  };
  const move = (event: PointerEvent<HTMLDivElement>) => {
    if (
      event.pointerType !== "mouse" ||
      reduced ||
      useStore.getState().mobile ||
      busy.current
    )
      return;
    bounds.current ??= event.currentTarget.getBoundingClientRect();
    pointer.current = { x: event.clientX, y: event.clientY };
    if (pointerFrame.current) return;
    pointerFrame.current = requestAnimationFrame(() => {
      pointerFrame.current = 0;
      const rect = bounds.current;
      if (!rect) return;
      const x = Math.max(
        -1,
        Math.min(1, ((pointer.current.x - rect.left) / rect.width) * 2 - 1),
      );
      const y = Math.max(
        -1,
        Math.min(1, ((pointer.current.y - rect.top) / rect.height) * 2 - 1),
      );
      gsap.to(root.current?.querySelector(".documentation-parallax") || [], {
        x: x * T.gallery.shift,
        y: y * T.gallery.shift,
        rotateX: -y * T.gallery.tilt,
        rotateY: x * T.gallery.tilt,
        duration: T.gallery.parallax,
        ease: T.ease.out,
        overwrite: true,
      });
    });
  };
  return (
    <div
      ref={root}
      id={`documentation-${project.slug}`}
      className={`documentation-viewer ${reduced ? "is-reduced" : ""}`}
      data-motion={motion}
      data-effect="clip-scale"
      role="dialog"
      aria-modal="true"
      aria-labelledby={`viewer-title-${project.slug}`}
      style={
        {
          "--gallery-digit": `${T.gallery.caption}s`,
          clipPath: `circle(0% at ${origin.x}% ${origin.y}%)`,
        } as CSSProperties
      }
      onClick={(event) => {
        if (event.target === event.currentTarget) close();
      }}
      onKeyDown={(event) => {
        if (event.key === "Escape") {
          event.preventDefault();
          close();
        }
        if (event.key === "ArrowRight") {
          event.preventDefault();
          change(index + 1);
        }
        if (event.key === "ArrowLeft") {
          event.preventDefault();
          change(index - 1);
        }
        if (event.key === "Tab") {
          const controls = [
            ...event.currentTarget.querySelectorAll<HTMLButtonElement>(
              "button:not(:disabled)",
            ),
          ];
          const position = controls.indexOf(
            document.activeElement as HTMLButtonElement,
          );
          event.preventDefault();
          controls[
            (position + (event.shiftKey ? -1 : 1) + controls.length) %
              controls.length
          ]?.focus();
        }
      }}
    >
      <div className="documentation-edge" />
      <div
        className="documentation-pulse"
        style={{ left: `${origin.x}%`, top: `${origin.y}%` }}
      />
      <div className="documentation-layout">
        <header className="documentation-header">
          <p className="label" id={`viewer-title-${project.slug}`}>
            {project.name}
            <span className="muted"> / {content.documentation.title}</span>
          </p>
          <button
            className="button button-quiet documentation-close"
            onClick={close}
          >
            {content.documentation.close}
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.5"
              aria-hidden="true"
            >
              <path d="m6 6 12 12M18 6 6 18" />
            </svg>
          </button>
        </header>
        <div
          className="documentation-stage"
          onPointerMove={move}
          onPointerEnter={() => {
            bounds.current = null;
          }}
          onPointerLeave={() => {
            bounds.current = null;
            gsap.to(
              root.current?.querySelector(".documentation-parallax") || [],
              {
                x: 0,
                y: 0,
                rotateX: 0,
                rotateY: 0,
                duration: T.gallery.parallax,
                overwrite: true,
              },
            );
          }}
          onPointerDown={(event) => {
            start.current = { x: event.clientX, y: event.clientY };
            if (event.pointerType === "touch")
              event.currentTarget.setPointerCapture(event.pointerId);
          }}
          onPointerUp={swipeEnd}
        >
          <div className="documentation-parallax">
            <div className="documentation-image" key={photo.src}>
              {Array.from(
                { length: reduced ? 1 : T.gallery.slices },
                (_, n) => (
                  <div
                    key={n}
                    className={`documentation-slice ${reduced ? "single" : ""}`}
                    style={{ left: `${reduced ? 0 : n * 20}%` }}
                  >
                    <div
                      className="documentation-slice-plane"
                      style={{ left: `${reduced ? 0 : n * -100}%` }}
                    >
                      <DocumentationPhoto photo={photo} decorative={n > 0} />
                    </div>
                  </div>
                ),
              )}
            </div>
          </div>
        </div>
        <aside className="documentation-panel">
          <div
            className="documentation-number"
            aria-live="polite"
            aria-atomic="true"
          >
            <span className="sr-only">
              {content.documentation.photo} {index + 1} /{" "}
              {project.photos.length}
            </span>
            <span aria-hidden="true">
              {count.split("").map((digit, n) => (
                <span className="documentation-digit" key={n}>
                  <span
                    className="documentation-digit-track"
                    style={{ transform: `translateY(-${Number(digit) * 10}%)` }}
                  >
                    {Array.from({ length: 10 }, (_, d) => (
                      <span key={d}>{d}</span>
                    ))}
                  </span>
                </span>
              ))}
              <span className="documentation-total">
                {" "}
                / {String(project.photos.length).padStart(2, "0")}
              </span>
            </span>
          </div>
          <p className="documentation-caption" key={photo.caption}>
            <LetterCopy text={photo.caption} />
          </p>
          <div className="documentation-summary">
            <h2>{project.name}</h2>
            <p>
              <span className="sr-only">{project.description}</span>
              <span aria-hidden="true">
                {project.description.split(" ").map((word, n) => (
                  <span className="documentation-summary-mask" key={n}>
                    <span className="documentation-summary-word">
                      {word}&nbsp;
                    </span>
                  </span>
                ))}
              </span>
            </p>
            <p className="label muted">{content.documentation.note}</p>
          </div>
          <div className="documentation-navigation">
            <Magnetic>
              <button
                className="button button-quiet"
                disabled={project.photos.length < 2}
                aria-label={content.documentation.previous}
                onClick={() => change(index - 1)}
              >
                <ArrowIcon direction="left" />
              </button>
            </Magnetic>
            <Magnetic>
              <button
                className="button button-quiet"
                disabled={project.photos.length < 2}
                aria-label={content.documentation.next}
                onClick={() => change(index + 1)}
              >
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.5"
                  aria-hidden="true"
                >
                  <path d="M4 12h16m-7-7 7 7-7 7" />
                </svg>
              </button>
            </Magnetic>
          </div>
        </aside>
        <nav
          className="documentation-thumbnails"
          aria-label={content.documentation.thumbnails}
        >
          {project.photos.map((item, n) => (
            <button
              key={item.src}
              className="documentation-thumb"
              aria-label={`${content.documentation.photo} ${n + 1}: ${item.alt}`}
              aria-current={n === index ? "true" : undefined}
              onClick={() => change(n)}
            >
              <DocumentationPhoto photo={item} decorative thumbnail />
              <span>{String(n + 1).padStart(2, "0")}</span>
            </button>
          ))}
        </nav>
      </div>
    </div>
  );
}
