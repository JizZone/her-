"use client";
import Image from "next/image";
import { useState } from "react";
import { content, type DocumentationPhoto as Photo } from "@/content";
export function DocumentationPhoto({
  photo,
  decorative = false,
  thumbnail = false,
}: {
  photo: Photo;
  decorative?: boolean;
  thumbnail?: boolean;
}) {
  const [failed, setFailed] = useState(false);
  const sizes = thumbnail ? "96px" : "(max-width: 800px) 100vw, 62vw";
  return (
    <picture className="documentation-picture">
      <source
        type="image/webp"
        srcSet={`${photo.src800} 800w, ${photo.src} 1600w`}
        sizes={sizes}
      />
      <source
        type="image/jpeg"
        srcSet={`${photo.jpeg800} 800w, ${photo.jpeg} 1600w`}
        sizes={sizes}
      />
      <Image
        src={thumbnail ? photo.jpeg800 : photo.jpeg}
        alt={decorative ? "" : photo.alt}
        fill
        sizes={sizes}
        placeholder="blur"
        blurDataURL={photo.blurDataURL}
        loading="eager"
        draggable={false}
        onError={() => setFailed(true)}
      />
      {failed && !decorative && (
        <span className="documentation-image-error" role="status">
          {content.documentation.unavailable}
        </span>
      )}
    </picture>
  );
}
