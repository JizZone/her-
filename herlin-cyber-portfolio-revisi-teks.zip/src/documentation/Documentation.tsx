"use client";
import { useRef, useState } from "react";
import { createPortal } from "react-dom";
import { content, type Project } from "@/content";
import { ArrowIcon } from "@/components/icons/Icons";
import { Magnetic } from "@/components/ui/Magnetic";
import { DocumentationViewer } from "./DocumentationViewer";
import "./documentation.css";
export function Documentation({ project }: { project: Project }) {
  const trigger = useRef<HTMLButtonElement>(null);
  const warmed = useRef(false);
  const [open, setOpen] = useState(false);
  const [origin, setOrigin] = useState({ x: 50, y: 50 });
  const prefetch = () => {
    if (warmed.current) return;
    const connection = (
      navigator as Navigator & {
        connection?: { saveData?: boolean; effectiveType?: string };
      }
    ).connection;
    if (connection?.saveData || /2g/.test(connection?.effectiveType || ""))
      return;
    warmed.current = true;
    const image = new Image();
    image.src =
      innerWidth <= 800 ? project.photos[0].src800 : project.photos[0].src;
  };
  return (
    <section
      className="documentation-launch"
      aria-labelledby={`documentation-title-${project.slug}`}
    >
      <h2 id={`documentation-title-${project.slug}`} className="label muted">
        {content.documentation.title}
      </h2>
      <Magnetic>
        <button
          ref={trigger}
          className="button documentation-button"
          aria-expanded={open}
          aria-controls={`documentation-${project.slug}`}
          onPointerEnter={(event) => {
            if (event.pointerType === "mouse") prefetch();
          }}
          onFocus={() => {
            if (matchMedia("(pointer:fine)").matches) prefetch();
          }}
          onClick={(event) => {
            const rect = event.currentTarget.getBoundingClientRect();
            setOrigin({
              x:
                ((event.detail ? event.clientX : rect.left + rect.width / 2) /
                  innerWidth) *
                100,
              y:
                ((event.detail ? event.clientY : rect.top + rect.height / 2) /
                  innerHeight) *
                100,
            });
            setOpen(true);
          }}
        >
          <span className="magnetic-text">{content.documentation.view}</span>
          <span className="documentation-count">
            ({String(project.photos.length).padStart(2, "0")})
          </span>
          <ArrowIcon />
        </button>
      </Magnetic>
      {open &&
        createPortal(
          <DocumentationViewer
            project={project}
            origin={origin}
            opener={trigger}
            onClose={() => setOpen(false)}
          />,
          document.body,
        )}
    </section>
  );
}
