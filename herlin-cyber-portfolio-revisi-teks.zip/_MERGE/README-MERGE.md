# Gabungan V1 + V2: herlin-portfolio-V1-V2-merged.zip

Isi: **seluruh project** (68 file V1 + 46 file baru V2 = 114 file), siap di-ekstrak ke root repo.

| Status | Jumlah | Arti |
|---|---|---|
| `M` | 15 | file V1 yang sudah diganti versi V2 (daftar di `MANIFEST.txt`) |
| `A` | 46 | file baru V2 (intro, documentation, foto, CREDITS.md, dst.) |
| `=` | 53 | file V1 yang **tidak disentuh** |
| hapus | **0** | tidak ada file yang dihapus dari ZIP |

`src/components/ui/Preloader.tsx` (loader V1) **masih ada di ZIP, tidak disentuh**. Sudah tidak dipanggil siapa pun, dan semua token/state yang ia pakai masih ada di V2, jadi tidak merusak build. Daftar file yang *boleh* dihapus nanti ada di `_MERGE/FILES-DELETE.txt`. **Jangan dihapus sebelum kamu memutuskan.**

Folder `_MERGE/` hanya catatan. Jangan ikut ter-commit (lihat langkah 4).

## Pasang di Codespaces

```bash
# 1. Backup + branch kerja (dari root repo)
git status --short                       # idealnya kosong
git checkout -b v1-backup && git push -u origin v1-backup
git checkout -b revisi-v2

# 2. Upload ZIP lewat Explorer (klik kanan > Upload...), lalu ekstrak ke folder sementara
mkdir -p /tmp/merged && unzip -q herlin-portfolio-V1-V2-merged.zip -d /tmp/merged
# tanpa unzip: python3 -m zipfile -e herlin-portfolio-V1-V2-merged.zip /tmp/merged

# 3. Pastikan repo masih sama dengan V1 (senyap = aman; ada FAILED = berhenti)
sha256sum -c --quiet /tmp/merged/_MERGE/BASELINE-SHA256.txt

# 4. Salin (hanya menimpa/menambah, tanpa menghapus; folder _MERGE tidak ikut)
tar -C /tmp/merged --exclude='./_MERGE' -cf - . | tar -xf -
git status --short -uall | wc -l          # harus 61 (15 diganti + 46 baru)

# 5. Pasang dan uji
npm ci
npm run build
npm run dev                              # buka port 3000 dari tab Ports
```

Bila `npm ci` gagal: `npm install`. `package.json` dan lockfile tidak berubah dari V1.

## Menghapus file lama (HANYA setelah kamu memerintahkan)

```bash
xargs -d '\n' rm -v < /tmp/merged/_MERGE/FILES-DELETE.txt
```

## Rollback

Sebelum commit: `git restore . && git clean -fd` (menghapus file baru yang belum di-commit). Sesudah commit: `git checkout v1-backup`.

## Catatan

- `AGENT-BUILD_INFO.md` = laporan asli dari AI agent V2 (tidak diubah).
- Belum terverifikasi: tampilan visual, FPS, dan uji HP. Kontak WhatsApp/Instagram/LinkedIn/CV masih `{{...}}` di `src/content.ts`.
