# BUILD INFO - Herlin Aprianti / TON 618 / V2 File 1

Tanggal: 22 Oktober 2026 (Asia/Jakarta).

## Ringkasan hasil dan batas penerimaan

Implementasi File 1 tersedia di patch ini. Build setiap tahap dan uji tambal dari baseline bersih lulus. Bukti visual yang diminta dan FPS transisi **belum terverifikasi**, sehingga penerimaan penuh V2 **belum dapat dinyatakan lulus**. Tidak ada angka FPS atau screenshot yang direkayasa. File 2 tidak dikerjakan.

| Revisi | Status bukti yang diminta | Bukti yang tersedia / batas |
| --- | --- | --- |
| 1A - loading terpisah | TIDAK - bukti visual belum lengkap | Build lulus. HTML Home memiliki satu intro terpisah; site-shell inert, aria-hidden=true, visibility:hidden. Detail tidak memuat intro. Grep tagline lama kosong. Screenshot desktop/390px belum tersedia. |
| 1B - entrance Home | TIDAK - bukti visual belum lengkap | Build lulus. Timeline memakai tokens.ts: 0 / 0,3 / 0,5 / 0,8 / 1,2 / 1,8 / 2,6 detik; rute 1,4 dan entrance singkat 0,9. Urutan screenshot t=0/0,8/1,4/2,0/2,6 belum tersedia. |
| 2A - foto dan konten | LULUS - pemeriksaan aset/konten | 9 foto nyata, 36 varian. Ukuran/dimensi dicek programatis, crop ditinjau visual, lisensi dan sumber dicatat di CREDITS.md. Jumlah 3/2/1/3 memenuhi minimum 1 yang diizinkan. |
| 2B - viewer setelah klik | LULUS - pemeriksaan kode dan HTML awal | Keempat detail memiliki nol img dan satu tombol tertutup pada HTML awal. Portal hanya dibuat setelah klik. Kontrol, trap fokus, scroll lock dan swipe ada pada source. Pengujian interaksi dalam browser belum tersedia; ini bukan klaim QA interaksi lulus. |
| 2C - transisi galeri | TIDAK - screenshot/FPS belum tersedia | Build lulus. Iris + 5 slice, skala/parallax, masked caption, angka bergulir, thumbnail dan reduced motion diimplementasikan. Varian clip-path + skala dipilih; RGB-split tidak diaktifkan tanpa bukti ambang FPS. |

Browser QA ditolak oleh kebijakan lingkungan ketika memperoleh akses ke tab preview. Pesan asli: `Browser Use rejected this action due to browser security policy. ... Cloud browser could not acquire authority to observe page content. ... The requested URL protocol is not allowed.` Tidak digunakan jalur browser alternatif untuk menghindari penolakan tersebut. Karena itu tidak ada screenshot/GIF, pengujian viewport hidup 390px, atau pengukuran FPS yang dapat dilaporkan. Tidak ada klaim 55/30/60 fps.

## Baseline dan isi patch

Baseline dibuat SEBELUM perubahan source dari paket `Herlin-TON618-Codespaces.zip` yang terakhir diserahkan, bukan dari konfigurasi hosting lain.

- Commit baseline-v1: `59502cfa3d285295f7bb6323991cb3c872bcd6f1`.
- SHA-256 ZIP V1: `cec2b8c8bad515c1eae0cccec3b44d0567e1b53e286d16dcbdab50cb976f47eb`.
- File baru/berubah: **61**; dihapus: **1**.
- `repo/` hanya berisi A/M dengan path relatif root repository.
- `package.json` berubah: **TIDAK**. `package-lock.json` berubah: **TIDAK**. Keduanya identik byte demi byte dengan baseline dan tidak masuk patch. Tidak ada dependensi baru; `npm install` tambahan tidak diperlukan untuk perubahan ini.
- Tidak ada node_modules, .next, .git, .env*, docs, prompt, README tambahan, screenshot, browser binary, atau hasil build dalam ZIP.
- Semua foto nyata; tidak ada placeholder foto, maka ASSETS-TODO.md tidak dibuat.

Langkah A dijalankan dengan git init, git add -A, commit `baseline-v1` memakai identitas agent@local, kemudian git rev-parse HEAD disimpan ke /tmp/BASE. Baseline mencakup seluruh 68 file paket V1.

## Perilaku implementasi

- Intro hanya pada kunjungan Home awal sesi. Direct /work/* tidak menjalankannya. Kembali secara internal ke Home memakai paket transisi halaman + entrance singkat. `?intro=1` pada pembukaan/reload Home memaksa intro.
- Progres menggabungkan document.fonts.ready (35%), gambar kritis yang berhasil decode (35%), dan renderer/asset/frame (30%). Nilai ditahan maksimum 99 sampai syarat waktu terpenuhi. Minimum 2 detik; deadline 6 detik beralih ke fallback statis. Reduced motion memakai loading 0,8 detik, tanpa rolling digits, lalu crossfade 0,3 detik.
- Saat intro/loading: seluruh situs termasuk nav, hero, canvas, skip-link dan cursor berada di shell tersembunyi/inert. Saat entrance: shell terungkap dengan circle, tetapi inert dan scroll lock bertahan sampai timeline selesai.
- Dokumentasi desktop melakukan prefetch foto pertama hanya saat hover/fokus; Save-Data/2G membatalkan prefetch. Pada sentuh, tidak ada prefetch otomatis: foto diminta setelah klik. Ini memilih jalur hover/fokus dari opsi prefetch yang diizinkan dan menghindari dugaan network-idle.
- Penjelasan serta meta selalu terlihat. Teks Challenge/Approach/Outcome V1 tetap ada. Diagram V1 tidak lagi dirender otomatis di halaman detail; aset diagram lama tidak dihapus karena patch tidak membutuhkan penghapusannya.
- Viewer memakai portal di luar shell inert, tombol Close, Escape, klik area kosong, panah keyboard, swipe, thumbnail, serta fokus kembali ke pembuka. Canvas di belakang dipause ketika viewer terbuka.
- Buka 1,4 detik; ganti 0,9 detik (keluar 0,4 + masuk 0,5); tutup 1,0 detik. Lima slice masuk dengan stagger 0,08 saat buka. Caption memakai stagger huruf yang dibatasi anggaran waktu agar caption panjang tetap selesai dalam 1,4 detik. Parallax desktop maksimum 12px / 2 derajat; nonaktif di sentuh dan reduced motion.
- RGB-split tidak diaktifkan: ambang FPS belum terbukti. Reduced motion menggunakan crossfade total 0,3 detik, termasuk pergantian foto.
- Email resmi terpusat pada profile.email: herlinaprianti5@gmail.com; dipakai mailto, copy dan metadata. Field kontak lain tetap mengikuti V1.

## Daftar file dan alasan

| Status | Path | Alasan |
| --- | --- | --- |
| A | `CREDITS.md` | Atribusi foto Pexels, lisensi, crop, konteks foto referensi, serta referensi UI MIT. |
| A | `public/work/audit-ready/01-800.jpg` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/audit-ready/01-800.webp` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/audit-ready/01.jpg` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/audit-ready/01.webp` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/audit-ready/02-800.jpg` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/audit-ready/02-800.webp` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/audit-ready/02.jpg` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/audit-ready/02.webp` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/dossier/01-800.jpg` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/dossier/01-800.webp` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/dossier/01.jpg` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/dossier/01.webp` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/dossier/02-800.jpg` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/dossier/02-800.webp` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/dossier/02.jpg` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/dossier/02.webp` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/dossier/03-800.jpg` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/dossier/03-800.webp` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/dossier/03.jpg` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/dossier/03.webp` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/scale-up/01-800.jpg` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/scale-up/01-800.webp` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/scale-up/01.jpg` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/scale-up/01.webp` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/shelf-life/01-800.jpg` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/shelf-life/01-800.webp` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/shelf-life/01.jpg` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/shelf-life/01.webp` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/shelf-life/02-800.jpg` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/shelf-life/02-800.webp` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/shelf-life/02.jpg` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/shelf-life/02.webp` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/shelf-life/03-800.jpg` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/shelf-life/03-800.webp` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/shelf-life/03.jpg` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| A | `public/work/shelf-life/03.webp` | Foto dokumentasi lokal: varian resolusi/format untuk galeri setelah klik; atribusi pada CREDITS.md. |
| M | `src/app/layout.tsx` | Memisahkan seluruh konten situs di IntroShell dan menambahkan metadata email resmi. |
| M | `src/components/canvas/Experience.tsx` | Menghentikan render Canvas ketika viewer dokumentasi terbuka. |
| M | `src/components/canvas/HeroText.tsx` | Reveal nama terpisah dari ignition disk; mask dan rotasi per huruf. |
| M | `src/components/canvas/LensingPass.tsx` | Mengalikan kekuatan lensing dengan envelope intro 3 ke 1. |
| M | `src/components/canvas/Ton618.tsx` | Menandai kesiapan frame Canvas nyata setelah frame awal. |
| M | `src/components/ui/Cursor.tsx` | Kursor baru aktif setelah intro dan transisi halaman berakhir. |
| M | `src/components/ui/FallbackHero.tsx` | Menambahkan mask per huruf untuk entrance nama pada fallback statis. |
| M | `src/components/ui/Menu.tsx` | Mencegah menu membuka Lenis selama pemilik lain masih mengunci scroll. |
| M | `src/components/ui/ProjectDetail.tsx` | Mempertahankan penjelasan/meta V1, menambahkan tombol dokumentasi, menghapus gambar otomatis dari markup detail. |
| M | `src/components/ui/Runtime.tsx` | Menghapus loader V1; memastikan pemeriksaan renderer dan deadline mengikuti intro V2. |
| M | `src/components/ui/TransitionOverlay.tsx` | Mempertahankan paket transisi 1,4 detik dan menambahkan entrance Home 0,9 detik. |
| M | `src/content.ts` | Email resmi, deskripsi dua kalimat, seluruh alt/caption/label dan metadata foto terpusat. |
| A | `src/documentation/Documentation.tsx` | Tombol tunggal dengan jumlah aktual, aria-expanded/controls, prefetch desktop dan portal setelah klik. |
| A | `src/documentation/DocumentationPhoto.tsx` | next/image dalam picture dengan WebP/JPEG 800/1600, sizes, blurDataURL dan alt. |
| A | `src/documentation/DocumentationViewer.tsx` | Viewer penuh, keyboard/swipe/focus trap, lima slice, iris, rolling digits, close dan parallax. |
| A | `src/documentation/documentation.css` | Layout viewer responsif, mask, thumbnail dan warna ink/bone/gold. |
| A | `src/intro/IntroLoader.tsx` | Markup loader mandiri serta satu timeline GSAP entrance Home 2,6 detik. |
| A | `src/intro/IntroShell.tsx` | inert/aria-hidden/visibility dan pembatasan interaksi ketika intro atau overlay aktif. |
| A | `src/intro/intro.css` | Layar hitam fixed, monogram SVG, ring tipis, angka bergulir dan garis gold. |
| A | `src/intro/useIntro.ts` | Kesiapan font, fallback, asset loader dan frame; sessionStorage, ?intro=1, minimum/deadline dan reduced motion. |
| M | `src/lib/lenis.ts` | Menghormati kunci scroll yang telah aktif saat Lenis dibuat. |
| A | `src/lib/scroll-lock.ts` | Kunci scroll bersama agar intro, rute dan viewer tidak saling membuka kunci. |
| M | `src/lib/store.ts` | State kesiapan intro/frame, envelope nama/lensing dan status viewer. |
| M | `src/lib/tokens.ts` | Durasi dan parameter V2 terpusat; cursor tetap terlihat di atas viewer setelah intro. |
| D | `src/components/ui/Preloader.tsx` | Loader V1 diganti oleh modul intro mandiri; hindari dua loader dan dua counter. |

## Bukti grep dan perintah wajib (output asli)

Exit 1 pada grep/rg tanpa hasil berarti tidak ditemukan kecocokan.

```text
$ grep -rIn "Alexander\|Smith\|example.com\|Jakarta\|Dribbble\|glass-knot\|Placeholder\|Illustrative\|Vol\. 01" src public | wc -l
0
[exit 0]

$ grep -rIn "↗\|↘\|↖\|↑\|✳\|↔" src | wc -l
0
[exit 0]

$ ls public/images 2>/dev/null | grep -i "glass-knot" | wc -l
0
[exit 0]

$ grep -rIn "hello@example.com\|{{EMAIL}}" src public | wc -l
0
[exit 0]

$ grep -rIn "herlinaprianti5@gmail.com" src | wc -l
1
[exit 0]

$ wc -l /tmp/patch/_PATCH/FILES-CHANGED.txt /tmp/patch/_PATCH/FILES-DELETE.txt
  61 /tmp/patch/_PATCH/FILES-CHANGED.txt
   1 /tmp/patch/_PATCH/FILES-DELETE.txt
  62 total
[exit 0]

$ grep -r "Shaping the experience\|A little less ordinary" src
[exit 1]

$ rg -n "duration: [0-9]" src/intro src/documentation
[exit 1]

$ rg -n "sessionStorage|document.fonts.ready|frameReady|deadline|internalVisit" src/intro/useIntro.ts
11:    sessionStorage.setItem(sessionKey, "seen");
28:    const internalVisit =
33:      seen = sessionStorage.getItem(sessionKey) === "seen";
36:    if (pathname !== "/" || ((seen || internalVisit) && !force)) {
39:          sessionStorage.setItem(sessionKey, "seen");
60:    document.fonts.ready.then(() => {
79:        (!state.webgl || (state.sceneReady && state.frameReady));
89:      const deadline = age >= (reduce ? T.intro.reduced : T.intro.maximum);
90:      if (deadline || (fonts && image && scene && age >= T.intro.minimum)) {
91:        if (deadline || !scene || reduce)
[exit 0]

$ rg -n "aria-expanded|aria-controls|createPortal|onPointerEnter|onFocus" src/documentation/Documentation.tsx
3:import { createPortal } from "react-dom";
40:          aria-expanded={open}
41:          aria-controls={`documentation-${project.slug}`}
42:          onPointerEnter={(event) => {
45:          onFocus={() => {
71:        createPortal(
[exit 0]

$ rg -n "Escape|ArrowRight|ArrowLeft|Tab|focus|swipeEnd|lockScroll|unlockScroll|data-effect" src/documentation/DocumentationViewer.tsx
15:import { lockScroll, unlockScroll } from "@/lib/scroll-lock";
72:    lockScroll("documentation");
75:      ?.focus({ preventScroll: true });
80:      unlockScroll("documentation");
83:          opener.current?.focus({ preventScroll: true });
348:  const swipeEnd = (event: PointerEvent) => {
395:      data-effect="clip-scale"
409:        if (event.key === "Escape") {
413:        if (event.key === "ArrowRight") {
417:        if (event.key === "ArrowLeft") {
421:        if (event.key === "Tab") {
434:          ]?.focus();
490:          onPointerUp={swipeEnd}
[exit 0]

```

## Pemeriksaan HTML awal dan aset

```text
dossier: 0 img elements; one collapsed documentation trigger; no intro loader; 3 photos configured
audit-ready: 0 img elements; one collapsed documentation trigger; no intro loader; 2 photos configured
scale-up: 0 img elements; one collapsed documentation trigger; no intro loader; 1 photos configured
shelf-life: 0 img elements; one collapsed documentation trigger; no intro loader; 3 photos configured
Home SSR: one standalone intro; site-shell inert + aria-hidden=true + visibility:hidden; official email in metadata and mailto
Assets: 36 files; max 249978 bytes; all 800/1600px; ratios 3:2 and 4:5 verified
package.json and package-lock.json: byte-identical to baseline
Authored source comment/marker scan: zero matches
```

| Aset | Dimensi | Byte |
| --- | --- | ---: |
| `public/work/audit-ready/01-800.jpg` | 800 x 533 | 56110 |
| `public/work/audit-ready/01-800.webp` | 800 x 533 | 27496 |
| `public/work/audit-ready/01.jpg` | 1600 x 1067 | 242013 |
| `public/work/audit-ready/01.webp` | 1600 x 1067 | 138028 |
| `public/work/audit-ready/02-800.jpg` | 800 x 1000 | 71527 |
| `public/work/audit-ready/02-800.webp` | 800 x 1000 | 34058 |
| `public/work/audit-ready/02.jpg` | 1600 x 2000 | 225745 |
| `public/work/audit-ready/02.webp` | 1600 x 2000 | 133030 |
| `public/work/dossier/01-800.jpg` | 800 x 533 | 55470 |
| `public/work/dossier/01-800.webp` | 800 x 533 | 31232 |
| `public/work/dossier/01.jpg` | 1600 x 1067 | 152614 |
| `public/work/dossier/01.webp` | 1600 x 1067 | 72630 |
| `public/work/dossier/02-800.jpg` | 800 x 1000 | 61252 |
| `public/work/dossier/02-800.webp` | 800 x 1000 | 28596 |
| `public/work/dossier/02.jpg` | 1600 x 2000 | 219526 |
| `public/work/dossier/02.webp` | 1600 x 2000 | 86346 |
| `public/work/dossier/03-800.jpg` | 800 x 1000 | 87154 |
| `public/work/dossier/03-800.webp` | 800 x 1000 | 48528 |
| `public/work/dossier/03.jpg` | 1600 x 2000 | 234223 |
| `public/work/dossier/03.webp` | 1600 x 2000 | 198520 |
| `public/work/scale-up/01-800.jpg` | 800 x 533 | 99984 |
| `public/work/scale-up/01-800.webp` | 800 x 533 | 77086 |
| `public/work/scale-up/01.jpg` | 1600 x 1067 | 249978 |
| `public/work/scale-up/01.webp` | 1600 x 1067 | 222684 |
| `public/work/shelf-life/01-800.jpg` | 800 x 533 | 61596 |
| `public/work/shelf-life/01-800.webp` | 800 x 533 | 38408 |
| `public/work/shelf-life/01.jpg` | 1600 x 1067 | 185112 |
| `public/work/shelf-life/01.webp` | 1600 x 1067 | 91936 |
| `public/work/shelf-life/02-800.jpg` | 800 x 1000 | 98962 |
| `public/work/shelf-life/02-800.webp` | 800 x 1000 | 63998 |
| `public/work/shelf-life/02.jpg` | 1600 x 2000 | 234703 |
| `public/work/shelf-life/02.webp` | 1600 x 2000 | 164898 |
| `public/work/shelf-life/03-800.jpg` | 800 x 1000 | 106169 |
| `public/work/shelf-life/03-800.webp` | 800 x 1000 | 53974 |
| `public/work/shelf-life/03.jpg` | 1600 x 2000 | 246317 |
| `public/work/shelf-life/03.webp` | 1600 x 2000 | 201648 |

Foto yang belum tersedia persis sesuai daftar referensi: koridor cleanroom tanpa wajah/marka, tablet press dan pilot equipment. Dipilih foto aman dan relevan dalam jumlah minimum yang diizinkan; foto alat laboratorium tidak dilabeli sebagai tablet press atau fasilitas milik Herlin. Foto meja kerja memakai desktop, bukan laptop. Semua foto merupakan konteks referensi, bukan bukti pekerjaan/klien pribadi. Rincian sumber dan crop ada di CREDITS.md.

## Build per tahap (output asli)

### 1A - exit 0

```text
npm warn Unknown env config "http-proxy". This will stop working in the next major version of npm.

> herlin-aprianti-portfolio@1.0.0 build
> next build --webpack

▲ Next.js 16.4.2 (webpack)
✓ Running next.config.ts took 34ms

  Creating an optimized production build ...
✓ Compiled successfully in 3.9s
  Running TypeScript ...
  Finished TypeScript in 2.6s ...
  Collecting page data using 8 workers ...
  Generating static pages using 8 workers (0/10) ...
⚠ metadataBase property in metadata export is not set for resolving social open graph or twitter images, using "http://localhost:3000". See https://nextjs.org/docs/app/api-reference/functions/generate-metadata#metadatabase
  Generating static pages using 8 workers (2/10) 
  Generating static pages using 8 workers (4/10) 
  Generating static pages using 8 workers (7/10) 
✓ Generating static pages using 8 workers (10/10) in 759ms
  Finalizing page optimization ...
  Collecting build traces ...

Route (app)
┌ ○ /
├ ○ /_not-found
├ ○ /icon.svg
├ ○ /robots.txt
├ ○ /sitemap.xml
└   /work/[slug]
  ├ ● /work/dossier
  ├ ● /work/audit-ready
  ├ ● /work/scale-up
  └ ● /work/shelf-life


○  (Static)  prerendered as static content
●  (SSG)     prerendered as static HTML (uses generateStaticParams)

```

### 1B - exit 0

```text
npm warn Unknown env config "http-proxy". This will stop working in the next major version of npm.

> herlin-aprianti-portfolio@1.0.0 build
> next build --webpack

▲ Next.js 16.4.2 (webpack)
✓ Running next.config.ts took 31ms

  Creating an optimized production build ...
✓ Compiled successfully in 6.0s
  Running TypeScript ...
  Finished TypeScript in 3.2s ...
  Collecting page data using 8 workers ...
  Generating static pages using 8 workers (0/10) ...
⚠ metadataBase property in metadata export is not set for resolving social open graph or twitter images, using "http://localhost:3000". See https://nextjs.org/docs/app/api-reference/functions/generate-metadata#metadatabase
  Generating static pages using 8 workers (2/10) 
  Generating static pages using 8 workers (4/10) 
  Generating static pages using 8 workers (7/10) 
✓ Generating static pages using 8 workers (10/10) in 1438ms
  Finalizing page optimization ...
  Collecting build traces ...

Route (app)
┌ ○ /
├ ○ /_not-found
├ ○ /icon.svg
├ ○ /robots.txt
├ ○ /sitemap.xml
└   /work/[slug]
  ├ ● /work/dossier
  ├ ● /work/audit-ready
  ├ ● /work/scale-up
  └ ● /work/shelf-life


○  (Static)  prerendered as static content
●  (SSG)     prerendered as static HTML (uses generateStaticParams)

```

### 2A/2B - exit 0

```text
npm warn Unknown env config "http-proxy". This will stop working in the next major version of npm.

> herlin-aprianti-portfolio@1.0.0 build
> next build --webpack

▲ Next.js 16.4.2 (webpack)
✓ Running next.config.ts took 30ms

  Creating an optimized production build ...
✓ Compiled successfully in 5.1s
  Running TypeScript ...
  Finished TypeScript in 5.7s ...
  Collecting page data using 8 workers ...
  Generating static pages using 8 workers (0/10) ...
⚠ metadataBase property in metadata export is not set for resolving social open graph or twitter images, using "http://localhost:3000". See https://nextjs.org/docs/app/api-reference/functions/generate-metadata#metadatabase
  Generating static pages using 8 workers (2/10) 
  Generating static pages using 8 workers (4/10) 
  Generating static pages using 8 workers (7/10) 
✓ Generating static pages using 8 workers (10/10) in 1159ms
  Finalizing page optimization ...
  Collecting build traces ...

Route (app)
┌ ○ /
├ ○ /_not-found
├ ○ /icon.svg
├ ○ /robots.txt
├ ○ /sitemap.xml
└   /work/[slug]
  ├ ● /work/dossier
  ├ ● /work/audit-ready
  ├ ● /work/scale-up
  └ ● /work/shelf-life


○  (Static)  prerendered as static content
●  (SSG)     prerendered as static HTML (uses generateStaticParams)

```

### 2C - exit 0

```text
npm warn Unknown env config "http-proxy". This will stop working in the next major version of npm.

> herlin-aprianti-portfolio@1.0.0 build
> next build --webpack

▲ Next.js 16.4.2 (webpack)
✓ Running next.config.ts took 31ms

  Creating an optimized production build ...
✓ Compiled successfully in 3.9s
  Running TypeScript ...
  Finished TypeScript in 4.4s ...
  Collecting page data using 8 workers ...
  Generating static pages using 8 workers (0/10) ...
⚠ metadataBase property in metadata export is not set for resolving social open graph or twitter images, using "http://localhost:3000". See https://nextjs.org/docs/app/api-reference/functions/generate-metadata#metadatabase
  Generating static pages using 8 workers (2/10) 
  Generating static pages using 8 workers (4/10) 
  Generating static pages using 8 workers (7/10) 
✓ Generating static pages using 8 workers (10/10) in 749ms
  Finalizing page optimization ...
  Collecting build traces ...

Route (app)
┌ ○ /
├ ○ /_not-found
├ ○ /icon.svg
├ ○ /robots.txt
├ ○ /sitemap.xml
└   /work/[slug]
  ├ ● /work/dossier
  ├ ● /work/audit-ready
  ├ ● /work/scale-up
  └ ● /work/shelf-life


○  (Static)  prerendered as static content
●  (SSG)     prerendered as static HTML (uses generateStaticParams)

```

### Final setelah perbaikan integrasi - exit 0

```text
npm warn Unknown env config "http-proxy". This will stop working in the next major version of npm.

> herlin-aprianti-portfolio@1.0.0 build
> next build --webpack

▲ Next.js 16.4.2 (webpack)
✓ Running next.config.ts took 29ms

  Creating an optimized production build ...
✓ Compiled successfully in 5.1s
  Running TypeScript ...
  Finished TypeScript in 3.5s ...
  Collecting page data using 8 workers ...
  Generating static pages using 8 workers (0/10) ...
⚠ metadataBase property in metadata export is not set for resolving social open graph or twitter images, using "http://localhost:3000". See https://nextjs.org/docs/app/api-reference/functions/generate-metadata#metadatabase
  Generating static pages using 8 workers (2/10) 
  Generating static pages using 8 workers (4/10) 
  Generating static pages using 8 workers (7/10) 
✓ Generating static pages using 8 workers (10/10) in 819ms
  Finalizing page optimization ...
  Collecting build traces ...

Route (app)
┌ ○ /
├ ○ /_not-found
├ ○ /icon.svg
├ ○ /robots.txt
├ ○ /sitemap.xml
└   /work/[slug]
  ├ ● /work/dossier
  ├ ● /work/audit-ready
  ├ ● /work/scale-up
  └ ● /work/shelf-life


○  (Static)  prerendered as static content
●  (SSG)     prerendered as static HTML (uses generateStaticParams)

```

## Uji tambal bersih - Langkah C

Baseline diekstrak dengan git archive ke /tmp/verify yang baru. Pemeriksaan checksum dilakukan SEBELUM file patch disalin:

```text
$ sha256sum -c --quiet /tmp/patch/_PATCH/BASELINE-SHA256.txt
[stdout kosong, stderr kosong, exit 0]
```

Kemudian repo/ disalin, apply-delete.sh --yes dijalankan, npm ci, dan npm run build. Output asli:

```text
File yang akan dihapus:
src/components/ui/Preloader.tsx
Selesai.
npm warn Unknown env config "http-proxy". This will stop working in the next major version of npm.

added 102 packages in 11s
npm warn Unknown env config "http-proxy". This will stop working in the next major version of npm.

> herlin-aprianti-portfolio@1.0.0 build
> next build --webpack

▲ Next.js 16.4.2 (webpack)
✓ Running next.config.ts took 34ms

  Creating an optimized production build ...
✓ Compiled successfully in 13.8s
  Running TypeScript ...
  Finished TypeScript in 5.1s ...
  Collecting page data using 8 workers ...
  Generating static pages using 8 workers (0/10) ...
⚠ metadataBase property in metadata export is not set for resolving social open graph or twitter images, using "http://localhost:3000". See https://nextjs.org/docs/app/api-reference/functions/generate-metadata#metadatabase
  Generating static pages using 8 workers (2/10) 
  Generating static pages using 8 workers (4/10) 
  Generating static pages using 8 workers (7/10) 
✓ Generating static pages using 8 workers (10/10) in 815ms
  Finalizing page optimization ...
  Collecting build traces ...

Route (app)
┌ ○ /
├ ○ /_not-found
├ ○ /icon.svg
├ ○ /robots.txt
├ ○ /sitemap.xml
└   /work/[slug]
  ├ ● /work/dossier
  ├ ● /work/audit-ready
  ├ ● /work/scale-up
  └ ● /work/shelf-life


○  (Static)  prerendered as static content
●  (SSG)     prerendered as static HTML (uses generateStaticParams)

```

Perbandingan source setelah tambal:

```text
$ diff -rq --exclude=node_modules --exclude=.next --exclude=.git /workspace/scratch/c10beee15cbc/herlin-portfolio /tmp/verify
[stdout kosong, stderr kosong, exit 0]
```

Sebelum diff, folder hasil build `out/` dari kedua pohon dipindahkan ke lokasi bukti di luar repo. Output Next.js memuat build ID berbeda setiap build; output tersebut tidak termasuk source/patch. Tidak ada file source/aset yang dikecualikan selain direktori node_modules, .next, .git pada perintah di atas. next-env.d.ts hasil kedua build tetap dibandingkan. Set repo/ juga dibandingkan langsung dengan daftar staged A/M: sama persis, dan semua byte file cocok.

Uji tambal diulang dari baseline bersih setelah perbaikan terakhir. Folder verifikasi pertama dipertahankan terpisah; tidak dipakai sebagai baseline pengujian terakhir.

apply-delete.sh diperketat: hanya path relatif dalam repo, bukan symlink, dan checksum harus sama dengan V1 sebelum penghapusan. Script meminta konfirmasi kecuali --yes; tidak memakai penghapusan rekursif/paksa. Ini menghapus hanya src/components/ui/Preloader.tsx pada uji tambal.

## Hal yang belum selesai / belum terbukti

1. Screenshot loading desktop dan 390px, urutan waktu entrance Home, serta urutan buka/pindah/tutup viewer: belum tersedia karena browser QA ditolak kebijakan lingkungan.
2. FPS desktop/mobile, kelancaran aktual, swipe perangkat fisik, focus trap/return focus pada browser, sesi ulang dan reduced-motion pada browser: belum diverifikasi langsung. Build dan pemeriksaan source/HTML tidak menggantikan pengujian tersebut.
3. RGB-split sengaja tidak aktif tanpa pembuktian FPS; fallback clip-path/skala yang diizinkan dipakai.
4. Foto khusus cleanroom corridor/tablet press/pilot equipment tidak cukup memenuhi batas bebas wajah/logo pada sumber yang ditemukan. Minimum 1 foto per proyek dipenuhi dengan foto nyata, tanpa foto rekaan.
5. Build memunculkan warning metadataBase karena SITE_ORIGIN belum diisi pada lingkungan pengujian. Konfigurasi origin V1 tetap berlaku; tidak ada .env dalam patch. Ini tidak menggagalkan build.
6. Tidak ada deployment atau perubahan hosting. Output hanya ZIP tambal File 1. File 2 tidak disentuh.

## Cara menerapkan

Ekstrak ZIP di luar root repo. Simpan perubahan lokal sebelum menimpa. Dari root repo V1:

```bash
sha256sum -c /lokasi/patch/_PATCH/BASELINE-SHA256.txt
cp -a /lokasi/patch/repo/. .
bash /lokasi/patch/_PATCH/apply-delete.sh --yes
npm run build
```

Jika checksum berbeda, jangan menimpa file yang berbeda sebelum mencocokkan perubahan lokal. Isi _PATCH/ tidak disalin ke repo. Tidak perlu menambahkan package.json atau lockfile karena dependensi tidak berubah.

## Verifikasi ZIP - Langkah D

Struktur diperiksa: 61 file di repo/ dan 5 berkas catatan di _PATCH/. Tidak ada file terlarang atau file source yang tidak berubah.

Output uji CRC (diulang pula pada arsip akhir setelah catatan ini ditambahkan):

```text
    testing: repo/src/lib/store.ts    OK
    testing: repo/src/lib/tokens.ts   OK
No errors detected in compressed data of /tmp/herlin-portfolio-v2-patch.zip.
```

Daftar arsip juga diperiksa dengan unzip -l. ZIP akhir hanya satu: herlin-portfolio-v2-patch.zip.
