# Cyber Ronin + Portofolio Herlin — Paket lengkap

Paket ini berisi seluruh proyek portofolio V1–V2 yang kamu unggah, ditambah layar pembuka Cyber Ronin. Tidak memerlukan ZIP V1 atau patch V2 terpisah.

Paket ini sudah memuat revisi dua teks Cyber. Laporan perubahan dan verifikasi ada di `_INTEGRATION/REVISI-TEKS.md`.

## Alur yang dipasang

1. Buka halaman Home pada kunjungan pertama di browser tersebut.
2. Cyber Ronin tampil; tunggu Metatron selesai terbentuk, lalu sentuh/klik Metatron. Keyboard: Tab untuk fokus, lalu Enter atau Space.
3. Efek Cyber menutupi layar dengan hitam.
4. Animasi Cyber berhenti; resource WebGL dilepas dan iframe Cyber dihapus.
5. Loading portofolio asli berjalan, dilanjutkan entrance dan Home.

Cyber tidak memiliki tombol replay dan tidak kembali saat berpindah halaman, menekan Back, atau me-refresh setelah masuk. Penanda sekali-masuk disimpan di localStorage, dengan sessionStorage dan state halaman sebagai cadangan. Browser/profil lain atau penghapusan data situs dianggap kunjungan baru. Tidak ada cara bagi situs untuk menjamin penanda tetap ada setelah pengguna menghapus data browser.

Link langsung ke `/work/*` tetap menuju detail proyek. `?intro=1` hanya memaksa loading portofolio sesuai perilaku asli; tidak mengulang Cyber yang sudah dilewati.

## Memasang di Codespaces

Gunakan folder/repository kosong untuk paket lengkap ini. Jika repository lama berisi perubahanmu, simpan commit/backup terlebih dahulu dan ekstrak paket ke folder terpisah untuk membandingkan file sebelum menimpa.

1. Buat/buka Codespace, lalu unggah `herlin-cyber-portfolio-revisi-teks.zip` melalui Explorer.
2. Di terminal, masuk ke folder yang berisi ZIP. Ekstrak ke folder proyek baru:

```bash
unzip -t herlin-cyber-portfolio-revisi-teks.zip
unzip herlin-cyber-portfolio-revisi-teks.zip -d herlin-cyber-portfolio
cd herlin-cyber-portfolio
```

3. Pastikan root folder tersebut langsung berisi `package.json`, `src/`, `public/` dan `.devcontainer/`. Gunakan Node.js 22 sebagaimana konfigurasi Codespaces yang disertakan, lalu:

```bash
npm ci
npm run build
npm run dev
```

Jalankan satu per satu. Jika build gagal, berhenti dan periksa outputnya sebelum menjalankan preview.

4. Buka panel **Ports**, cari port **3000**, lalu **Open in Browser**. Untuk preview pribadi di Codespaces, pertahankan visibilitas port **Private**. Buka URL pada browser dengan sesi GitHub yang memiliki akses ke Codespace tersebut.
5. Untuk menjadikan proyek root repository, pindahkan **isi folder** `herlin-cyber-portfolio/` ke root repository setelah memastikan tidak ada file lain yang tertimpa. Folder `.devcontainer/` perlu berada di root jika ingin konfigurasi container otomatis digunakan saat Codespace dibuat/rebuild. Jangan pindahkan atau menimpa folder `.git` milik repository.
6. Setelah pemeriksaan selesai, commit source dan aset. Jangan commit ZIP unggahan, `node_modules/`, `.next/`, `out/` atau `.env` pribadi.

Paket tidak menyertakan dependensi terpasang atau hasil build. `package.json` dan `package-lock.json` sama dengan unggahan V1–V2; Cyber memakai Three.js 0.160.0 lokal yang terisolasi di `public/cyber/vendor/`.

## Struktur tambahan

| Path | Fungsi |
| --- | --- |
| `src/cyber/CyberGate.tsx` | Memasang Cyber sebelum portofolio, menyimpan status sekali-masuk dan melepas iframe setelah selesai. |
| `src/cyber/cyber.css` | Lapisan penuh viewport; memakai `--ink` dan `--bone` portofolio. |
| `public/cyber/index.html` | Dokumen terisolasi yang membaca warna aktual dari CSS halaman portofolio. |
| `public/cyber/ronin.js` | Adegan Cyber asli yang disesuaikan untuk masuk sekali dan cleanup resource. |
| `public/cyber/ronin.glb` | Model asli, diekstrak byte-for-byte dari HTML unggahan. |
| `public/cyber/boot.js` | Memulai adegan, menangani fallback, lalu mengirim sinyal selesai. |
| `public/cyber/frame.css` | Tata letak Cyber, area sentuh, safe area dan latar. |
| `public/cyber/vendor/` | Runtime Three.js yang cocok dengan Cyber asli, beserta lisensi. |
| `_INTEGRATION/BUILD_INFO.md` | Hasil pemeriksaan integrasi dan batas pengujian. |
| `_MERGE/` | Catatan gabungan V1–V2 dari ZIP unggahan; disimpan sebagai riwayat. |

Seluruh file `src/intro/`, konten portofolio, foto galeri dan CSS portofolio asli dipertahankan. Perubahan pada file lama hanya pembungkus `CyberGate` di `src/app/layout.tsx` serta tambahan atribusi di `CREDITS.md`.

## Warna dan tampilan

Latar Cyber membaca `--bone` dari CSS portofolio, saat ini **#EDEAE4**. Blackout membaca `--ink`, saat ini **#0A0A0A**. Nilainya tidak ditebak dari screenshot. Warna model, cahaya dan efek karakter Cyber tetap berasal dari adegan aslinya.

Layout memakai ukuran viewport, `100dvh`, safe-area dan perhitungan kamera berdasarkan rasio layar. Target Metatron minimal 56 CSS px. Render pixel ratio dibatasi untuk mengurangi beban GPU pada perangkat sentuh. Jika WebGL tidak tersedia atau model gagal dimuat, Metatron statis tetap dapat disentuh untuk masuk.

Preview diperiksa pada beberapa ukuran layar, bukan seluruh model HP/laptop fisik. Lingkungan browser pengujian menonaktifkan WebGL sehingga jalur animasi 3D penuh dan FPS perangkat fisik belum terverifikasi. Rincian pemeriksaan ada di `_INTEGRATION/BUILD_INFO.md`.

## Preview privat dan publikasi sendiri

Tautan privat versi integrasi sebelumnya tercatat di `_INTEGRATION/PRIVATE-PREVIEW.md`. Revisi dua teks ini disediakan dalam ZIP dan belum diterbitkan ulang ke tautan tersebut. Akses privat mengikuti akun ChatGPT pemilik Site.

Untuk hosting milikmu, proyek menghasilkan static export dalam `out/` melalui `npm run build`. Isi `SITE_ORIGIN` dengan origin HTTPS deployment milikmu sebelum build agar metadata canonical/social mengarah ke domain yang benar. Gunakan `.env.example` sebagai contoh konfigurasi, tanpa membagikan `.env` pribadi.

Lisensi foto, font, UI, model dan runtime tetap disertakan pada `CREDITS.md`, `THIRD-PARTY-NOTICES.md`, serta direktori lisensi terkait.
