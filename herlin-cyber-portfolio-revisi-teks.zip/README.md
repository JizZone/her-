# Herlin Aprianti - TON 618

Paket inti portfolio Next.js, React Three Fiber, dan GSAP untuk GitHub Codespaces.

## Jalankan di Codespaces

1. Ekstrak seluruh isi ZIP ke root repository GitHub. Pastikan folder `.devcontainer` ikut masuk, sejajar dengan `src` dan `package.json`.
2. Buka repository dengan **Code > Codespaces > Create codespace**. Node.js 22 disiapkan dan `npm ci` dijalankan otomatis.
3. Jalankan `npm run dev` di terminal, lalu buka port **3000** dari tab **Ports**.

Jika membuka di luar Codespaces, gunakan Node.js 22 dan jalankan `npm ci` lebih dahulu.

## Perintah

| Perintah            | Hasil                                         |
| ------------------- | --------------------------------------------- |
| `npm run dev`       | Server pengembangan pada port 3000            |
| `npm run typecheck` | Membuat tipe Next.js dan memeriksa TypeScript |
| `npm run build`     | Build statis siap hosting di folder `out/`    |

## Susunan file

| Lokasi                              | Isi                                       |
| ----------------------------------- | ----------------------------------------- |
| `src/app/`                          | Halaman, rute, metadata, favicon, dan CSS |
| `src/components/`                   | Komponen antarmuka, ikon, dan scene WebGL |
| `src/lib/`                          | Shader, token desain, state, dan utilitas |
| `src/content.ts`                    | Identitas, studi kasus, teks, dan kontak  |
| `public/`                           | Font lokal, lisensi font, dan gambar      |
| `.devcontainer/`                    | Konfigurasi Codespaces                    |
| `package.json`, `package-lock.json` | Perintah dan versi dependensi             |
| `next.config.ts`, `tsconfig.json`   | Konfigurasi Next.js dan TypeScript        |

## Sesuaikan konten

Isi email, WhatsApp, Instagram, LinkedIn, dan lokasi CV di `src/content.ts`. Kontak tetap nonaktif sampai diisi. Simpan CV di `public/` dan gunakan path seperti `/cv.pdf`. Isi statistik hanya dengan data yang dapat dibuktikan.

Untuk build produksi, salin `.env.example` menjadi `.env.local`, lalu ganti `SITE_ORIGIN` dengan origin situs yang sebenarnya, tanpa slash penutup. Nilai ini digunakan oleh canonical, metadata sosial, robots, dan sitemap. Jalankan build kembali setelah menggantinya.

Font dan gambar sudah tersedia secara lokal. `node_modules/`, `.next/`, `out/`, dan `next-env.d.ts` dibuat otomatis saat instalasi atau menjalankan perintah Next.js; semuanya tidak perlu dimasukkan ke Git. Report PDF diberikan terpisah. Catatan QA dan generator yang disebut dalam report adalah arsip pengerjaan, bukan kebutuhan menjalankan situs.

Lisensi aset disertakan di `THIRD-PARTY-NOTICES.md` dan `public/fonts/licenses/`.
