# Photo credits

These are licensed contextual stock photographs, not photographs of Herlin Aprianti’s own projects, facilities, clients, or results. Captions describe the actual photographed subjects and their relationship to the proposed case studies. No endorsement is implied.

All photographs below were checked on 22 October 2026. Each Pexels photo page states Free or Free to use and links to the [Pexels License](https://www.pexels.com/license/). This license permits website use and modification. Images were cropped, resized and compressed; no generative content was added.

| Asset | Photographer | Source | License |
| --- | --- | --- | --- |
| `public/work/dossier/01.webp` and size/format variants | Kampus Production | [Pexels 8353764](https://www.pexels.com/photo/documents-in-a-binder-on-a-work-desk-8353764/) | [Pexels License](https://www.pexels.com/license/) |
| `public/work/dossier/02.webp` and size/format variants | cottonbro studio | [Pexels 6538576](https://www.pexels.com/photo/a-person-with-hand-on-the-file-folder-6538576/) | [Pexels License](https://www.pexels.com/license/) |
| `public/work/dossier/03.webp` and size/format variants | Mikhail Nilov | [Pexels 8730374](https://www.pexels.com/photo/a-person-writing-on-the-document-8730374/) | [Pexels License](https://www.pexels.com/license/) |
| `public/work/audit-ready/01.webp` and size/format variants | Daniel Andraski | [Pexels 12234106](https://www.pexels.com/photo/close-up-shot-of-a-person-doing-a-checklist-12234106/) | [Pexels License](https://www.pexels.com/license/) |
| `public/work/audit-ready/02.webp` and size/format variants | Pavel Danilyuk | [Pexels 8442026](https://www.pexels.com/photo/rotator-in-laboratory-8442026/) | [Pexels License](https://www.pexels.com/license/) |
| `public/work/scale-up/01.webp` and size/format variants | Tara Winstead | [Pexels 7722651](https://www.pexels.com/photo/close-up-shot-of-tablets-7722651/) | [Pexels License](https://www.pexels.com/license/) |
| `public/work/shelf-life/01.webp` and size/format variants | 宏秋 王 | [Pexels 13619560](https://www.pexels.com/photo/metal-drawers-in-laboratory-13619560/) | [Pexels License](https://www.pexels.com/license/) |
| `public/work/shelf-life/02.webp` and size/format variants | Polina Tankilevitch | [Pexels 3735763](https://www.pexels.com/photo/chemicals-in-laboratory-3735763/) | [Pexels License](https://www.pexels.com/license/) |
| `public/work/shelf-life/03.webp` and size/format variants | Yuri Shkoda | [Pexels 10514991](https://www.pexels.com/photo/vials-in-a-chromatograph-10514991/) | [Pexels License](https://www.pexels.com/license/) |

## Cropping and source limits

- The checklist photograph is cropped to remove the branded neck strap; the photograph shows inventory review, not an asserted pharmaceutical audit.
- The storage-drawer photograph is cropped to remove the person at the right. It is laboratory storage, not an established temperature-controlled stability chamber.
- The chromatograph photograph is cropped to remove the equipment manufacturer mark.
- Dossier uses three photographs. Audit Ready uses two relevant photographs because the screened corridor images had visible facial profiles. Scale-Up uses one tablet macro because an exact tablet press and pilot-equipment photograph could not be verified among suitable free Unsplash/Pexels sources. Shelf Life uses three photographs. These counts follow the requested minimum-one exception when suitable sources are insufficient.
- The document-workspace photograph shows a desktop computer rather than a laptop. It is a contextual image, not an actual BPOM submission.

Existing UI and font licenses remain in `THIRD-PARTY-NOTICES.md` and `public/fonts/licenses/`.

## Interface references

The thin pulse ring adapts JkHuger: https://uiverse.io/JkHuger/moody-crab-18 (MIT, checked 22 October 2026). The documentation button retains the V1 fill-sweep adaptation of Adam Giebl: https://uiverse.io/adamgiebl/silent-kangaroo-86 (MIT, checked 22 October 2026). Both use the project palette and local motion tokens. Full retained notices are in THIRD-PARTY-NOTICES.md.

## Cyber Ronin entrance

The Cyber Ronin scene was supplied by the user as `cyber_ronin.html`. The original embedded model was extracted byte-for-byte to `public/cyber/ronin.glb`; its geometry and textures were not replaced.

The embedded glTF metadata identifies the model as **Cyber Samurai** by **KhoaMinh** ([creator](https://sketchfab.com/duongminhkhoa231), [model source](https://sketchfab.com/3d-models/cyber-samurai-26ccafaddb2745ceb56ae5cfc65bfed5)), licensed under [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/). Attribution is reproduced from the supplied asset metadata.

Integration changes: the scene now reads the portfolio's CSS palette for its background and final blackout; the existing Metatron event exits once into the unchanged portfolio loader; the runtime releases its resources at exit; a keyboard target, responsive hit area and a static Metatron fallback were added. The user-supplied shader animation and model remain the basis of the entrance.

Cyber's Three.js **0.160.0** runtime is included locally and isolated from the portfolio's Three.js runtime. The upstream MIT license is retained at `public/cyber/vendor/THREE-LICENSE.txt`. No public CDN is needed to display the supplied model.
