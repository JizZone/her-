# Preview privat — versi sebelum revisi teks

Catatan berikut merekam deployment paket integrasi sebelumnya. Dua teks baru dalam ZIP ini belum diterbitkan ulang ke URL di bawah. Lihat `REVISI-TEKS.md` untuk perubahan terbaru.

URL: https://herlin-cyber-ronin.windyjoy1027.chatgpt.site

Deployment berhasil pada 23 Oktober 2026 pukul 21.12 WIB. Akses diperiksa setelah publikasi: mode custom, hanya satu pengguna dengan peran owner, tanpa grup pengunjung. Buka menggunakan akun ChatGPT pemilik Site.

Ini adalah gabungan Cyber Ronin dan portofolio Herlin V1–V2. Situs V1 publik sebelumnya tidak diganti.

Source commit: `44cde671809f30e5f6142fb156d767db65a51c6e`.

Status deployment yang dikembalikan layanan: `succeeded`, tanpa failure message.

Catatan ini awalnya ditambahkan pada paket integrasi setelah status publikasi berhasil dikonfirmasi. Source/aset paket integrasi sebelum revisi teks sama dengan commit terbit, kecuali konfigurasi hosting Site yang tidak diperlukan oleh Codespaces dan sengaja tidak dimasukkan.

Lihat `../MULAI-DI-SINI.md` untuk instalasi dan `BUILD_INFO.md` untuk bukti pengujian beserta keterbatasan WebGL pada browser QA.

## Riwayat verifikasi paket integrasi sebelum revisi teks

ZIP diekstrak ke direktori baru, lalu `npm ci` dan `npm run build` berhasil dengan exit 0. Instalasi memasang 102 package. Build baru menampilkan `Compiled successfully in 23.4s`, TypeScript selesai dalam 7.8s, dan static export menghasilkan 10/10 halaman. Semua 136 file source yang disertakan cocok byte-for-byte dengan source commit terbit; berkas catatan ini adalah file tambahan ke-137.

Uji CRC ZIP: `No errors detected in compressed data`. Tidak ada node_modules, .next, out, .git, .openai, kredensial atau qa.html dalam paket. `.env.example` adalah contoh konfigurasi asal, bukan kredensial.

Uji keyboard Metatron melalui Enter juga mencapai `portfolio/ready`, dengan `cyberFrames: 0`. Pengujian tersebut berjalan pada fallback WebGL, sesuai keterbatasan pada BUILD_INFO.md.
