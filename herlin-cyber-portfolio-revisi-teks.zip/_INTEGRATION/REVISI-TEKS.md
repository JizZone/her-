# Revisi dua teks Cyber

Paket: `herlin-cyber-portfolio-revisi-teks.zip`. Ini paket proyek lengkap untuk Codespaces, bukan patch. Cara memasang ada di `../MULAI-DI-SINI.md`.

## Perubahan

| Teks sebelumnya | Teks baru | Lokasi |
| --- | --- | --- |
| Metatron sedang terbentuk | slide the mouse, lin! | `public/cyber/index.html` |
| Sentuh Metatron untuk masuk | diagramnya aneh ga si lin? | `public/cyber/ronin.js` dan `public/cyber/boot.js` |

Teks kedua diganti pada jalur animasi 3D dan fallback. Masing-masing dari tiga file kode hanya berubah pada satu string tersebut. Label aksesibilitas tombol tetap menjelaskan tindakan masuk ke portofolio.

Seluruh kode lain, CSS responsif, animasi, model Cyber, loading portofolio, foto Selected Work, konten, font, konfigurasi, `package.json` dan `package-lock.json` identik dengan paket sebelumnya. Tidak ada dependensi baru.

Perubahan dokumentasi hanya mencakup nama ZIP dan keterangan versi pada `MULAI-DI-SINI.md`, penjelasan versi pada `PRIVATE-PREVIEW.md`, serta laporan baru ini. Laporan dan panduan semuanya berupa Markdown; tidak ada PDF.

## Bukti pemeriksaan

Pembanding: `herlin-cyber-portfolio-complete.zip` dengan SHA256:

```text
bff3964dff7a879422e986c814df81ef2d9629bccb1a1c61bca5c513e316ec42
```

Hasil perbandingan isi file:

```text
Original files retained: 137
Exact intended code replacements: 3
Unrelated code differences: 0
Decorative code markers: 0
Package and lock unchanged: True
Literal //**// markers across all code including vendor: 0
Existing PDF reports: 0
```

`node --input-type=module --check` untuk `boot.js` dan `ronin.js`: exit 0, tanpa pesan kesalahan.

Instalasi bersih menggunakan lockfile:

```text
$ npm ci --prefer-offline --no-audit --no-fund
added 102 packages in 21s
exit 0
```

Build terakhir:

```text
$ npm run build
Next.js 16.4.2 (webpack)
Compiled successfully in 36.5s
Finished TypeScript in 10.1s
Generating static pages using 8 workers (10/10) in 895ms
exit 0
```

Home dan keempat halaman detail proyek berhasil diekspor. Percobaan build pertama gagal karena `.next/server/pages-manifest.json` kosong. Direktori hasil build sementara dibersihkan, lalu perintah yang sama berhasil tanpa perubahan source atau konfigurasi. Peringatan environment `http-proxy` dan metadata origin default `http://localhost:3000` muncul; keduanya tidak menggagalkan build terakhir. Pengaturan origin untuk hosting tersedia pada panduan pemasangan.

Paket akhir berisi 138 file: seluruh 137 file asal ditambah laporan ini. Lima file asal berubah, terdiri dari tiga file kode di atas dan dua dokumen yang langsung terkait revisi. Sebanyak 132 file asal tetap identik byte-for-byte. Pemeriksaan ZIP meliputi CRC seluruh entri, kelengkapan path, dan kesamaan setiap file dengan folder proyek yang sudah dibangun.

ZIP tidak menyertakan `node_modules/`, `.next/`, `out/`, `.git/`, `.openai/`, browser pengujian atau hasil QA. Contoh konfigurasi `.env.example` dan konfigurasi Codespaces `.devcontainer/` tetap disertakan. Source berada langsung di root ZIP, dengan `package.json`, `src/` dan `public/` pada tingkat yang sama.

Pemeriksaan kali ini mencakup perubahan string, sintaks JavaScript, build dan integritas paket. CSS serta logika ukuran layar tidak berubah; rincian pemeriksaan visual integrasi sebelumnya tetap ada di `BUILD_INFO.md`.

## Status preview privat

Revisi ini dikirim sebagai ZIP. Preview privat sebelumnya belum diterbitkan ulang sehingga masih memakai teks lama. Riwayat URL dan deployment tersedia di `PRIVATE-PREVIEW.md`.
