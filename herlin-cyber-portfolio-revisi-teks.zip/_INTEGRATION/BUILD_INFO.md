# Bukti integrasi Cyber Ronin + Herlin Aprianti

Tanggal: 23 Oktober 2026, Asia/Jakarta.

## Lingkup

Input: `herlin-portfolio-V1-V2-merged.zip` dan `cyber_ronin.html` yang diunggah pengguna. Output adalah proyek lengkap yang dapat diinstal, bukan ZIP patch. Semua proyek dikerjakan di salinan baru.

Urutan implementasi: Home pertama → Cyber → sentuh Metatron → efek hitam → cleanup dan pelepasan iframe → loading asli → entrance → Home. Kunjungan langsung ke detail proyek mengikuti routing asli dan tidak menjalankan Cyber. Tidak ada tombol replay, state reset atau query untuk mengulang Cyber.

## Hasil pemeriksaan

| Pemeriksaan | Hasil | Batas bukti |
| --- | --- | --- |
| Preservasi portofolio | LULUS | 117 file identik; 2 file lama berubah; tidak ada file unggahan hilang. |
| Loading asli | LULUS | Keempat file `src/intro/` byte-identik dengan unggahan. Browser mengamati loading setelah Cyber dilepas. |
| Model Cyber asli | LULUS | GLB 8.304.724 byte identik dengan data tertanam pada HTML unggahan. |
| Build produksi | LULUS | Next.js 16.4.2, TypeScript dan static export 10 halaman berhasil. |
| Urutan masuk | LULUS pada jalur fallback | Browser mencatat Cyber → black → loading → entering → ready. WebGL browser pengujian dinonaktifkan. |
| Sekali masuk | LULUS pada sesi uji | Reload setelah entry dan kembali dari detail ke Home tidak memasang iframe Cyber lagi. |
| Pelepasan Cyber | LULUS untuk DOM/lifecycle | Iframe berjumlah nol sebelum loading dimulai. Cleanup GPU tersedia di source; penggunaan memori GPU aktual belum diukur. |
| Warna | LULUS | DOM iframe memuat `--ink: #0A0A0A; --bone: #EDEAE4; --gold: #C8A96A;`, dibaca dari CSS halaman induk. |
| Viewport responsif | LULUS untuk pemeriksaan yang dilakukan | Tujuh ukuran iframe diuji; tidak ada horizontal overflow pada Home dan Cyber fallback. Ini bukan sertifikasi seluruh perangkat fisik. |
| Galeri V2 | LULUS untuk pemeriksaan yang dilakukan | Detail Dossier: 0 elemen img sebelum buka; viewer muncul setelah klik; Next menampilkan foto 2; layout 390px diperiksa; Esc menghapus viewer. |
| Model 3D penuh/FPS | BELUM TERVERIFIKASI | Browser uji melaporkan WebGL context disabled. Tidak ada klaim kelancaran GPU atau FPS pada semua perangkat. |

## Perubahan file lama

- `src/app/layout.tsx`: menambahkan `CyberGate` sebagai pembungkus di luar `IntroShell`. Komponen loading tidak diubah; portofolio baru dipasang setelah handoff.
- `CREDITS.md`: menambahkan atribusi model asli dari metadata glTF dan lisensi runtime Cyber.

Seluruh 117 file lama lainnya identik, termasuk `src/content.ts`, `src/app/globals.css`, `src/lib/tokens.ts`, kode galeri, foto, font, package.json dan lockfile. File Preloader lama yang masih ada dalam ZIP unggahan juga dipertahankan; runtime aktif tetap menggunakan modul intro V2.

## SHA-256

```text
b49f7c7248c122353bc44ec383668d1531e0458334e1868a6902f31c5d231f30  src/intro/IntroLoader.tsx
3222b48dcbcafae4e9e5c44afab609b7f3c280a5208fdad62ee1151020b08cd9  src/intro/IntroShell.tsx
4dde042186253c6c5f2d6bacf3a8c5b1b195416fd21ce701b8ad5d5e832c162a  src/intro/intro.css
907c100aaa0a364a1d5795f483c45e087fc57b8a3a1aabcd873ac576d40333bf  src/intro/useIntro.ts
a3df2cd8cb3d6d4731e1ad6abac0b5a399835b928b3351342b6bb0ffd18cd8d3  public/cyber/ronin.glb
d0bc838b9050ea028e9b5f1484e1ae5c6b0f671aeb69090a2d1fa2a2dc660743  cyber_ronin.html (input)
```

Pemeriksaan source dilakukan dengan membandingkan byte seluruh file input ke salinan gabungan. Model GLB dibandingkan langsung terhadap hasil decode base64 input. Runtime lokal Cyber memakai Three.js revision 160, sama dengan import map HTML asli.

## Output build final

```text
> herlin-aprianti-portfolio@1.0.0 build
> next build --webpack

▲ Next.js 16.4.2 (webpack)
✓ Running next.config.ts took 48ms
  Creating an optimized production build ...
✓ Compiled successfully in 5.0s
  Running TypeScript ...
  Finished TypeScript in 2.9s ...
  Collecting page data using 8 workers ...
✓ Generating static pages using 8 workers (10/10) in 861ms
  Finalizing page optimization ...
  Collecting build traces ...

Route (app)
┌ ○ /
├ ○ /_not-found
├ ○ /icon.svg
├ ○ /robots.txt
├ ○ /sitemap.xml
└   /work/[slug]
  ├ ● /work/dossier
  ├ ● /work/audit-ready
  ├ ● /work/scale-up
  └ ● /work/shelf-life
```

Build dijalankan dengan `SITE_ORIGIN` untuk origin preview yang terdaftar. Warning npm `Unknown env config "http-proxy"` berasal dari lingkungan eksekusi dan tidak menggagalkan instalasi/build. Package/lockfile tidak berubah.

## Bukti browser

Timeline berikut berasal dari panel QA lokal, dalam milidetik relatif terhadap panel. Interval sampling 250ms; waktu ini bukan pengukuran durasi animasi frame-presisi.

```json
[
  {"phase":"checking/none","at":61910,"cyberFrames":0},
  {"phase":"cyber/none","at":62127,"cyberFrames":1},
  {"phase":"black/none","at":73345,"cyberFrames":0},
  {"phase":"portfolio/loading","at":74112,"cyberFrames":0},
  {"phase":"portfolio/entering","at":76595,"cyberFrames":0},
  {"phase":"portfolio/ready","at":78595,"cyberFrames":0}
]
```

Status setelah masuk/reload:

```json
{"viewport":[390,844],"gate":"portfolio","intro":"ready","cyberFrames":0,"overflow":false,"target":null}
```

Ukuran yang diuji melalui viewport iframe pada Chrome desktop:

| Ukuran CSS px | Home horizontal overflow | Cyber fallback overflow | Target fallback (w × h) |
| --- | --- | --- | --- |
| 320 × 568 | Tidak | Tidak | 130 × 130 |
| 390 × 844 | Tidak | Tidak | 133 × 133 |
| 430 × 932 | Tidak | Tidak | 146 × 146 |
| 844 × 390 | Tidak | Tidak | 133 × 133 |
| 768 × 1024 | Tidak | Tidak | 240 × 240 |
| 1366 × 768 | Tidak | Tidak | 240 × 240 |
| 1920 × 1080 | Tidak | Tidak | 240 × 240 |

Posisi target Metatron 3D pada pose dasar juga diperiksa secara matematis dengan kamera Three.js asli; target berada di dalam ketujuh viewport. Pemeriksaan ini tidak menggantikan rendering GPU atau pengujian gerakan pada perangkat fisik.

Pesan batas WebGL dari browser:

```text
THREE.WebGLRenderer: A WebGL context could not be created.
GL_VENDOR = Disabled, GL_RENDERER = Disabled
THREE.WebGLRenderer: Error creating WebGL context.
Cyber Ronin fallback: Error: Error creating WebGL context.
```

Karena itu renderer Cyber penuh, distorsi hitam asli pada GPU, FPS, suhu/beban GPU, Safari/iPhone fisik, dan perilaku sentuh perangkat nyata belum dinyatakan lulus. Jalur fallback tidak otomatis masuk: pengguna tetap menyentuh Metatron untuk melanjutkan.

## Cleanup dan batas penyimpanan

Saat masuk normal, runtime menghentikan `setAnimationLoop`, membatalkan fetch/listener melalui AbortController, membuang geometry/material/texture, membuang render target dan renderer, memanggil `forceContextLoss`, lalu menghapus canvas. Parent kemudian menghapus iframe sehingga konteks JavaScript Cyber tidak dipertahankan aplikasi. Waktu pengumpulan memori oleh garbage collector dan cache HTTP tetap dikendalikan browser.

UI QA yang dapat mensimulasikan kunjungan baru hanya dipakai di folder pengujian terpisah. Panel tersebut tidak masuk source produksi, ZIP atau publikasi. Produk tidak mempunyai tombol replay.

## Instalasi dan publikasi

Lihat `MULAI-DI-SINI.md`. ZIP lengkap memuat source, model, vendor lokal, font, foto, konfigurasi Codespaces dan dokumentasi; tidak menyertakan node_modules, output build, metadata Git, kredensial atau panel QA. Konfigurasi hosting Site privat tidak diperlukan untuk Codespaces dan tidak disertakan dalam ZIP.

Publikasi menggunakan Site privat terpisah dari situs V1 publik. Status sukses dan URL final harus dikonfirmasi dari hasil deployment sebelum tautan diberikan.
