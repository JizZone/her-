# Patch Cyber: tampil kembali saat refresh

ZIP ini hanya berisi satu file kode yang direvisi dan petunjuk ini. Terapkan pada proyek Cyber Ronin + Herlin yang sudah terpasang; tidak perlu mengganti proyek lengkap.

## Perilaku baru

- Membuka ulang atau me-refresh halaman Home (`/`) selalu memulai Cyber.
- Penanda kunjungan lama di localStorage/sessionStorage tidak lagi menentukan apakah Cyber tampil. Tidak perlu menghapus data browser.
- Setelah Metatron disentuh, layar menghitam, iframe Cyber dilepas dan portofolio dibuka.
- Navigasi internal dari Home ke proyek lalu kembali ke Home tidak memulai Cyber lagi. Refresh Home akan memulainya kembali.
- Link langsung ke `/work/*` tetap membuka detail proyek.
- Loading portofolio tetap memakai perilaku aslinya, termasuk aturan sesi. Dua teks baru Cyber, model, efek, CSS responsif dan foto tidak diubah.

Ketentuan ini menggantikan keterangan “sekali per browser” pada panduan integrasi lama.

## Pasang di Codespaces

1. Upload `herlin-cyber-refresh-patch.zip` ke root repo `/workspaces/her-`.
2. Hentikan server yang berjalan dengan **Ctrl + C** di terminalnya.
3. Jalankan satu per satu:

```bash
cd /workspaces/her-
unzip -t herlin-cyber-refresh-patch.zip
unzip -o herlin-cyber-refresh-patch.zip 'src/cyber/CyberGate.tsx'
npm run build
```

Perintah ekstraksi hanya menimpa `src/cyber/CyberGate.tsx`. Folder `_PATCH/` adalah catatan dan tidak diperlukan aplikasi. Jika build gagal, periksa outputnya sebelum melanjutkan.

4. Setelah build berhasil:

```bash
npm run dev
```

5. Tunggu **Ready**, buka preview port **3000**, lalu refresh halaman **Home**. Cyber akan muncul kembali. Restart server saja tidak selalu memuat ulang tab browser, jadi lakukan refresh setelah server siap.

Tidak ada perubahan dependensi atau konfigurasi container; patch ini tidak memerlukan instalasi paket tambahan maupun Full Rebuild Codespaces.

## Perubahan kode

Hanya `src/cyber/CyberGate.tsx` yang berubah: hapus pembacaan/penulisan penanda kunjungan persisten serta listener lintas tab, dan tentukan layar awal dari pathname pada setiap pemuatan dokumen baru. State React tetap mencegah pengulangan selama navigasi internal. Pemeriksaan origin/source pesan iframe, blackout, pelepasan iframe dan timer tetap dipertahankan.

SHA256 file sebelum revisi:

```text
5433ae2afde7aafe88de0aeae2ae43686ffcfce19f6fec00e3c95d71964cf567
```

SHA256 file setelah revisi:

```text
55d86a6bc206f800218539047c959cd65b12dcc690a76fe8f7ed35bbd1592201
```

## Hasil verifikasi

Baseline: `herlin-cyber-portfolio-revisi-teks.zip`. Perbandingan seluruh isinya menemukan **1 file kode berubah dan 137 file lain identik**. Tidak ada file yang dihapus, tidak ada perubahan `package.json`/lockfile, dan tidak ada penanda dekoratif pada file kode patch.

Instalasi bersih dan build lulus:

```text
npm ci --prefer-offline --no-audit --no-fund
added 102 packages in 22s
exit 0

npm run build
Next.js 16.4.2 (webpack)
Compiled successfully in 13.7s
Finished TypeScript in 5.2s
Generating static pages using 8 workers (10/10) in 888ms
exit 0
```

Peringatan origin metadata default `http://localhost:3000` muncul pada build lokal tanpa `SITE_ORIGIN`; build tetap berhasil.

Uji browser pada hasil build:

| Pemeriksaan | Hasil |
| --- | --- |
| Home dibuka dengan penanda lama bernilai `1` di localStorage dan sessionStorage | Cyber tampil |
| Sentuh Metatron lalu masuk portofolio | `cyberFrames: 0`, `portfolioShell: 1` |
| Refresh Home setelah masuk | `cyberFramesAfterReload: 1` |
| Masuk lagi, navigasi ke Dossier | `cyberFramesOnProject: 0` |
| Kembali ke Home lewat navigasi internal | `cyberFramesAfterInternalHome: 0`, `portfolioShell: 1` |

Browser pengujian memakai fallback Cyber karena WebGL tidak tersedia. Alur refresh dan navigasi telah diuji; performa render 3D perangkat fisik tidak diuji ulang. Tidak ada perubahan pada renderer atau tata letak.

Paket diperiksa dengan CRC ZIP serta uji penerapan satu file patch pada baseline: seluruh file proyek hasil penerapan cocok dengan proyek yang lulus build. Preview privat yang diterbitkan sebelumnya tidak diperbarui oleh ZIP ini.
